#!/usr/bin/env bash
set -euo pipefail
./gradlew --no-daemon --stacktrace clean assembleDebug
printf '\nAPK: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
