@ECHO OFF
SETLOCAL
SET APP_HOME=%~dp0
IF NOT EXIST "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  WHERE gradle >NUL 2>NUL
  IF ERRORLEVEL 1 (
    ECHO Gradle 8.7 is required to bootstrap the wrapper.
    EXIT /B 1
  )
  gradle wrapper --gradle-version 8.7 --distribution-type bin
)
java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
ENDLOCAL
