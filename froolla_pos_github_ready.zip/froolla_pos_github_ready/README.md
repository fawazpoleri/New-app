# Froolla POS — Android (Django bundled with Chaquopy)

This project packages the Froolla Django POS application inside an Android APK.
The Android app starts Django + Waitress on `127.0.0.1:8000` and loads it in a WebView.
The default Android build uses SQLite stored in the app's private files directory.

## Requirements

- Android Studio or a Linux/macOS/Windows build machine
- JDK 17
- Android SDK (compile/target SDK 34)
- Gradle 8.7 (the GitHub Actions workflow installs it automatically)
- Internet access during the first build because Chaquopy downloads Python packages

## GitHub-only build (recommended)

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Push to `main`, or open **Actions → Build Froolla POS APK → Run workflow**.
4. Download the `froolla-pos-debug-apk` artifact from the completed workflow.
5. Install the APK on your Android phone.

The workflow bootstraps the standard Gradle wrapper (`gradlew`, `gradlew.bat`, and
`gradle/wrapper/gradle-wrapper.jar`) before building, so the repository does not need
to contain a binary wrapper JAR generated on another machine.

## Local build

If Gradle 8.7 is installed, run:

```bash
./gradlew assembleDebug
```

On the first run, the wrapper JAR is generated automatically if it is missing.

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Android runtime design

- Python 3.11 + Django are bundled by Chaquopy.
- Waitress serves Django on loopback only (`127.0.0.1:8000`).
- Android WebView loads the local Django site.
- SQLite is stored under the app's private `files/froolla_runtime` directory.
- The first run runs Django migrations and creates the starter cashier account.

### Starter login

- Username: `cashier`
- Password: `froolla123`

Change the password before using the app for real sales.

## Important production note

This build is intended for a **single Android POS device**. It does not expose Django
to the LAN and does not synchronize sales between multiple devices. Add an export/backup
strategy before using the APK as the only copy of business data.
