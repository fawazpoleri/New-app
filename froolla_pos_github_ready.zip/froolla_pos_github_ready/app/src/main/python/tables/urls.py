"""
URL routes for the tables app: floor plan, ordering screen, and KOT printing.
"""

from django.urls import path

from tables import views

app_name = 'tables'

urlpatterns = [
    path('tables/', views.TableGridView.as_view(), name='grid'),
    path('tables/<int:pk>/open/', views.TableOpenView.as_view(), name='open_table'),

    path('tables/order/<int:pk>/', views.TableOrderDetailView.as_view(), name='order_detail'),
    path('tables/order/<int:pk>/add-item/', views.order_add_item, name='order_add_item'),
    path('tables/order/<int:pk>/update-quantity/', views.order_update_quantity, name='order_update_quantity'),
    path('tables/order/<int:pk>/note/', views.order_set_note, name='order_set_note'),
    path('tables/order/<int:pk>/confirm/', views.order_confirm, name='order_confirm'),
    path('tables/order/<int:pk>/invoice/', views.TableOrderInvoiceView.as_view(), name='order_invoice'),

    path('tables/kot/<int:pk>/print/', views.KotPrintView.as_view(), name='kot_print'),

    path('kitchen/', views.KitchenDisplayView.as_view(), name='kitchen_display'),
    path('kitchen/board/', views.KitchenDisplayBoardView.as_view(), name='kitchen_display_board'),
    path('kitchen/kot/<int:pk>/start/', views.kot_mark_preparing, name='kot_mark_preparing'),
    path('kitchen/kot/<int:pk>/complete/', views.kot_mark_completed, name='kot_mark_completed'),
    path('kitchen/kot/<int:pk>/undo/', views.kot_mark_pending, name='kot_mark_pending'),

    path('tables/sw.js', views.ServiceWorkerView.as_view(), name='service_worker'),
]
