"""
Tables app models — Restaurant Table Management & KOT.

Model map (see spec doc):

    DiningTable          one physical table in the dining room
    TableOrder           the open "tab" running against a table
    TableOrderItem        a product line within that tab (current + snapshot)
    KitchenOrderTicket    one printed slip sent to the kitchen
    KitchenOrderItem      one ADD/CANCEL line within a KOT

Design notes
------------
- A TableOrderItem's `quantity` is always the *current* live quantity on
  the tab (0 means "removed", but the row is kept for audit history once
  it has ever been sent to the kitchen). `confirmed_quantity` is a
  snapshot of what the kitchen was last told — the difference between the
  two is exactly what "Confirm Order" turns into a new KOT.
- This keeps "unlimited modifications" trivial: bump `quantity` as many
  times as you like, and only the *net* change since the last KOT is ever
  printed, never a duplicate of what the kitchen already has.
- Money fields snapshot name/price at add-time (same pattern as
  billing.OrderItem) so a later menu price change never rewrites history.
"""

from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Q
from django.utils import timezone


class DiningTable(models.Model):
    """One physical table in the dining room."""

    class Status(models.TextChoices):
        VACANT = 'VACANT', 'Vacant'
        OCCUPIED = 'OCCUPIED', 'Occupied'
        RESERVED = 'RESERVED', 'Reserved'
        CLEANING = 'CLEANING', 'Cleaning'
        DISABLED = 'DISABLED', 'Disabled'

    table_number = models.CharField(
        max_length=10,
        unique=True,
        help_text='Short identifier shown on the floor plan, e.g. "T5".',
    )
    name = models.CharField(
        max_length=50,
        blank=True,
        help_text='Optional friendly name, e.g. "Patio 2" or "Window Booth".',
    )
    capacity = models.PositiveSmallIntegerField(default=4)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.VACANT)
    assigned_waiter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_tables',
        help_text='Optional default waiter for this table.',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['table_number']

    def __str__(self) -> str:
        return self.name and f'{self.table_number} — {self.name}' or self.table_number

    @property
    def active_order(self):
        """The single OPEN TableOrder for this table, if any."""
        return self.orders.filter(status=TableOrder.Status.OPEN).first()

    @property
    def display_label(self) -> str:
        return self.name or self.table_number


class TableOrder(models.Model):
    """The running tab for one dine-in visit at a table."""

    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open'          # Being built / served, not yet billed
        BILLED = 'BILLED', 'Billed'    # Invoice generated, awaiting payment
        PAID = 'PAID', 'Paid'          # Payment received, table closed
        VOID = 'VOID', 'Void'          # Abandoned without billing

    table = models.ForeignKey(DiningTable, on_delete=models.PROTECT, related_name='orders')
    waiter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='table_orders',
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    customer_note = models.CharField(max_length=200, blank=True)

    invoice = models.OneToOneField(
        'billing.Order',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='table_order',
    )

    opened_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-opened_at']
        constraints = [
            # DB-level enforcement of "only ONE active order per table" —
            # a partial unique index on (table) that only applies while
            # status='OPEN', so history of past OPEN orders is unaffected.
            models.UniqueConstraint(
                fields=['table'],
                condition=Q(status='OPEN'),
                name='one_open_order_per_table',
            ),
        ]

    def __str__(self) -> str:
        return f'{self.table.table_number} — {self.get_status_display()} (#{self.pk})'

    @property
    def active_items(self):
        return self.items.filter(quantity__gt=0)

    @property
    def current_subtotal(self) -> Decimal:
        return sum((item.line_total for item in self.active_items), Decimal('0.00'))

    @property
    def has_pending_changes(self) -> bool:
        """True if any item has unconfirmed additions/cancellations."""
        return any(item.quantity != item.confirmed_quantity for item in self.items.all())

    @property
    def next_kot_number(self) -> int:
        return self.kots.count() + 1


class TableOrderItem(models.Model):
    """A single product line on a table's tab."""

    table_order = models.ForeignKey(TableOrder, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey('menu.MenuItem', on_delete=models.PROTECT, related_name='table_order_items')

    # Snapshot at time of sale, same pattern as billing.OrderItem.
    item_name = models.CharField(max_length=100)
    unit_price = models.DecimalField(max_digits=8, decimal_places=2)

    quantity = models.PositiveIntegerField(
        default=0,
        help_text='Current live quantity. 0 = removed, but kept for KOT history.',
    )
    confirmed_quantity = models.PositiveIntegerField(
        default=0,
        help_text='Quantity as of the last KOT sent to the kitchen.',
    )
    notes = models.CharField(max_length=200, blank=True, help_text='e.g. "No onion".')

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']
        unique_together = [('table_order', 'product')]

    def __str__(self) -> str:
        return f'{self.item_name} x{self.quantity}'

    @property
    def line_total(self) -> Decimal:
        return self.unit_price * self.quantity

    @property
    def is_pending(self) -> bool:
        return self.quantity != self.confirmed_quantity

    def save(self, *args, **kwargs):
        if not self.pk and not self.unit_price:
            self.unit_price = self.product.price
        if not self.item_name:
            self.item_name = self.product.name
        super().save(*args, **kwargs)


class KitchenOrderTicket(models.Model):
    """One printed slip sent to the kitchen for a table order."""

    class Status(models.TextChoices):
        PRINTED = 'PRINTED', 'Printed'
        VOID = 'VOID', 'Void'

    class PrepStatus(models.TextChoices):
        """Kitchen Display Screen workflow state — independent of `status`
        above, which only tracks print/void. A ticket can be reprinted
        any number of times without touching where it is in the kitchen's
        prep workflow."""
        PENDING = 'PENDING', 'New'
        PREPARING = 'PREPARING', 'Preparing'
        COMPLETED = 'COMPLETED', 'Completed'

    table_order = models.ForeignKey(TableOrder, on_delete=models.CASCADE, related_name='kots')
    kot_number = models.PositiveIntegerField(help_text='Sequential within this table order (1, 2, 3…).')
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PRINTED)
    prep_status = models.CharField(
        max_length=10, choices=PrepStatus.choices, default=PrepStatus.PENDING,
        help_text='Kitchen Display Screen workflow state.',
    )
    preparing_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='kots_created',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['kot_number']
        unique_together = [('table_order', 'kot_number')]

    def __str__(self) -> str:
        return f'KOT #{self.kot_number:03d} — {self.table_order.table.table_number}'

    @property
    def label(self) -> str:
        return f'KOT #{self.kot_number:03d}'

    @property
    def has_cancellations(self) -> bool:
        return self.items.filter(action=KitchenOrderItem.Action.CANCEL).exists()

    @property
    def is_addition_only(self) -> bool:
        return not self.has_cancellations

    def mark_preparing(self):
        self.prep_status = self.PrepStatus.PREPARING
        self.preparing_at = timezone.now()
        self.completed_at = None
        self.save(update_fields=['prep_status', 'preparing_at', 'completed_at'])

    def mark_completed(self):
        self.prep_status = self.PrepStatus.COMPLETED
        self.completed_at = timezone.now()
        if not self.preparing_at:
            self.preparing_at = self.completed_at
        self.save(update_fields=['prep_status', 'preparing_at', 'completed_at'])

    def mark_pending(self):
        """Undo — send a ticket back to the New column (mis-tap recovery)."""
        self.prep_status = self.PrepStatus.PENDING
        self.preparing_at = None
        self.completed_at = None
        self.save(update_fields=['prep_status', 'preparing_at', 'completed_at'])


class KitchenOrderItem(models.Model):
    """One ADD or CANCEL line within a KitchenOrderTicket."""

    class Action(models.TextChoices):
        ADD = 'ADD', 'Add'
        CANCEL = 'CANCEL', 'Cancel'

    kot = models.ForeignKey(KitchenOrderTicket, on_delete=models.CASCADE, related_name='items')
    table_order_item = models.ForeignKey(
        TableOrderItem,
        on_delete=models.PROTECT,
        related_name='kot_entries',
    )
    item_name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(help_text='The net change this KOT represents (always positive).')
    action = models.CharField(max_length=10, choices=Action.choices)
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ['id']

    def __str__(self) -> str:
        return f'{self.action} {self.item_name} x{self.quantity}'
