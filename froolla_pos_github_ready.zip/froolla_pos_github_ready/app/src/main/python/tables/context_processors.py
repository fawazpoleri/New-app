"""
Makes the "Kitchen" nav badge count (New + Preparing tickets) available
in every template without each view having to fetch it.
"""

from tables.models import KitchenOrderTicket, TableOrder


def kitchen_pending_count(request):
    if not request.user.is_authenticated:
        return {}
    count = KitchenOrderTicket.objects.filter(
        status=KitchenOrderTicket.Status.PRINTED,
        table_order__status=TableOrder.Status.OPEN,
        prep_status__in=[
            KitchenOrderTicket.PrepStatus.PENDING,
            KitchenOrderTicket.PrepStatus.PREPARING,
        ],
    ).count()
    return {'kitchen_pending_count': count}
