from django import template

from tables.permissions import can_bill as _can_bill
from tables.permissions import is_kitchen as _is_kitchen
from tables.permissions import role_label as _role_label

register = template.Library()


@register.filter
def role_label(user):
    return _role_label(user)


@register.filter
def can_bill(user):
    return _can_bill(user)


@register.filter
def is_kitchen(user):
    return _is_kitchen(user)
