"""
Role helpers for the table-management module.

Follows the same convention already used across the project
(accounts/models.py docstring):

    is_staff                    -> Admin
    member of "Waiter" group    -> Waiter
    member of "Kitchen" group   -> Kitchen
    everyone else authenticated -> Cashier

Waiters can open tables, take orders, and fire KOTs, but must never see
reports/settings (already enforced elsewhere via is_staff checks) and
must never generate an invoice — billing/payment stays a
cashier-or-admin action.

Kitchen users are for the Kitchen Display Screen only: they view fired
KOTs and mark them Preparing/Completed. Like Waiters, they must never
generate an invoice.
"""

from functools import wraps

from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied

WAITER_GROUP_NAME = 'Waiter'
KITCHEN_GROUP_NAME = 'Kitchen'


def is_waiter(user) -> bool:
    if not user.is_authenticated or user.is_staff:
        return False
    return user.groups.filter(name=WAITER_GROUP_NAME).exists()


def is_kitchen(user) -> bool:
    if not user.is_authenticated or user.is_staff:
        return False
    return user.groups.filter(name=KITCHEN_GROUP_NAME).exists()


def role_label(user) -> str:
    if user.is_staff:
        return 'Admin'
    if is_waiter(user):
        return 'Waiter'
    if is_kitchen(user):
        return 'Kitchen'
    return 'Cashier'


def can_bill(user) -> bool:
    """Cashiers and Admins can generate invoices and take payment; Waiters and Kitchen cannot."""
    return user.is_staff or not (is_waiter(user) or is_kitchen(user))


class CashierOrAdminRequiredMixin(UserPassesTestMixin):
    """
    For class-based views: blocks Waiters/Kitchen from billing/payment screens.
    Pair with LoginRequiredMixin (put this one second) so an anonymous
    user still gets redirected to login rather than a 403.
    """

    def test_func(self):
        return can_bill(self.request.user)

    def handle_no_permission(self):
        if not self.request.user.is_authenticated:
            return super().handle_no_permission()
        raise PermissionDenied("You don't have access to billing/payment.")


def cashier_or_admin_required(view_func):
    """Function-view equivalent of CashierOrAdminRequiredMixin. Stack under @login_required."""

    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not can_bill(request.user):
            raise PermissionDenied("You don't have access to billing/payment.")
        return view_func(request, *args, **kwargs)

    return wrapper
