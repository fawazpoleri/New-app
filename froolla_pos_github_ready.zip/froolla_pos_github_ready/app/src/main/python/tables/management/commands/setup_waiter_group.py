from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand

from tables.permissions import WAITER_GROUP_NAME


class Command(BaseCommand):
    help = 'Creates the "Waiter" group (idempotent). Add users to it in Django Admin to give them waiter access.'

    def handle(self, *args, **options):
        group, created = Group.objects.get_or_create(name=WAITER_GROUP_NAME)
        if created:
            self.stdout.write(self.style.SUCCESS(f'Created group "{group.name}".'))
        else:
            self.stdout.write(f'Group "{group.name}" already exists.')
