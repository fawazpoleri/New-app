from django.apps import AppConfig


class TablesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tables'
    verbose_name = 'Table Management'

    def ready(self):
        # Registers the post_save receiver that closes a table (marks the
        # TableOrder PAID and the DiningTable VACANT) the moment its linked
        # billing.Order is marked paid. Imported here rather than at module
        # load time to avoid app-loading order issues.
        from tables import signals  # noqa: F401
