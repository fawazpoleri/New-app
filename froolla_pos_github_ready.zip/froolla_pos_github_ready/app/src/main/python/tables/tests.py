"""
Tables app tests — the dine-in tab/KOT workflow, which sits between the
waiter screen and the billing app. Covers:

  - Opening a table's tab (create-once, reuse, disabled-table guard)
  - Adding/incrementing items and floor-plan occupancy syncing
  - The confirm_order() diff logic that decides what actually gets sent
    to the kitchen (net ADD/CANCEL only, never a duplicate)
  - generate_invoice() end-to-end, and that a billed tab can't be edited
    or billed twice
  - The one-open-order-per-table DB constraint
"""

from decimal import Decimal

from django.contrib.auth.models import Group, User
from django.db import IntegrityError, transaction
from django.test import Client, TestCase
from django.urls import reverse

from menu.models import Category, MenuItem
from tables import services
from tables.models import DiningTable, KitchenOrderItem, KitchenOrderTicket, TableOrder
from tables.permissions import KITCHEN_GROUP_NAME, can_bill, is_kitchen, role_label


class TablesTestBase(TestCase):
    def setUp(self):
        self.waiter = User.objects.create_user('waiter1', password='x')
        self.cashier = User.objects.create_user('cashier1', password='x')
        self.table = DiningTable.objects.create(table_number='T1')
        self.category = Category.objects.create(name='Snacks')
        self.item_a = MenuItem.objects.create(category=self.category, name='Fries', price=Decimal('50.00'))
        self.item_b = MenuItem.objects.create(category=self.category, name='Sandwich', price=Decimal('80.00'))


class OpenTableTests(TablesTestBase):
    def test_opening_a_vacant_table_creates_an_order(self):
        table_order = services.open_table(self.table, self.waiter)
        self.assertEqual(table_order.status, TableOrder.Status.OPEN)
        self.assertEqual(table_order.table, self.table)

    def test_opening_an_already_open_table_reuses_the_same_order(self):
        first = services.open_table(self.table, self.waiter)
        second = services.open_table(self.table, self.waiter)
        self.assertEqual(first.pk, second.pk)

    def test_opening_an_empty_tab_does_not_mark_table_occupied(self):
        services.open_table(self.table, self.waiter)
        self.table.refresh_from_db()
        self.assertEqual(self.table.status, DiningTable.Status.VACANT)

    def test_cannot_open_a_disabled_table(self):
        self.table.status = DiningTable.Status.DISABLED
        self.table.save(update_fields=['status'])
        with self.assertRaises(services.TableOrderError):
            services.open_table(self.table, self.waiter)

    def test_only_one_open_order_per_table_enforced_at_db_level(self):
        services.open_table(self.table, self.waiter)
        # Bypass the service layer to simulate a race that both passed the
        # select_for_update check — the DB constraint must still catch it.
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                TableOrder.objects.create(table=self.table, waiter=self.waiter)


class AddItemTests(TablesTestBase):
    def setUp(self):
        super().setUp()
        self.table_order = services.open_table(self.table, self.waiter)

    def test_adding_a_new_item_creates_a_line_with_snapshot_price(self):
        line = services.add_item(self.table_order, self.item_a)
        self.assertEqual(line.quantity, 1)
        self.assertEqual(line.unit_price, Decimal('50.00'))
        self.assertEqual(line.item_name, 'Fries')

    def test_adding_the_same_item_twice_increments_quantity_not_duplicates_row(self):
        services.add_item(self.table_order, self.item_a, quantity=2)
        services.add_item(self.table_order, self.item_a, quantity=3)
        self.assertEqual(self.table_order.items.count(), 1)
        line = self.table_order.items.get(product=self.item_a)
        self.assertEqual(line.quantity, 5)

    def test_adding_an_item_marks_table_occupied(self):
        services.add_item(self.table_order, self.item_a)
        self.table.refresh_from_db()
        self.assertEqual(self.table.status, DiningTable.Status.OCCUPIED)

    def test_price_change_on_menu_does_not_affect_existing_line(self):
        services.add_item(self.table_order, self.item_a)
        self.item_a.price = Decimal('999.00')
        self.item_a.save(update_fields=['price'])

        line = self.table_order.items.get(product=self.item_a)
        self.assertEqual(line.unit_price, Decimal('50.00'))  # snapshot, unchanged

    def test_cannot_add_item_to_billed_order(self):
        services.add_item(self.table_order, self.item_a)
        services.generate_invoice(self.table_order, self.cashier)
        with self.assertRaises(services.TableOrderError):
            services.add_item(self.table_order, self.item_b)


class SetItemQuantityTests(TablesTestBase):
    def setUp(self):
        super().setUp()
        self.table_order = services.open_table(self.table, self.waiter)

    def test_zeroing_an_unconfirmed_new_line_deletes_it(self):
        line = services.add_item(self.table_order, self.item_a, quantity=2)
        services.set_item_quantity(self.table_order, line.pk, 0)
        self.assertFalse(self.table_order.items.filter(pk=line.pk).exists())

    def test_table_goes_vacant_again_after_removing_the_only_item(self):
        line = services.add_item(self.table_order, self.item_a, quantity=1)
        self.table.refresh_from_db()
        self.assertEqual(self.table.status, DiningTable.Status.OCCUPIED)

        services.set_item_quantity(self.table_order, line.pk, 0)
        self.table.refresh_from_db()
        self.assertEqual(self.table.status, DiningTable.Status.VACANT)

    def test_zeroing_a_confirmed_line_keeps_it_for_audit_and_cancels_in_kot(self):
        line = services.add_item(self.table_order, self.item_a, quantity=2)
        services.confirm_order(self.table_order, self.waiter)  # sends KOT, confirmed_quantity=2

        services.set_item_quantity(self.table_order, line.pk, 0)
        line.refresh_from_db()
        self.assertEqual(line.quantity, 0)
        self.assertTrue(TableOrder.objects.filter(pk=self.table_order.pk).exists())  # row kept

        kot = services.confirm_order(self.table_order, self.waiter)
        cancel_lines = kot.items.filter(action=KitchenOrderItem.Action.CANCEL)
        self.assertEqual(cancel_lines.count(), 1)
        self.assertEqual(cancel_lines.first().quantity, 2)

    def test_negative_quantity_is_clamped_to_zero(self):
        line = services.add_item(self.table_order, self.item_a, quantity=1)
        services.confirm_order(self.table_order, self.waiter)
        services.set_item_quantity(self.table_order, line.pk, -5)
        line.refresh_from_db()
        self.assertEqual(line.quantity, 0)


class ConfirmOrderKOTDiffTests(TablesTestBase):
    def setUp(self):
        super().setUp()
        self.table_order = services.open_table(self.table, self.waiter)

    def test_confirm_with_no_changes_returns_none(self):
        result = services.confirm_order(self.table_order, self.waiter)
        self.assertIsNone(result)

    def test_first_confirm_sends_full_quantity_as_add(self):
        services.add_item(self.table_order, self.item_a, quantity=3)
        kot = services.confirm_order(self.table_order, self.waiter)

        self.assertIsNotNone(kot)
        self.assertEqual(kot.kot_number, 1)
        lines = list(kot.items.all())
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0].action, KitchenOrderItem.Action.ADD)
        self.assertEqual(lines[0].quantity, 3)

    def test_second_confirm_only_sends_the_net_new_delta(self):
        line = services.add_item(self.table_order, self.item_a, quantity=2)
        services.confirm_order(self.table_order, self.waiter)  # KOT #1: ADD 2

        services.set_item_quantity(self.table_order, line.pk, 5)
        kot2 = services.confirm_order(self.table_order, self.waiter)  # KOT #2: ADD 3 only

        self.assertEqual(kot2.kot_number, 2)
        lines = list(kot2.items.all())
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0].quantity, 3)  # 5 - 2, not the full 5 again

    def test_reducing_quantity_after_confirm_sends_a_cancel_delta(self):
        line = services.add_item(self.table_order, self.item_a, quantity=5)
        services.confirm_order(self.table_order, self.waiter)  # ADD 5

        services.set_item_quantity(self.table_order, line.pk, 2)
        kot2 = services.confirm_order(self.table_order, self.waiter)

        lines = list(kot2.items.all())
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0].action, KitchenOrderItem.Action.CANCEL)
        self.assertEqual(lines[0].quantity, 3)  # 5 - 2

    def test_mixed_add_and_new_item_in_one_confirm(self):
        line_a = services.add_item(self.table_order, self.item_a, quantity=2)
        services.confirm_order(self.table_order, self.waiter)  # ADD 2 (item_a)

        services.set_item_quantity(self.table_order, line_a.pk, 4)  # +2 more
        services.add_item(self.table_order, self.item_b, quantity=1)  # brand new item
        kot2 = services.confirm_order(self.table_order, self.waiter)

        actions = {(i.item_name, i.action, i.quantity) for i in kot2.items.all()}
        self.assertIn(('Fries', KitchenOrderItem.Action.ADD, 2), actions)
        self.assertIn(('Sandwich', KitchenOrderItem.Action.ADD, 1), actions)

    def test_cannot_confirm_a_billed_order(self):
        services.add_item(self.table_order, self.item_a)
        services.generate_invoice(self.table_order, self.cashier)
        with self.assertRaises(services.TableOrderError):
            services.confirm_order(self.table_order, self.waiter)


class GenerateInvoiceTests(TablesTestBase):
    def setUp(self):
        super().setUp()
        self.table_order = services.open_table(self.table, self.waiter)

    def test_generate_invoice_creates_matching_order(self):
        services.add_item(self.table_order, self.item_a, quantity=2)  # 100.00
        services.add_item(self.table_order, self.item_b, quantity=1)  # 80.00

        order = services.generate_invoice(self.table_order, self.cashier)
        order.recalculate_totals()

        self.assertEqual(order.items.count(), 2)
        self.assertEqual(order.subtotal, Decimal('180.00'))

    def test_generate_invoice_folds_in_unconfirmed_edits_first(self):
        """Any last-second unconfirmed changes must be included in the bill."""
        services.add_item(self.table_order, self.item_a, quantity=1)
        # Deliberately never call confirm_order() before billing.
        order = services.generate_invoice(self.table_order, self.cashier)
        self.assertEqual(order.items.count(), 1)

    def test_generate_invoice_marks_table_order_billed_and_links_invoice(self):
        services.add_item(self.table_order, self.item_a)
        order = services.generate_invoice(self.table_order, self.cashier)

        self.table_order.refresh_from_db()
        self.assertEqual(self.table_order.status, TableOrder.Status.BILLED)
        self.assertEqual(self.table_order.invoice_id, order.pk)

    def test_cannot_bill_an_empty_table(self):
        with self.assertRaises(services.TableOrderError):
            services.generate_invoice(self.table_order, self.cashier)

    def test_cannot_bill_the_same_table_order_twice(self):
        services.add_item(self.table_order, self.item_a)
        services.generate_invoice(self.table_order, self.cashier)
        with self.assertRaises(services.TableOrderError):
            services.generate_invoice(self.table_order, self.cashier)

    def test_paying_the_invoice_frees_the_table(self):
        services.add_item(self.table_order, self.item_a)
        order = services.generate_invoice(self.table_order, self.cashier)
        order.recalculate_totals()

        order.mark_paid()  # triggers tables.signals.close_table_on_payment

        self.table_order.refresh_from_db()
        self.table.refresh_from_db()
        self.assertEqual(self.table_order.status, TableOrder.Status.PAID)
        self.assertEqual(self.table.status, DiningTable.Status.VACANT)


class KitchenRoleTests(TablesTestBase):
    """The Kitchen role: KDS access, but never billing."""

    def setUp(self):
        super().setUp()
        self.kitchen_user = User.objects.create_user('cook1', password='x')
        self.kitchen_user.groups.add(Group.objects.get_or_create(name=KITCHEN_GROUP_NAME)[0])

    def test_is_kitchen_true_for_kitchen_group_member(self):
        self.assertTrue(is_kitchen(self.kitchen_user))
        self.assertFalse(is_kitchen(self.cashier))
        self.assertFalse(is_kitchen(self.waiter))

    def test_kitchen_role_label(self):
        self.assertEqual(role_label(self.kitchen_user), 'Kitchen')

    def test_kitchen_cannot_bill(self):
        self.assertFalse(can_bill(self.kitchen_user))

    def test_admin_is_never_classified_as_kitchen(self):
        admin = User.objects.create_user('boss', password='x', is_staff=True)
        admin.groups.add(Group.objects.get(name=KITCHEN_GROUP_NAME))
        self.assertFalse(is_kitchen(admin))  # is_staff always wins -> Admin


class KotPrepStatusModelTests(TablesTestBase):
    def setUp(self):
        super().setUp()
        self.table_order = services.open_table(self.table, self.waiter)
        services.add_item(self.table_order, self.item_a, quantity=2)
        self.kot = services.confirm_order(self.table_order, self.waiter)

    def test_new_kot_starts_pending(self):
        self.assertEqual(self.kot.prep_status, KitchenOrderTicket.PrepStatus.PENDING)
        self.assertIsNone(self.kot.preparing_at)
        self.assertIsNone(self.kot.completed_at)

    def test_mark_preparing_sets_timestamp(self):
        self.kot.mark_preparing()
        self.assertEqual(self.kot.prep_status, KitchenOrderTicket.PrepStatus.PREPARING)
        self.assertIsNotNone(self.kot.preparing_at)
        self.assertIsNone(self.kot.completed_at)

    def test_mark_completed_sets_timestamp(self):
        self.kot.mark_completed()
        self.assertEqual(self.kot.prep_status, KitchenOrderTicket.PrepStatus.COMPLETED)
        self.assertIsNotNone(self.kot.completed_at)

    def test_mark_completed_without_preparing_first_backfills_preparing_at(self):
        """A kitchen can tap straight to Complete on a quick ticket — Preparing
        is never a hard gate, but the timeline shouldn't show a gap."""
        self.kot.mark_completed()
        self.assertIsNotNone(self.kot.preparing_at)
        self.assertEqual(self.kot.preparing_at, self.kot.completed_at)

    def test_mark_pending_clears_timestamps(self):
        self.kot.mark_completed()
        self.kot.mark_pending()
        self.assertEqual(self.kot.prep_status, KitchenOrderTicket.PrepStatus.PENDING)
        self.assertIsNone(self.kot.preparing_at)
        self.assertIsNone(self.kot.completed_at)


class KitchenDisplayViewTests(TablesTestBase):
    """The KDS board views/actions, via the actual HTTP endpoints."""

    def setUp(self):
        super().setUp()
        self.client = Client()
        self.client.login(username='waiter1', password='x')

        self.table_order = services.open_table(self.table, self.waiter)
        services.add_item(self.table_order, self.item_a, quantity=1)
        self.kot1 = services.confirm_order(self.table_order, self.waiter)

        # A second table/order so ordering across tickets is meaningful.
        self.table2 = DiningTable.objects.create(table_number='T2')
        self.table_order2 = services.open_table(self.table2, self.waiter)
        services.add_item(self.table_order2, self.item_b, quantity=1)
        self.kot2 = services.confirm_order(self.table_order2, self.waiter)

    def test_board_lists_new_tickets_oldest_first(self):
        resp = self.client.get(reverse('tables:kitchen_display'))
        self.assertEqual(resp.status_code, 200)
        content = resp.content.decode()
        # kot1 (created first) must appear before kot2, regardless of their
        # per-table-order KOT numbers (which can collide, e.g. both being
        # "KOT #001" for their respective tables) — so match on the
        # globally-unique ticket id instead.
        marker1 = f'data-kot-id="{self.kot1.pk}"'
        marker2 = f'data-kot-id="{self.kot2.pk}"'
        self.assertLess(content.index(marker1), content.index(marker2))

    def test_mark_preparing_moves_ticket_out_of_new_column(self):
        url = reverse('tables:kot_mark_preparing', args=[self.kot1.pk])
        resp = self.client.post(url)
        self.assertEqual(resp.status_code, 200)
        self.kot1.refresh_from_db()
        self.assertEqual(self.kot1.prep_status, KitchenOrderTicket.PrepStatus.PREPARING)
        self.assertIn('Mark Complete', resp.content.decode())

    def test_mark_completed_moves_ticket_to_completed_column(self):
        self.client.post(reverse('tables:kot_mark_preparing', args=[self.kot1.pk]))
        resp = self.client.post(reverse('tables:kot_mark_completed', args=[self.kot1.pk]))
        self.assertEqual(resp.status_code, 200)
        self.kot1.refresh_from_db()
        self.assertEqual(self.kot1.prep_status, KitchenOrderTicket.PrepStatus.COMPLETED)

    def test_undo_sends_ticket_back_to_new(self):
        self.client.post(reverse('tables:kot_mark_preparing', args=[self.kot1.pk]))
        self.client.post(reverse('tables:kot_mark_completed', args=[self.kot1.pk]))
        self.client.post(reverse('tables:kot_mark_pending', args=[self.kot1.pk]))
        self.kot1.refresh_from_db()
        self.assertEqual(self.kot1.prep_status, KitchenOrderTicket.PrepStatus.PENDING)

    def test_action_endpoints_reject_get(self):
        url = reverse('tables:kot_mark_preparing', args=[self.kot1.pk])
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 405)

    def test_billed_table_orders_do_not_appear_on_board(self):
        services.generate_invoice(self.table_order, self.cashier)
        resp = self.client.get(reverse('tables:kitchen_display'))
        self.assertNotIn(f'data-kot-id="{self.kot1.pk}"', resp.content.decode())

    def test_kitchen_user_can_view_board_but_not_bill(self):
        kitchen_user = User.objects.create_user('cook1', password='x')
        kitchen_user.groups.add(Group.objects.get_or_create(name=KITCHEN_GROUP_NAME)[0])
        self.client.login(username='cook1', password='x')

        resp = self.client.get(reverse('tables:kitchen_display'))
        self.assertEqual(resp.status_code, 200)

        resp = self.client.post(
            reverse('tables:order_invoice', args=[self.table_order.pk])
        )
        # Redirected back, not billed — Kitchen has no billing access.
        self.table_order.refresh_from_db()
        self.assertEqual(self.table_order.status, TableOrder.Status.OPEN)
