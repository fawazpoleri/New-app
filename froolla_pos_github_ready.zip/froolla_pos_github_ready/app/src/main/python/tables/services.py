"""
Tables app service layer.

Every state-changing operation on a table/tab goes through here rather
than being spread across views, so the business rules from the spec
(one active order per table, never print duplicate KOT items, unlimited
edits, complete audit trail, atomic + lock-safe) live in exactly one
place.
"""

from decimal import Decimal

from django.db import transaction

from billing.models import Order, OrderItem
from menu.models import MenuItem

from tables.models import (
    DiningTable,
    KitchenOrderItem,
    KitchenOrderTicket,
    TableOrder,
    TableOrderItem,
)


class TableOrderError(Exception):
    """Raised for any business-rule violation in the table-order workflow."""


@transaction.atomic
def open_table(table: DiningTable, waiter) -> TableOrder:
    """
    Return the table's existing OPEN order, or create a fresh one.

    select_for_update + the DB-level UniqueConstraint together guarantee
    exactly one active order per table even under concurrent taps (e.g.
    two waiters opening the same table at once).
    """
    if table.status == DiningTable.Status.DISABLED:
        raise TableOrderError(f'Table {table.table_number} is disabled.')

    existing = (
        TableOrder.objects.select_for_update()
        .filter(table=table, status=TableOrder.Status.OPEN)
        .first()
    )
    if existing:
        return existing

    order = TableOrder.objects.create(table=table, waiter=waiter)
    # Deliberately NOT marking the table Occupied here — an opened-but-
    # empty tab (e.g. waiter tapped the table but hasn't taken an order
    # yet) should still show as Vacant/available. _sync_table_occupancy
    # is what flips it to Occupied, the moment the first item is added.
    return order


@transaction.atomic
def add_item(table_order: TableOrder, product: MenuItem, notes: str = '', quantity: int = 1) -> TableOrderItem:
    """
    Add `quantity` units of `product` to the tab, or increment if already
    present. `quantity` defaults to 1 for the tap-to-add POS/waiter flow;
    QR self-order acceptance passes the customer's requested quantity in
    one call instead of looping.
    """
    _guard_editable(table_order)

    line, created = TableOrderItem.objects.select_for_update().get_or_create(
        table_order=table_order,
        product=product,
        defaults={
            'item_name': product.name,
            'unit_price': product.price,
            'quantity': quantity,
            'notes': notes,
        },
    )
    if not created:
        line.quantity += quantity
        if notes:
            line.notes = notes
        line.save(update_fields=['quantity', 'notes'])

    _sync_table_occupancy(table_order)
    return line


@transaction.atomic
def set_item_quantity(table_order: TableOrder, item_id: int, quantity: int) -> TableOrderItem:
    """
    Set a line's live quantity directly (used by the +/- steppers).

    A brand-new line that was never sent to the kitchen
    (confirmed_quantity == 0) is deleted outright when reduced to zero —
    there's nothing to cancel, so nothing to audit. Once it has been
    confirmed at least once, dropping it to zero keeps the row (as a
    future CANCEL entry) instead of deleting it.
    """
    _guard_editable(table_order)

    if quantity < 0:
        quantity = 0

    line = TableOrderItem.objects.select_for_update().get(pk=item_id, table_order=table_order)
    if quantity == 0 and line.confirmed_quantity == 0:
        line.delete()
        _sync_table_occupancy(table_order)
        return line

    line.quantity = quantity
    line.save(update_fields=['quantity'])
    _sync_table_occupancy(table_order)
    return line


@transaction.atomic
def set_item_notes(table_order: TableOrder, item_id: int, notes: str) -> TableOrderItem:
    _guard_editable(table_order)
    line = TableOrderItem.objects.select_for_update().get(pk=item_id, table_order=table_order)
    line.notes = notes[:200]
    line.save(update_fields=['notes'])
    return line


@transaction.atomic
def confirm_order(table_order: TableOrder, user) -> KitchenOrderTicket | None:
    """
    Diff every line's live quantity against what the kitchen was last
    told, and turn only the *net* change into a new KOT.

    Returns the new KitchenOrderTicket, or None if there was nothing to
    send (e.g. the waiter tapped Confirm with no pending changes).
    """
    _guard_editable(table_order)

    items = list(table_order.items.select_for_update().all())
    diffs = []
    for item in items:
        delta = item.quantity - item.confirmed_quantity
        if delta > 0:
            diffs.append((item, delta, KitchenOrderItem.Action.ADD))
        elif delta < 0:
            diffs.append((item, -delta, KitchenOrderItem.Action.CANCEL))

    if not diffs:
        return None

    kot = KitchenOrderTicket.objects.create(
        table_order=table_order,
        kot_number=table_order.next_kot_number,
        created_by=user,
    )
    for item, qty, action in diffs:
        KitchenOrderItem.objects.create(
            kot=kot,
            table_order_item=item,
            item_name=item.item_name,
            quantity=qty,
            action=action,
            notes=item.notes,
        )
        item.confirmed_quantity = item.quantity
        item.save(update_fields=['confirmed_quantity'])

    return kot


@transaction.atomic
def generate_invoice(table_order: TableOrder, cashier) -> Order:
    """
    Convert a table's tab into a normal POS Order covering every
    confirmed item across all of its KOTs, then hand off to the existing
    billing/payment flow.

    Any last-second unconfirmed edits are folded into a final KOT first,
    so the printed KOT history and the invoice can never disagree about
    what's being billed.
    """
    if table_order.status != TableOrder.Status.OPEN:
        raise TableOrderError('This table order has already been billed or closed.')

    confirm_order(table_order, cashier)

    active_items = list(table_order.active_items)
    if not active_items:
        raise TableOrderError('There are no items to bill for this table.')

    order = Order.objects.create(cashier=cashier)
    for item in active_items:
        OrderItem.objects.create(
            order=order,
            menu_item=item.product,
            item_name=item.item_name,
            unit_price=item.unit_price,
            quantity=item.quantity,
        )
    order.recalculate_totals()

    table_order.invoice = order
    table_order.status = TableOrder.Status.BILLED
    table_order.save(update_fields=['invoice', 'status'])

    return order


def _guard_editable(table_order: TableOrder) -> None:
    if table_order.status != TableOrder.Status.OPEN:
        raise TableOrderError('This table order is no longer open for editing.')


def _sync_table_occupancy(table_order: TableOrder) -> None:
    """
    Keep the table's floor-plan status honest: Occupied only while its
    open tab actually has items on it, Vacant the moment it doesn't.

    Only toggles between VACANT <-> OCCUPIED — a table an admin has
    explicitly marked Reserved/Cleaning/Disabled is left alone, since
    those are manual states this module shouldn't silently override.
    """
    table = table_order.table
    if table.status not in (DiningTable.Status.VACANT, DiningTable.Status.OCCUPIED):
        return

    has_items = table_order.items.filter(quantity__gt=0).exists()
    target_status = DiningTable.Status.OCCUPIED if has_items else DiningTable.Status.VACANT
    if table.status != target_status:
        table.status = target_status
        table.save(update_fields=['status'])


# ---------------------------------------------------------------------------
# Kitchen Display Screen — prep-status workflow for fired KOTs.
# ---------------------------------------------------------------------------

@transaction.atomic
def kot_mark_preparing(kot: KitchenOrderTicket) -> KitchenOrderTicket:
    kot = KitchenOrderTicket.objects.select_for_update().get(pk=kot.pk)
    kot.mark_preparing()
    return kot


@transaction.atomic
def kot_mark_completed(kot: KitchenOrderTicket) -> KitchenOrderTicket:
    kot = KitchenOrderTicket.objects.select_for_update().get(pk=kot.pk)
    kot.mark_completed()
    return kot


@transaction.atomic
def kot_mark_pending(kot: KitchenOrderTicket) -> KitchenOrderTicket:
    """Undo — send a ticket back to the New column (mis-tap recovery)."""
    kot = KitchenOrderTicket.objects.select_for_update().get(pk=kot.pk)
    kot.mark_pending()
    return kot
