from django.contrib import admin

from tables.models import (
    DiningTable,
    KitchenOrderItem,
    KitchenOrderTicket,
    TableOrder,
    TableOrderItem,
)


@admin.register(DiningTable)
class DiningTableAdmin(admin.ModelAdmin):
    list_display = ['table_number', 'name', 'capacity', 'status', 'assigned_waiter']
    list_filter = ['status']
    search_fields = ['table_number', 'name']
    list_editable = ['status', 'assigned_waiter']


class TableOrderItemInline(admin.TabularInline):
    model = TableOrderItem
    extra = 0
    readonly_fields = ['item_name', 'unit_price', 'quantity', 'confirmed_quantity', 'notes']
    can_delete = False


@admin.register(TableOrder)
class TableOrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'table', 'waiter', 'status', 'current_subtotal', 'opened_at', 'closed_at']
    list_filter = ['status', 'table']
    readonly_fields = ['invoice', 'opened_at', 'closed_at']
    inlines = [TableOrderItemInline]


class KitchenOrderItemInline(admin.TabularInline):
    model = KitchenOrderItem
    extra = 0
    readonly_fields = ['table_order_item', 'item_name', 'quantity', 'action', 'notes']
    can_delete = False


@admin.register(KitchenOrderTicket)
class KitchenOrderTicketAdmin(admin.ModelAdmin):
    list_display = ['label', 'table_order', 'status', 'prep_status', 'created_by', 'created_at']
    list_filter = ['status', 'prep_status']
    readonly_fields = ['table_order', 'kot_number', 'created_by', 'created_at', 'preparing_at', 'completed_at']
    inlines = [KitchenOrderItemInline]
