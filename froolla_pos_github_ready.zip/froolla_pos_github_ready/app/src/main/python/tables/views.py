"""
Tables app views.

    TableGridView          floor plan — every role lands here
    TableOpenView           POST: open/resume a table's tab
    TableOrderDetailView    the waiter/cashier ordering screen for one tab
    order_add_item / order_update_quantity / order_set_note   AJAX cart edits
    order_confirm            AJAX: turn pending edits into a new KOT
    order_generate_invoice   POST: convert tab -> billing.Order, hand off to payment
    KotPrintView             printable KOT slip (also used for reprints)
"""

from datetime import timedelta

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.staticfiles import finders
from django.db.models import Prefetch
from django.http import Http404, HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views import View
from django.views.decorators.http import require_POST
from django.views.generic import DetailView, TemplateView

from menu.models import Category, MenuItem
from tables import services
from tables.models import DiningTable, KitchenOrderTicket, TableOrder, TableOrderItem
from tables.permissions import can_bill, role_label


class TableGridView(LoginRequiredMixin, TemplateView):
    """Floor-plan view: colored table cards, the landing page for the module."""

    template_name = 'tables/table_grid.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tables = (
            DiningTable.objects.all()
            .select_related('assigned_waiter')
            .prefetch_related('orders__items', 'orders__waiter')
        )
        context.update({
            'tables': tables,
            'can_bill': can_bill(self.request.user),
            'role_label': role_label(self.request.user),
        })
        return context


class TableOpenView(LoginRequiredMixin, View):
    """Open (or resume) a table's tab, then jump to the ordering screen."""

    def post(self, request: HttpRequest, pk: int):
        table = get_object_or_404(DiningTable, pk=pk)
        try:
            table_order = services.open_table(table, request.user)
        except services.TableOrderError as exc:
            return redirect(f"{reverse('tables:grid')}?error={exc}")
        return redirect('tables:order_detail', pk=table_order.pk)


class TableOrderDetailView(LoginRequiredMixin, DetailView):
    """
    The main waiter/cashier screen for one table's tab: product grid on
    one side, live order + KOT history on the other. Mirrors the POS
    screen's layout so the module feels native to the rest of the app.
    """

    model = TableOrder
    template_name = 'tables/table_order.html'
    context_object_name = 'table_order'

    def get_queryset(self):
        return TableOrder.objects.select_related('table', 'waiter').prefetch_related(
            'items', 'kots__items'
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        categories = Category.objects.filter(is_active=True).prefetch_related(
            Prefetch(
                'items',
                queryset=MenuItem.objects.filter(is_active=True),
                to_attr='active_items',
            )
        )
        categories = [c for c in categories if c.active_items]

        context.update({
            'categories': categories,
            'can_bill': can_bill(self.request.user),
            'can_edit': self.object.status == TableOrder.Status.OPEN,
            'role_label': role_label(self.request.user),
        })
        return context


@require_POST
def order_add_item(request: HttpRequest, pk: int) -> JsonResponse:
    table_order = get_object_or_404(TableOrder, pk=pk)
    item_id = request.POST.get('item_id')
    notes = request.POST.get('notes', '')
    product = get_object_or_404(MenuItem, pk=item_id, is_active=True)

    try:
        services.add_item(table_order, product, notes=notes)
    except services.TableOrderError as exc:
        return JsonResponse({'error': str(exc)}, status=400)

    return JsonResponse(_order_payload(table_order))


@require_POST
def order_update_quantity(request: HttpRequest, pk: int) -> JsonResponse:
    table_order = get_object_or_404(TableOrder, pk=pk)
    line_id = request.POST.get('line_id')
    delta = request.POST.get('delta')

    try:
        delta = int(delta)
    except (TypeError, ValueError):
        return JsonResponse({'error': 'Invalid delta.'}, status=400)

    line = get_object_or_404(TableOrderItem, pk=line_id, table_order=table_order)
    new_quantity = max(0, line.quantity + delta)

    try:
        services.set_item_quantity(table_order, line.pk, new_quantity)
    except services.TableOrderError as exc:
        return JsonResponse({'error': str(exc)}, status=400)

    return JsonResponse(_order_payload(table_order))


@require_POST
def order_set_note(request: HttpRequest, pk: int) -> JsonResponse:
    table_order = get_object_or_404(TableOrder, pk=pk)
    line_id = request.POST.get('line_id')
    notes = request.POST.get('notes', '')

    try:
        services.set_item_notes(table_order, line_id, notes)
    except services.TableOrderError as exc:
        return JsonResponse({'error': str(exc)}, status=400)

    return JsonResponse(_order_payload(table_order))


@require_POST
def order_confirm(request: HttpRequest, pk: int) -> JsonResponse:
    """Turn any pending +/- edits into a new KOT and (browser-)print it."""
    table_order = get_object_or_404(TableOrder, pk=pk)

    try:
        kot = services.confirm_order(table_order, request.user)
    except services.TableOrderError as exc:
        return JsonResponse({'error': str(exc)}, status=400)

    payload = _order_payload(table_order)
    payload['kot_created'] = kot is not None
    if kot:
        payload['kot_print_url'] = reverse('tables:kot_print', args=[kot.pk]) + '?autoprint=1'
    return JsonResponse(payload)


class TableOrderInvoiceView(LoginRequiredMixin, View):
    """Convert the tab into a billing.Order and hand off to Payment."""

    def post(self, request: HttpRequest, pk: int):
        table_order = get_object_or_404(TableOrder, pk=pk)

        if not can_bill(request.user):
            return redirect('tables:order_detail', pk=table_order.pk)

        try:
            order = services.generate_invoice(table_order, request.user)
        except services.TableOrderError as exc:
            return redirect(f"{reverse('tables:order_detail', args=[table_order.pk])}?error={exc}")

        # Hand off into the existing billing flow exactly like a normal
        # POS cart — the cashier lands on the same Payment screen used
        # for walk-in bills.
        request.session['current_order_id'] = order.pk
        return redirect('billing:payment')


class ServiceWorkerView(View):
    """
    Serves the PWA service worker at /tables/sw.js instead of its static
    path under /static/pwa/. A service worker can only control pages at
    or below the URL path it's served from (its "scope") unless the
    server sends a Service-Worker-Allowed header — serving it here, right
    at the top of /tables/, is the simplest way to let it control the
    whole staff app without needing that extra header.
    """

    def get(self, request: HttpRequest):
        path = finders.find('pwa/sw.js')
        if not path:
            raise Http404('Service worker not found.')
        with open(path, 'rb') as f:
            content = f.read()
        return HttpResponse(content, content_type='application/javascript')


class KotPrintView(LoginRequiredMixin, DetailView):
    """Printable kitchen slip — used both for the first print and reprints."""

    model = KitchenOrderTicket
    template_name = 'tables/kot_print.html'
    context_object_name = 'kot'

    def get_queryset(self):
        return KitchenOrderTicket.objects.select_related('table_order__table', 'created_by').prefetch_related('items')


# ---------------------------------------------------------------------------
# Kitchen Display Screen (KDS) — a live board of fired KOTs for kitchen
# staff to work from, grouped into New / Preparing / Completed columns.
# ---------------------------------------------------------------------------

# How long a completed ticket stays visible on the board before it drops
# off entirely (it's still in the database/KOT history either way — this
# only controls what the live board bothers showing).
KITCHEN_BOARD_COMPLETED_WINDOW = timedelta(hours=2)


def _kitchen_board_context() -> dict:
    """Shared queryset/grouping logic for the full page and every partial refresh."""
    active_tickets = (
        KitchenOrderTicket.objects.filter(
            status=KitchenOrderTicket.Status.PRINTED,
            table_order__status=TableOrder.Status.OPEN,
        )
        .select_related('table_order__table')
        .prefetch_related('items')
    )

    completed_cutoff = timezone.now() - KITCHEN_BOARD_COMPLETED_WINDOW

    return {
        # Oldest first within New/Preparing — the kitchen works tickets
        # in the order they came in (first in, first cooked).
        'new_tickets': active_tickets.filter(
            prep_status=KitchenOrderTicket.PrepStatus.PENDING
        ).order_by('created_at'),
        'preparing_tickets': active_tickets.filter(
            prep_status=KitchenOrderTicket.PrepStatus.PREPARING
        ).order_by('preparing_at', 'created_at'),
        # Most-recently-finished first, so the kitchen can see what they
        # just sent out; old completions quietly drop off the board.
        'completed_tickets': active_tickets.filter(
            prep_status=KitchenOrderTicket.PrepStatus.COMPLETED,
            completed_at__gte=completed_cutoff,
        ).order_by('-completed_at'),
    }


class KitchenDisplayView(LoginRequiredMixin, TemplateView):
    """Full-page Kitchen Display Screen — New / Preparing / Completed board."""

    template_name = 'tables/kitchen_display.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(_kitchen_board_context())
        context['role_label'] = role_label(self.request.user)
        return context


class KitchenDisplayBoardView(LoginRequiredMixin, TemplateView):
    """
    Just the board markup (no page chrome) — fetched on a timer by the
    page's own JS to keep every kitchen screen in sync, and reused as the
    response for the mark-preparing/completed/undo actions below so a tap
    updates instantly without waiting for the next poll.
    """

    template_name = 'tables/_kitchen_board.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(_kitchen_board_context())
        return context


def _kitchen_board_response(request: HttpRequest) -> HttpResponse:
    return render(request, 'tables/_kitchen_board.html', _kitchen_board_context())


@require_POST
def kot_mark_preparing(request: HttpRequest, pk: int) -> HttpResponse:
    kot = get_object_or_404(KitchenOrderTicket, pk=pk)
    services.kot_mark_preparing(kot)
    return _kitchen_board_response(request)


@require_POST
def kot_mark_completed(request: HttpRequest, pk: int) -> HttpResponse:
    kot = get_object_or_404(KitchenOrderTicket, pk=pk)
    services.kot_mark_completed(kot)
    return _kitchen_board_response(request)


@require_POST
def kot_mark_pending(request: HttpRequest, pk: int) -> HttpResponse:
    kot = get_object_or_404(KitchenOrderTicket, pk=pk)
    services.kot_mark_pending(kot)
    return _kitchen_board_response(request)


def _order_payload(table_order: TableOrder) -> dict:
    """Shared JSON shape for every AJAX cart-mutation endpoint on a tab."""
    lines = [
        {
            'line_id': item.pk,
            'name': item.item_name,
            'unit_price': str(item.unit_price),
            'quantity': item.quantity,
            'confirmed_quantity': item.confirmed_quantity,
            'is_pending': item.is_pending,
            'notes': item.notes,
            'line_total': str(item.line_total),
        }
        for item in table_order.items.filter(quantity__gt=0).select_related('product')
    ]
    return {
        'table_order_id': table_order.pk,
        'items': lines,
        'subtotal': str(table_order.current_subtotal),
        'has_pending_changes': table_order.has_pending_changes,
    }
