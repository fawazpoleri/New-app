"""
Closes the loop between billing and table management.

billing.Order knows nothing about tables (kept decoupled on purpose — the
POS must keep working even if this app is ever disabled). Instead, this
app listens for any Order being saved as PAID and, if it happens to be
linked to a TableOrder, flips that TableOrder to PAID and frees the table.
"""

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from billing.models import Order
from tables.models import DiningTable, TableOrder


@receiver(post_save, sender=Order)
def close_table_on_payment(sender, instance: Order, **kwargs):
    if instance.status != Order.Status.PAID:
        return

    table_order = TableOrder.objects.filter(invoice=instance).exclude(
        status=TableOrder.Status.PAID
    ).select_related('table').first()
    if table_order is None:
        return

    table_order.status = TableOrder.Status.PAID
    table_order.closed_at = timezone.now()
    table_order.save(update_fields=['status', 'closed_at'])

    table = table_order.table
    if table.status != DiningTable.Status.VACANT:
        table.status = DiningTable.Status.VACANT
        table.save(update_fields=['status'])
