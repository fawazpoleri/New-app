# Froolla POS

A fast, touch-friendly Point of Sale system for a cafe, juice shop, coffee
shop, bakery, or small restaurant — billing, receipts, and dine-in tables
with kitchen tickets (KOT). Built with Django, runs standalone on a
Windows PC, no internet required for daily use.

This guide assumes no prior experience. Follow it top to bottom and you'll
end up with the POS running automatically in the background on a shop PC,
backed by PostgreSQL, restarting itself if the PC reboots or it crashes.

**New here? Read this first:**
- If you just want to try the app on your own laptop → **[Part 1: Quick Try-Out](#part-1--quick-try-out-5-minutes)**
- If you're setting it up for real, permanent use on a shop PC → skip to **[Part 2: Real Setup for a Shop PC](#part-2--real-setup-for-a-shop-pc-postgresql--auto-start-service)**

---

## Part 1 — Quick Try-Out (5 minutes)

This runs the app with zero setup, using a simple built-in database
(SQLite). Good for trying it out on your own computer. **Don't use this
method for real daily business use** — see Part 2 for that.

1. Install [Python 3.11 or newer](https://www.python.org/downloads/) if
   you don't have it. On the Windows installer, tick **"Add python.exe to
   PATH"** before clicking Install.
2. Open a Command Prompt in the project folder (right-click the folder →
   "Open in Terminal", or `cd` into it) and run:
   ```bat
   python -m venv venv
   venv\Scripts\pip install -r requirements.txt
   venv\Scripts\python manage.py migrate
   venv\Scripts\python manage.py createsuperuser
   venv\Scripts\python manage.py runserver
   ```
3. Open `http://127.0.0.1:8000/` in your browser and log in with the
   admin account you just created.

That's it. When you're ready to set this up properly on the shop's actual
till PC, continue to Part 2 below — it uses the same project folder, so
nothing you did here is wasted.

---

## Part 2 — Real Setup for a Shop PC (PostgreSQL + auto-start service)

This is the setup you want for actual daily use: a real database
(PostgreSQL), running as a Windows background service so it starts
automatically when the PC turns on and restarts itself if it ever
crashes — no one has to remember to open anything.

You'll do this once, on the PC that will act as the till.

### Step 1 — Install Python

Download and install [Python 3.11+](https://www.python.org/downloads/).
On the installer's first screen, **tick "Add python.exe to PATH"** — this
is important, don't skip it.

### Step 2 — Install PostgreSQL

1. Download the Windows installer from
   [postgresql.org/download](https://www.postgresql.org/download/windows/)
   and run it. It includes **pgAdmin**, a tool for managing the database
   with a UI, which you don't strictly need but is handy.
2. During install, you'll be asked to set a password for the `postgres`
   superuser — write this down somewhere safe.
3. Leave the port as the default (`5432`).
4. After installing, open **pgAdmin** (or use the "SQL Shell (psql)"
   app that comes with PostgreSQL) and run:
   ```sql
   CREATE DATABASE froolla_pos;
   CREATE USER froolla_pos WITH PASSWORD 'choose-a-strong-password-here';
   GRANT ALL PRIVILEGES ON DATABASE froolla_pos TO froolla_pos;
   ```
   Then, connected to the `froolla_pos` database specifically (in
   pgAdmin, click into it first; in psql, run `\c froolla_pos`), run one
   more line — needed on newer PostgreSQL versions:
   ```sql
   GRANT ALL ON SCHEMA public TO froolla_pos;
   ```
5. Remember the username and password you just created — you'll need
   them in Step 4.

### Step 3 — Get the project onto the PC and install dependencies

Copy this whole project folder onto the till PC (USB stick, network
share, however's convenient). Then open a Command Prompt **inside the
project folder** and run:

```bat
python -m venv venv
venv\Scripts\pip install -r requirements.txt
venv\Scripts\pip install -r requirements-build.txt
```

### Step 4 — Configure the app (the `.env` file)

1. Make a copy of `.env.example` and name it `.env` (same folder):
   ```bat
   copy .env.example .env
   ```
2. Open `.env` in Notepad and fill in:
   - **`DJANGO_SECRET_KEY`** — a random secret string. Generate one with:
     ```bat
     venv\Scripts\python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
     ```
     Copy the output into `.env`.
   - **`DB_ENGINE=postgres`** — already set by default.
   - **`DB_NAME`**, **`DB_USER`**, **`DB_PASSWORD`** — the database name
     and user you created in Step 2 (`froolla_pos` / `froolla_pos` /
     the password you chose).
   - **`DB_HOST`** — leave as `localhost` if PostgreSQL is on this same
     PC (the normal setup).
3. Save and close the file.

### Step 5 — First run and create your admin account

```bat
venv\Scripts\python run_pos.py
```

This sets up the database tables and starts the app. Visit
`http://localhost:8000/` in a browser to confirm you see the login page,
then press `Ctrl+C` in the Command Prompt to stop it.

Now create your admin (owner/manager) login — this is a one-time step:

```bat
venv\Scripts\python manage.py createsuperuser
```

Follow the prompts to set a username and password.

### Step 6 — Build the standalone app (recommended)

This packages everything into a single `FroollaPOS.exe` folder that
doesn't need Python installed to run — cleaner and more reliable for the
Windows service in the next step.

```bat
build.bat
```

When it finishes, you'll have a new folder: `dist\FroollaPOS\` containing
`FroollaPOS.exe`. Copy your `.env` file into that folder:

```bat
copy .env dist\FroollaPOS\.env
```

Test it once by double-clicking `dist\FroollaPOS\FroollaPOS.exe` (or
running it from a Command Prompt) — you should see it print "Starting
Froolla POS on http://0.0.0.0:8000". Visit `http://localhost:8000/`
to confirm, then close the window.

> **Prefer not to build an .exe?** You can skip this step and instead
> run `venv\Scripts\python run_pos.py` directly in Step 7's NSSM setup —
> just point NSSM at `venv\Scripts\python.exe` with the argument
> `run_pos.py` and the startup directory set to the project folder. The
> built .exe is recommended because it's simpler to manage and doesn't
> depend on the venv staying in place.

### Step 7 — Install as an always-on Windows service (NSSM)

This makes the app start automatically when the PC boots, and restart
itself automatically if it ever crashes — no one needs to open anything
manually, ever.

1. Download NSSM from [nssm.cc/download](https://nssm.cc/download) and
   unzip it anywhere (e.g. `C:\nssm`).
2. Right-click **Command Prompt** in the Start Menu → **Run as
   administrator**. (This step requires admin rights.)
3. In that admin Command Prompt, run:
   ```bat
   cd C:\nssm\win64
   nssm install FroollaPOS
   ```
4. A small window pops up. Fill in:
   - **Application tab**
     - Path: the full path to `FroollaPOS.exe`, e.g.
       `C:\FroollaPOS\dist\FroollaPOS\FroollaPOS.exe`
     - Startup directory: the folder it's in, e.g.
       `C:\FroollaPOS\dist\FroollaPOS\`
     - Arguments: leave empty
   - **Details tab**
     - Display name: `Froolla POS`
     - Startup type: `Automatic` (so it starts on every boot)
   - Leave the other tabs as default.
5. Click **Install service**.
6. Start it:
   ```bat
   nssm start FroollaPOS
   ```
7. Visit `http://localhost:8000/` to confirm it's running.

**Handy commands** (from an admin Command Prompt, same NSSM folder):
```bat
nssm status FroollaPOS      REM check if it's running
nssm stop FroollaPOS
nssm start FroollaPOS
nssm restart FroollaPOS
nssm edit FroollaPOS        REM reopen the settings window
nssm remove FroollaPOS      REM uninstall the service
```

The app writes its own log file to `logs\pos.log` next to the .exe, so
if something looks wrong, check there first.

### Step 8 — Let other devices on the shop WiFi reach it

If you'll use a second screen or tablet as an additional waiter/cashier
station, other devices need to reach this PC over the network:

1. **Give this PC a fixed IP address.** Either set a static IP, or add a
   "DHCP reservation" for it in your WiFi router's settings (search
   "DHCP reservation" plus your router's model name for instructions).
   Without this, the PC's IP can change after a reboot and break
   everything that points at it. Find the current IP by running
   `ipconfig` in Command Prompt and looking for "IPv4 Address".
2. **Allow the app through Windows Firewall.** The first time something
   tries to connect, Windows will pop up a prompt — click **Allow
   access** (for Private networks). If you don't see the prompt, add a
   rule manually: Windows Defender Firewall → Advanced settings →
   Inbound Rules → New Rule → Port → TCP → `8000` → Allow.
3. From another device on the same WiFi, visit
   `http://<this-PC's-IP>:8000/` — e.g. `http://192.168.1.50:8000/`.

### Step 9 — Back up your data regularly

With PostgreSQL, back up the database itself (not a file), e.g. once a
day via Windows Task Scheduler:

```bat
pg_dump -U froolla_pos -h localhost froolla_pos > backup.sql
```

Also keep a copy of your `.env` file somewhere safe — it has your
database password and secret key, and isn't stored anywhere else.

### Updating to a new version later

1. `nssm stop FroollaPOS`
2. Replace the contents of `dist\FroollaPOS\` with the new build, **but
   keep your existing `.env` file** — don't overwrite it.
3. `nssm start FroollaPOS`

Database changes are applied automatically every time the app starts, so
there's no separate "migrate" step to remember.

---

## Part 3 — Using the App (day to day)

### Setting up cashier and waiter accounts

The quickest way, from a Command Prompt in the project folder:

```bat
venv\Scripts\python manage.py create_staff_user <username> --role cashier
```

Use `--role waiter` or `--role admin` instead of `cashier` as needed.
Leave off `--password` to be prompted for one instead of typing it on
the command line.

Roles:
- **Cashier** — full POS access: billing, payment, bill history.
- **Waiter** — can open tables and send kitchen tickets (KOT), but can't
  take payments or see bill history.
- **Admin** (`is_staff`) — everything, plus the Django Admin panel
  (accessible via the **Admin** link in the top navigation) for managing
  the menu, restaurant profile, and users.

You can also create users by hand in Django Admin (**Authentication and
Authorization → Users → Add user**) — leave "Staff status" unchecked to
keep someone limited to just the POS.

### Setting up your restaurant profile

**Django Admin → Restaurant Settings** — fill in name, address, phone,
receipt footer text, and tax %. This appears on the dashboard and every
printed receipt. There's only ever one of these.

### Managing the menu

**Django Admin → Categories** and **Menu Items**. No separate menu-editor
screen — Admin's built-in list/edit forms are fast enough for occasional
changes. Set a **display order** on categories to control the left-rail
order on the POS screen; untick **active** to hide an item without
deleting it (old receipts keep showing the original name/price either
way).

### Taking an order and getting paid

1. Log in → **Dashboard** → **Open POS**.
2. Tap products to add them to the cart (updates instantly, no page
   reload). Adjust quantity, remove items, or apply a flat discount.
3. Tap **Payment** → choose Cash, Card, UPI, or **Mixed** (split across
   more than one method) → **Confirm Payment**.
4. The printable receipt opens automatically, sized for a 58mm thermal
   printer. Just `Ctrl+P` (or the in-app Print button) — no special
   printer driver needed. (For an 80mm printer, edit the `@page` size in
   `static/css/receipt.css`.)
5. **Bill History** lists today's paid bills, searchable by bill number,
   with reprint/reopen.

### Dine-in tables and kitchen tickets (KOT)

`/tables/` shows a floor plan. Waiters open a table, add items, and tap
**Confirm Order** to print a KOT (only the new items since the last
ticket — never duplicates what the kitchen already has). Repeat for more
rounds as the table orders more. **Generate Invoice** turns everything
confirmed so far into a normal bill and hands off to the Payment screen;
once paid, the table frees up automatically.

### Installing the staff app on a phone (PWA)

Opening `/tables/` in Chrome on a waiter's Android phone shows an
**Install App** button — tapping it adds a home-screen icon that opens
full-screen like a native app. Nothing extra to build; it's on by
default.

---

## Troubleshooting

- **"Database is locked" or similar** — you're likely still on SQLite
  (`DB_ENGINE=sqlite`) with more than one person using the till at once.
  Switch to PostgreSQL (Part 2, Step 2 & 4).
- **Service won't start** — check `logs\pos.log` next to `FroollaPOS.exe`
  for the error, and confirm `.env` is in the same folder as the `.exe`
  with correct database credentials.
- **Forgot the database password** — reset it in pgAdmin (right-click the
  `froolla_pos` role → Properties → Definition), then update `.env` and
  restart the service (`nssm restart FroollaPOS`).

---

## Project layout

```
cafepos/        Project settings, root urls
core/           Dashboard, RestaurantSetting (singleton), admin branding
accounts/       Login / logout
menu/           Category, MenuItem — managed via Django Admin
billing/        POS screen, cart, payment, receipt, bill history
payments/       Payment records (supports mixed/split payments)
cashbook/       Cash drawer / day-close ledger
tables/         Dine-in tables & kitchen tickets (KOT)
reports/        Reserved for future reporting features
templates/      HTML templates, organized by app
static/         CSS, JS, self-hosted fonts/icons (no external CDN calls)
run_pos.py      Production entry point (used by the built .exe)
froolla_pos.spec  PyInstaller build spec
build.bat       Builds dist\FroollaPOS\FroollaPOS.exe
```

Stack: Python 3.11+ / Django 5.x, PostgreSQL (or SQLite for quick
try-outs), Waitress as the production web server, plain CSS/JS with no
frontend framework or build step.
