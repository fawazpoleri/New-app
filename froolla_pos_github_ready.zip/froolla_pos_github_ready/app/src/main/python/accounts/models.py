"""
Accounts app models.

Phase 1 intentionally has NO custom User model. Django's built-in
`auth.User` is used directly, with role distinction handled through:

- `is_superuser` / `is_staff`  -> Admin (full Django Admin access)
- Membership in the "Cashier" Group -> Cashier (POS access only)

This keeps auth simple and avoids the migration complexity of swapping
AUTH_USER_MODEL mid-project. If a richer profile (e.g. PIN codes, shift
tracking) is needed in a later phase, extend with a OneToOne profile model
here without touching this app's existing views.
"""
