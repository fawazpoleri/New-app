"""
Accounts app views.

Thin wrappers around Django's built-in auth views, customized only to
point at our own templates and post-login/logout redirects.
"""

from django.contrib.auth.views import LoginView as DjangoLoginView
from django.contrib.auth.views import LogoutView as DjangoLogoutView


class LoginView(DjangoLoginView):
    """Login screen for both Admin and Cashier users."""

    template_name = 'accounts/login.html'
    redirect_authenticated_user = True


class LogoutView(DjangoLogoutView):
    """Logs the user out and returns them to the login screen."""
    pass
