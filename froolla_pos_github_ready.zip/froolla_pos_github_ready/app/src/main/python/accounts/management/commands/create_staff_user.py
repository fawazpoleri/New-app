"""
Create (or update) a staff login from the command line, instead of going
through Django Admin by hand. Useful for first-time setup and for
scripting a fresh install.

    python manage.py create_staff_user priya --role waiter
    python manage.py create_staff_user arun  --role cashier
    python manage.py create_staff_user admin --role admin
    python manage.py create_staff_user cook1 --role kitchen

Roles (see tables/permissions.py for the single source of truth):

    admin   -> is_staff=True. Full access: Dashboard, Reports, Cash Book,
               Django Admin, POS billing, tables, QR orders.
    cashier -> is_staff=False, not in the Waiter/Kitchen groups. POS
               billing + everything a Waiter can do. This is the default
               for any authenticated user who isn't Admin, Waiter, or
               Kitchen.
    waiter  -> is_staff=False, member of the "Waiter" group. Can open
               tables, take orders, and fire KOTs (table service + QR
               order review/accept/reject + KOT printing) but is blocked
               from the POS billing screen, payment, and bill history.
    kitchen -> is_staff=False, member of the "Kitchen" group. Only
               access is the Kitchen Display Screen (view fired KOTs,
               mark Preparing/Completed) — blocked from POS billing,
               payment, and bill history, same as Waiter.

Password is never taken as a plain CLI arg by default (it would land in
shell history / process listings) — pass --password only for scripted,
non-interactive installs where that trade-off is acceptable; otherwise
leave it out and this prompts with hidden input.
"""

import getpass

from django.contrib.auth.models import Group, User
from django.core.management.base import BaseCommand, CommandError

from tables.permissions import KITCHEN_GROUP_NAME, WAITER_GROUP_NAME

ROLES = ('admin', 'cashier', 'waiter', 'kitchen')


class Command(BaseCommand):
    help = 'Create or update a staff login with a role: admin, cashier, waiter, or kitchen.'

    def add_arguments(self, parser):
        parser.add_argument('username')
        parser.add_argument(
            '--role', choices=ROLES, default='waiter',
            help='Access level to grant (default: waiter).',
        )
        parser.add_argument(
            '--password', default=None,
            help='Plaintext password (avoid in shared shells — omit to be prompted instead).',
        )
        parser.add_argument('--first-name', default='', help='Optional display name.')

    def handle(self, *args, **options):
        username = options['username'].strip()
        if not username:
            raise CommandError('Username cannot be empty.')

        role = options['role']
        password = options['password']
        if not password:
            password = getpass.getpass(f'Password for "{username}": ')
            confirm = getpass.getpass('Confirm password: ')
            if password != confirm:
                raise CommandError('Passwords did not match — nothing was changed.')
        if not password:
            raise CommandError('Password cannot be empty.')

        user, created = User.objects.get_or_create(username=username)
        user.set_password(password)
        user.first_name = options['first_name']
        user.is_active = True
        user.is_staff = (role == 'admin')
        # Staff users manage everything through Django Admin's own
        # permission system already (is_staff); this command only ever
        # creates day-to-day operational logins, never a superuser.
        user.is_superuser = False
        user.save()

        waiter_group, _ = Group.objects.get_or_create(name=WAITER_GROUP_NAME)
        kitchen_group, _ = Group.objects.get_or_create(name=KITCHEN_GROUP_NAME)

        if role == 'waiter':
            user.groups.add(waiter_group)
        else:
            user.groups.remove(waiter_group)

        if role == 'kitchen':
            user.groups.add(kitchen_group)
        else:
            user.groups.remove(kitchen_group)

        verb = 'Created' if created else 'Updated'
        self.stdout.write(self.style.SUCCESS(
            f'{verb} user "{username}" as {role.capitalize()}.'
        ))
        if role == 'waiter':
            self.stdout.write(
                'Waiter access: Tables, QR Orders, KOT printing. '
                'No POS billing, payment, or bill history.'
            )
        elif role == 'kitchen':
            self.stdout.write(
                'Kitchen access: Kitchen Display Screen only. '
                'No POS billing, payment, or bill history.'
            )
