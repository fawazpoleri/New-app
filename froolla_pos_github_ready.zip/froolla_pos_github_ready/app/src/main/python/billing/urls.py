"""
URL routes for the billing app: POS screen, cart AJAX endpoints, payment,
receipt, and bill history.
"""

from django.urls import path

from billing import views

app_name = 'billing'

urlpatterns = [
    path('pos/', views.POSView.as_view(), name='pos'),
    path('pos/new-bill/', views.NewBillView.as_view(), name='new_bill'),

    # Cart AJAX endpoints
    path('pos/cart/add/', views.cart_add_item, name='cart_add_item'),
    path('pos/cart/update-quantity/', views.cart_update_quantity, name='cart_update_quantity'),
    path('pos/cart/remove/', views.cart_remove_item, name='cart_remove_item'),
    path('pos/cart/clear/', views.cart_clear, name='cart_clear'),
    path('pos/cart/discount/', views.cart_apply_discount, name='cart_apply_discount'),

    path('pos/payment/', views.PaymentView.as_view(), name='payment'),
    path('receipt/<int:pk>/', views.ReceiptView.as_view(), name='receipt'),
    path('kot/<int:pk>/print/', views.KotPrintView.as_view(), name='kot_print'),

    path('history/', views.BillHistoryView.as_view(), name='bill_history'),
]
