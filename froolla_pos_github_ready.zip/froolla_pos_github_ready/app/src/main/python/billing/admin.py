"""
Admin configuration for the billing app.

Orders are shown here primarily so Admin users can browse "Sales" inside
Django Admin per the spec. Orders/OrderItems are not meant to be created
or edited from the admin — they're produced exclusively through the POS
flow — so add/change permissions are disabled, leaving only viewing.
"""

from django.contrib import admin

from billing.models import Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('menu_item', 'item_name', 'unit_price', 'quantity', 'line_total')
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('bill_number', 'cashier', 'status', 'grand_total', 'created_at', 'paid_at')
    list_filter = ('status', 'cashier')
    search_fields = ('bill_number',)
    date_hierarchy = 'created_at'
    inlines = [OrderItemInline]
    readonly_fields = (
        'bill_number', 'cashier', 'status', 'subtotal',
        'discount_amount', 'tax_amount', 'grand_total', 'created_at', 'paid_at',
    )

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
