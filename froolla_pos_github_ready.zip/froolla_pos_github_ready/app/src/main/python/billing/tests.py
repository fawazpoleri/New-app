"""
Billing app tests — the highest-risk area of the POS since it's directly
handling money. Covers:

  - Order total math in both GST-inclusive and legacy exclusive-tax modes
  - Discount clamping (can never exceed subtotal)
  - Split/mixed payments and change-due handling
  - net_applied_payments() never counting change as revenue
  - Sequential bill numbering, including the concurrent-collision retry path
"""

from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase

from billing.models import Order, OrderItem
from core.models import RestaurantSetting
from menu.models import Category, MenuItem
from payments.models import Payment


class BillingTestBase(TestCase):
    def setUp(self):
        self.cashier = User.objects.create_user('cashier1', password='x')
        self.category = Category.objects.create(name='Juices')
        self.item_a = MenuItem.objects.create(category=self.category, name='Mango Juice', price=Decimal('100.00'))
        self.item_b = MenuItem.objects.create(category=self.category, name='Orange Juice', price=Decimal('50.00'))

    def make_order(self):
        return Order.objects.create(cashier=self.cashier)

    def add_line(self, order, item, qty=1):
        return OrderItem.objects.create(
            order=order, menu_item=item, item_name=item.name, unit_price=item.price, quantity=qty,
        )


class LegacyTaxModeTests(BillingTestBase):
    """RestaurantSetting.gst_enabled = False (tax added on top)."""

    def setUp(self):
        super().setUp()
        settings_ = RestaurantSetting.get_solo()
        settings_.gst_enabled = False
        settings_.tax_percent = Decimal('10.00')
        settings_.save()

    def test_subtotal_and_tax_added_on_top(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=2)  # 200.00
        order.recalculate_totals()

        self.assertEqual(order.subtotal, Decimal('200.00'))
        self.assertEqual(order.tax_amount, Decimal('20.00'))  # 10% of 200
        self.assertEqual(order.grand_total, Decimal('220.00'))

    def test_discount_reduces_taxable_base(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.discount_amount = Decimal('20.00')
        order.save(update_fields=['discount_amount'])
        order.recalculate_totals()

        # net = 80, tax = 8 (10% of 80), grand_total = 88
        self.assertEqual(order.tax_amount, Decimal('8.00'))
        self.assertEqual(order.grand_total, Decimal('88.00'))

    def test_discount_can_never_exceed_subtotal(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.discount_amount = Decimal('500.00')  # absurd discount
        order.save(update_fields=['discount_amount'])
        order.recalculate_totals()

        self.assertEqual(order.discount_amount, Decimal('100.00'))  # clamped
        self.assertEqual(order.tax_amount, Decimal('0.00'))
        self.assertEqual(order.grand_total, Decimal('0.00'))

    def test_empty_order_totals_are_zero(self):
        order = self.make_order()
        order.recalculate_totals()
        self.assertEqual(order.subtotal, Decimal('0.00'))
        self.assertEqual(order.grand_total, Decimal('0.00'))


class GSTModeTests(BillingTestBase):
    """RestaurantSetting.gst_enabled = True (tax extracted from an inclusive price)."""

    def setUp(self):
        super().setUp()
        settings_ = RestaurantSetting.get_solo()
        settings_.gst_enabled = True
        settings_.gst_percent = Decimal('5.00')
        settings_.save()

    def test_grand_total_equals_net_amount_gst_inclusive(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00 inclusive of 5% GST
        order.recalculate_totals()

        # taxable_value = 100 / 1.05 = 95.24 (rounded), tax = 100 - 95.24 = 4.76
        self.assertEqual(order.grand_total, Decimal('100.00'))  # unchanged by tax
        self.assertEqual(order.tax_amount, Decimal('4.76'))

    def test_cgst_sgst_split_sums_to_tax_amount(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)
        order.recalculate_totals()

        self.assertEqual(order.cgst_amount + order.sgst_amount, order.tax_amount)
        # Split should be as even as possible
        self.assertLessEqual(abs(order.cgst_amount - order.sgst_amount), Decimal('0.01'))

    def test_taxable_value_property(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)
        order.recalculate_totals()
        self.assertEqual(order.taxable_value, order.grand_total - order.tax_amount)

    def test_gst_with_discount(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=2)  # 200.00
        order.discount_amount = Decimal('50.00')
        order.save(update_fields=['discount_amount'])
        order.recalculate_totals()

        # net = 150, grand_total should equal net (GST inclusive, no add-on)
        self.assertEqual(order.grand_total, Decimal('150.00'))


class PaymentAndChangeTests(BillingTestBase):
    def setUp(self):
        super().setUp()
        settings_ = RestaurantSetting.get_solo()
        settings_.gst_enabled = False
        settings_.tax_percent = Decimal('0.00')
        settings_.save()

    def test_exact_single_cash_payment(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.recalculate_totals()

        Payment.objects.create(order=order, method=Payment.Method.CASH, amount=Decimal('100.00'))

        self.assertEqual(order.total_paid, Decimal('100.00'))
        self.assertEqual(order.balance_due, Decimal('0.00'))
        self.assertEqual(order.change_due, Decimal('0.00'))

    def test_cash_overpayment_produces_change_and_is_not_double_counted(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.recalculate_totals()

        Payment.objects.create(order=order, method=Payment.Method.CASH, amount=Decimal('150.00'))

        self.assertEqual(order.change_due, Decimal('50.00'))
        # net_applied_payments must only credit 100, not the full 150 tendered
        totals = order.net_payment_totals_by_method()
        self.assertEqual(totals[Payment.Method.CASH], Decimal('100.00'))

    def test_split_mixed_payment_cash_and_card(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.recalculate_totals()

        Payment.objects.create(order=order, method=Payment.Method.CASH, amount=Decimal('40.00'))
        Payment.objects.create(order=order, method=Payment.Method.CARD, amount=Decimal('60.00'))

        self.assertEqual(order.total_paid, Decimal('100.00'))
        self.assertEqual(order.balance_due, Decimal('0.00'))
        totals = order.net_payment_totals_by_method()
        self.assertEqual(totals[Payment.Method.CASH], Decimal('40.00'))
        self.assertEqual(totals[Payment.Method.CARD], Decimal('60.00'))

    def test_split_payment_where_second_leg_is_pure_change(self):
        """
        Cashier takes 120 cash against a 100 bill (should be all change, no
        second real payment leg) — simulate a UI bug where a leftover
        second CASH leg of 0 gets recorded; net_applied must not credit it.
        """
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.recalculate_totals()

        Payment.objects.create(order=order, method=Payment.Method.CASH, amount=Decimal('120.00'))
        applied = dict(
            (p.pk, amt) for p, amt in order.net_applied_payments()
        )
        payment = order.payments.first()
        self.assertEqual(applied[payment.pk], Decimal('100.00'))
        self.assertEqual(order.change_due, Decimal('20.00'))

    def test_underpayment_leaves_balance_due(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)  # 100.00
        order.recalculate_totals()

        Payment.objects.create(order=order, method=Payment.Method.CASH, amount=Decimal('60.00'))
        self.assertEqual(order.balance_due, Decimal('40.00'))
        self.assertEqual(order.change_due, Decimal('0.00'))

    def test_mark_paid_sets_status_and_timestamp(self):
        order = self.make_order()
        self.add_line(order, self.item_a, qty=1)
        order.recalculate_totals()
        self.assertEqual(order.status, Order.Status.OPEN)

        order.mark_paid()
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.PAID)
        self.assertIsNotNone(order.paid_at)


class BillNumberTests(BillingTestBase):
    def test_sequential_bill_numbers(self):
        order1 = self.make_order()
        order2 = self.make_order()
        self.assertEqual(order1.bill_number, 'B000001')
        self.assertEqual(order2.bill_number, 'B000002')

    def test_bill_numbers_are_unique(self):
        numbers = {self.make_order().bill_number for _ in range(10)}
        self.assertEqual(len(numbers), 10)

    def test_bill_number_survives_gaps_from_deleted_orders(self):
        order1 = self.make_order()
        order2 = self.make_order()
        order2_number = order2.bill_number
        order1.delete()
        order3 = self.make_order()
        # Next sequence should follow the highest surviving number, not row count
        self.assertEqual(order3.bill_number, 'B000003')
        self.assertNotEqual(order3.bill_number, order2_number)
