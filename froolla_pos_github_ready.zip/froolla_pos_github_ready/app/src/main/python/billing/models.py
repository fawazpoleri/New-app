"""
Billing app models.

Order represents one bill/transaction from the moment a cashier opens a
new POS cart through to payment. OrderItem rows are the individual line
items within that order.

Flow:
    1. A new Order is created with status=OPEN when the cashier hits
       "New Bill" (or lands on the POS screen for the first time).
    2. OrderItems are added/updated/removed as products are tapped.
    3. Totals (subtotal, discount, grand_total) are recalculated on every
       cart change via `Order.recalculate_totals()`.
    4. On successful payment, status flips to PAID and `paid_at` is set.
       From that point the order is immutable bill history.
"""

import time
from decimal import Decimal

from django.conf import settings
from django.db import IntegrityError, OperationalError, models, transaction
from django.utils import timezone


class Order(models.Model):
    """One customer bill, from open cart through to a paid receipt."""

    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open'      # Cart is being built, not yet paid
        PAID = 'PAID', 'Paid'      # Payment completed, receipt printable
        VOID = 'VOID', 'Void'      # Cart abandoned/cleared without payment

    bill_number = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        help_text='Auto-generated sequential bill number, e.g. B000001.',
    )
    cashier = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='orders',
    )
    status = models.CharField(
        max_length=10,
        choices=Status.choices,
        default=Status.OPEN,
    )

    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    grand_total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    paid_at = models.DateTimeField(null=True, blank=True, db_index=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self) -> str:
        return self.bill_number or f'Order #{self.pk}'

    def save(self, *args, **kwargs):
        """
        Assign a sequential bill number the first time the order is saved.

        _generate_bill_number() reads the current max and increments it
        with no row lock, so two concurrent checkouts can legitimately
        compute the same "next" number and collide on the unique
        constraint. Rather than leaving that as a hard failure for the
        cashier, retry with a freshly-computed number a few times — the
        loser of the race simply gets the following number instead.

        Under real multi-terminal load a second, more common race also
        shows up: SQLite raises OperationalError("database is locked")
        when two connections try to write at the same moment, even
        though WAL mode + a busy `timeout` (see DATABASES in settings.py)
        make that a genuinely transient condition, not a real failure —
        it clears itself as soon as the other writer commits. Retrying
        with a short backoff turns that transient lock into an invisible
        delay instead of a checkout crashing on the cashier's screen.
        """
        if not self.bill_number:
            for attempt in range(5):
                self.bill_number = self._generate_bill_number()
                try:
                    with transaction.atomic():
                        super().save(*args, **kwargs)
                    return
                except IntegrityError:
                    self.bill_number = ''
                    if attempt == 4:
                        raise
                except OperationalError as exc:
                    if 'database is locked' not in str(exc).lower() or attempt == 4:
                        raise
                    self.bill_number = ''
                    time.sleep(0.1 * (attempt + 1))
            return
        super().save(*args, **kwargs)

    @staticmethod
    def _generate_bill_number() -> str:
        """
        Generate the next sequential bill number, e.g. B000001, B000002.

        Uses the highest existing numeric suffix rather than row count, so
        numbering stays correct even if old orders are ever deleted.
        """
        last_order = Order.objects.exclude(bill_number='').order_by('-id').first()
        next_seq = 1
        if last_order and last_order.bill_number[1:].isdigit():
            next_seq = int(last_order.bill_number[1:]) + 1
        return f'B{next_seq:06d}'

    def recalculate_totals(self) -> None:
        """
        Recompute subtotal, tax, and grand_total from current OrderItems
        and the stored discount_amount. Called after any cart mutation.

        Two mutually-exclusive tax modes, chosen by RestaurantSetting.gst_enabled:

        - GST mode (India): menu prices already include GST. tax_amount is
          the GST *extracted* from the post-discount total, not added on
          top, so grand_total == net_amount (unchanged by tax). The POS
          screen and receipt then show that extracted amount split evenly
          into CGST/SGST via the properties below.
        - Legacy exclusive-tax mode: tax_percent is added on top of the
          post-discount subtotal, as before (used for non-GST regions).
        """
        from core.models import RestaurantSetting

        subtotal = sum(
            (item.line_total for item in self.items.all()),
            Decimal('0.00'),
        )
        self.subtotal = subtotal

        # Discount can never exceed the subtotal.
        if self.discount_amount > subtotal:
            self.discount_amount = subtotal

        net_amount = subtotal - self.discount_amount
        settings_ = RestaurantSetting.get_solo()

        if settings_.gst_enabled:
            gst_percent = settings_.gst_percent
            divisor = Decimal('1') + (gst_percent / Decimal('100'))
            taxable_value = (net_amount / divisor).quantize(Decimal('0.01')) if divisor else net_amount
            self.tax_amount = (net_amount - taxable_value).quantize(Decimal('0.01'))
            self.grand_total = net_amount.quantize(Decimal('0.01'))
        else:
            tax_percent = settings_.tax_percent
            self.tax_amount = (net_amount * tax_percent / Decimal('100')).quantize(Decimal('0.01'))
            self.grand_total = (net_amount + self.tax_amount).quantize(Decimal('0.01'))

        self.save(update_fields=['subtotal', 'discount_amount', 'tax_amount', 'grand_total'])

    @property
    def taxable_value(self) -> Decimal:
        """Bill value excluding tax, in both GST-inclusive and exclusive modes."""
        return (self.grand_total - self.tax_amount).quantize(Decimal('0.01'))

    @property
    def cgst_amount(self) -> Decimal:
        """Half of the GST amount — Central GST, for the standard intra-state split."""
        return (self.tax_amount / Decimal('2')).quantize(Decimal('0.01'))

    @property
    def sgst_amount(self) -> Decimal:
        """The other half of the GST amount — State GST."""
        return self.tax_amount - self.cgst_amount

    @property
    def total_paid(self) -> Decimal:
        """Sum of all Payment rows linked to this order."""
        return sum((p.amount for p in self.payments.all()), Decimal('0.00'))

    @property
    def balance_due(self) -> Decimal:
        """Remaining amount owed; negative once change is due."""
        return self.grand_total - self.total_paid

    @property
    def change_due(self) -> Decimal:
        """Amount to hand back to the customer, if they overpaid (e.g. cash)."""
        overpaid = self.total_paid - self.grand_total
        return overpaid if overpaid > 0 else Decimal('0.00')

    def net_applied_payments(self):
        """
        Yield (payment, applied_amount) pairs for every payment leg on this
        order, where applied_amount is how much of that leg actually counts
        toward the bill — excluding any change handed back to the customer.

        `Payment.amount` itself always stays as the raw amount the cashier
        entered/tendered (needed for an accurate receipt, e.g. "Cash
        Tendered: 100.000, Change: 50.000"). This method is what every
        revenue/ledger/report figure should sum instead of raw
        `payment.amount`, so that a cash overpayment used purely to make
        change is never counted as extra sales.

        Legs are applied in the order they were recorded; once the running
        total reaches grand_total, any further amount contributes 0.
        """
        remaining = self.grand_total
        for payment in self.payments.all():
            if remaining <= 0:
                applied = Decimal('0.00')
            else:
                applied = min(payment.amount, remaining)
                remaining -= applied
            yield payment, applied

    def net_payment_totals_by_method(self) -> dict:
        """Aggregate net_applied_payments() into {method: net_amount}."""
        totals: dict = {}
        for payment, applied in self.net_applied_payments():
            if applied <= 0:
                continue
            totals[payment.method] = totals.get(payment.method, Decimal('0.00')) + applied
        return totals

    def net_applied_amount_for(self, payment) -> Decimal:
        """
        The net applied amount (see net_applied_payments) for one specific
        payment leg. Used wherever a single leg needs to be reversed/
        reposted (e.g. correct_payment_method) — reversing the raw
        `payment.amount` instead would over-reverse/over-credit the ledger
        by whatever change that leg contributed to.
        """
        for p, applied in self.net_applied_payments():
            if p.pk == payment.pk:
                return applied
        return Decimal('0.00')

    def mark_paid(self) -> None:
        self.status = self.Status.PAID
        self.paid_at = timezone.now()
        self.save(update_fields=['status', 'paid_at'])


class OrderItem(models.Model):
    """A single product line within an Order."""

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(
        'menu.MenuItem',
        on_delete=models.PROTECT,
        related_name='order_items',
    )
    # Name/price are captured at the time of sale so historical bills stay
    # accurate even if the menu item is later renamed, repriced, or removed.
    item_name = models.CharField(max_length=100)
    unit_price = models.DecimalField(max_digits=8, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ['id']

    def __str__(self) -> str:
        return f'{self.item_name} x{self.quantity}'

    @property
    def line_total(self) -> Decimal:
        return self.unit_price * self.quantity

    def save(self, *args, **kwargs):
        """Snapshot the menu item's current name/price on first save."""
        if not self.pk and not self.unit_price:
            self.unit_price = self.menu_item.price
        if not self.item_name:
            self.item_name = self.menu_item.name
        super().save(*args, **kwargs)
