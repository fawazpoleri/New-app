"""
Billing app views.

Covers the full cashier workflow:

    POS screen  -> AJAX cart endpoints -> Payment screen -> Receipt
                                                           -> Bill History

The "current order" for a cashier is tracked via their session
(`request.session['current_order_id']`), so each logged-in cashier has
their own in-progress cart even if multiple terminals are open.
"""

import json
from decimal import Decimal, InvalidOperation

from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse, HttpRequest, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect
from django.db.models import Prefetch
from django.urls import reverse
from django.utils import timezone
from django.views import View
from django.views.decorators.http import require_POST
from django.views.generic import DetailView, ListView, TemplateView

from billing.models import Order, OrderItem
from menu.models import Category, MenuItem
from payments.models import Payment
from tables.permissions import CashierOrAdminRequiredMixin, cashier_or_admin_required


def _is_business_day_open() -> bool:
    """
    Ensures there is a currently OPEN business day before letting billing
    proceed, auto-opening one if needed. This is what makes the midnight
    (and post-close) business-day rollover automatic: no admin has to
    click "Open Day" — the first sale of a new business date (or the
    first sale right after an admin's manual Daily Close) simply opens
    it on the fly, with the opening float carried forward the same way a
    manual Open Day would.

    Imported lazily (not at module level) so billing app doesn't have a
    hard import-time dependency on cashbook; if cashbook is ever disabled
    or something goes wrong opening the day, this fails safe by blocking
    sales rather than silently allowing them.
    """
    try:
        from cashbook.services import ensure_day_open
        ensure_day_open()
        return True
    except Exception:
        return False


def _get_or_create_open_order(request: HttpRequest) -> Order:
    """
    Fetch the cashier's in-progress order from their session, creating a
    fresh one if there isn't one yet (first visit, or after the previous
    bill was paid/cleared).
    """
    order_id = request.session.get('current_order_id')
    order = None
    if order_id:
        order = Order.objects.filter(pk=order_id, status=Order.Status.OPEN).first()
    if order is None:
        order = Order.objects.create(cashier=request.user)
        request.session['current_order_id'] = order.pk
    return order


class POSView(CashierOrAdminRequiredMixin, LoginRequiredMixin, TemplateView):
    """
    The main cashier screen: categories on the left, product grid in the
    center, live cart on the right. All cart mutation happens via the AJAX
    endpoints below — this view only renders the initial page.
    """

    template_name = 'billing/pos.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        order = _get_or_create_open_order(self.request)

        # One query for categories, one for their active items (via Prefetch) —
        # avoids the previous N+1 pattern of an .exists() query per category.
        categories = Category.objects.filter(is_active=True).prefetch_related(
            Prefetch(
                'items',
                queryset=MenuItem.objects.filter(is_active=True),
                to_attr='active_items',
            )
        )
        # Only show categories that currently have at least one active item.
        categories = [c for c in categories if c.active_items]

        context.update({
            'categories': categories,
            'order': order,
            'cart_items': order.items.select_related('menu_item').all(),
            'day_open': _is_business_day_open(),
        })
        return context


@login_required
@cashier_or_admin_required
@require_POST
def cart_add_item(request: HttpRequest) -> JsonResponse:
    """Add one unit of a menu item to the cart, or increment if already present."""
    order = _get_or_create_open_order(request)
    item_id = request.POST.get('item_id')
    menu_item = get_object_or_404(MenuItem, pk=item_id, is_active=True)

    line, created = OrderItem.objects.get_or_create(
        order=order,
        menu_item=menu_item,
        defaults={'item_name': menu_item.name, 'unit_price': menu_item.price, 'quantity': 1},
    )
    if not created:
        line.quantity += 1
        line.save(update_fields=['quantity'])

    order.recalculate_totals()
    return JsonResponse(_cart_payload(order))


@login_required
@cashier_or_admin_required
@require_POST
def cart_update_quantity(request: HttpRequest) -> JsonResponse:
    """Increment/decrement a line item's quantity. Removes the line at zero."""
    order = _get_or_create_open_order(request)
    line_id = request.POST.get('line_id')
    delta = request.POST.get('delta')

    try:
        delta = int(delta)
    except (TypeError, ValueError):
        return HttpResponseBadRequest('Invalid delta')

    line = get_object_or_404(OrderItem, pk=line_id, order=order)
    line.quantity += delta
    if line.quantity <= 0:
        line.delete()
    else:
        line.save(update_fields=['quantity'])

    order.recalculate_totals()
    return JsonResponse(_cart_payload(order))


@login_required
@cashier_or_admin_required
@require_POST
def cart_remove_item(request: HttpRequest) -> JsonResponse:
    """Remove a line item entirely, regardless of quantity."""
    order = _get_or_create_open_order(request)
    line_id = request.POST.get('line_id')
    line = get_object_or_404(OrderItem, pk=line_id, order=order)
    line.delete()
    order.recalculate_totals()
    return JsonResponse(_cart_payload(order))


@login_required
@cashier_or_admin_required
@require_POST
def cart_clear(request: HttpRequest) -> JsonResponse:
    """Empty the current cart entirely (keeps the same Order, removes all lines)."""
    order = _get_or_create_open_order(request)
    order.items.all().delete()
    order.discount_amount = Decimal('0.00')
    order.recalculate_totals()
    return JsonResponse(_cart_payload(order))


@login_required
@cashier_or_admin_required
@require_POST
def cart_apply_discount(request: HttpRequest) -> JsonResponse:
    """Set a flat discount amount (in ₹) on the current order."""
    order = _get_or_create_open_order(request)
    raw_amount = request.POST.get('discount_amount', '0')

    try:
        discount = Decimal(raw_amount).quantize(Decimal('0.01'))
    except InvalidOperation:
        return HttpResponseBadRequest('Invalid discount amount')

    if discount < 0:
        discount = Decimal('0.00')

    order.discount_amount = discount
    order.recalculate_totals()
    return JsonResponse(_cart_payload(order))


def _cart_payload(order: Order) -> dict:
    """Shared JSON shape returned by every cart-mutation endpoint."""
    from core.models import RestaurantSetting

    lines = [
        {
            'line_id': item.pk,
            'name': item.item_name,
            'unit_price': str(item.unit_price),
            'quantity': item.quantity,
            'line_total': str(item.line_total),
        }
        for item in order.items.select_related('menu_item').all()
    ]
    return {
        'order_id': order.pk,
        'bill_number': order.bill_number,
        'items': lines,
        'subtotal': str(order.subtotal),
        'discount_amount': str(order.discount_amount),
        'tax_amount': str(order.tax_amount),
        'grand_total': str(order.grand_total),
        'gst_enabled': RestaurantSetting.get_solo().gst_enabled,
        'taxable_value': str(order.taxable_value),
        'cgst_amount': str(order.cgst_amount),
        'sgst_amount': str(order.sgst_amount),
    }


class PaymentView(CashierOrAdminRequiredMixin, LoginRequiredMixin, TemplateView):
    """
    Payment screen for the current open order. Supports Cash, Card, UPI,
    or a Mixed combination — the cashier can enter an amount against any
    number of methods and the template/JS shows remaining/change live.
    """

    template_name = 'billing/payment.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        order = _get_or_create_open_order(self.request)
        context['order'] = order
        context['day_open'] = _is_business_day_open()
        return context

    def post(self, request, *args, **kwargs):
        """
        Accept one or more payment legs as JSON, e.g.:
            {"payments": [{"method": "CASH", "amount": "5.000"},
                           {"method": "CARD", "amount": "2.500"}]}
        Validates the total covers the grand total, then marks the order
        paid and clears it from the cashier's session so the next visit to
        the POS screen starts a fresh bill.
        """
        if not _is_business_day_open():
            return JsonResponse(
                {'error': 'Could not open today\'s business day automatically. Please contact an admin.'},
                status=403,
            )

        order = _get_or_create_open_order(request)

        if order.items.count() == 0:
            return JsonResponse({'error': 'Cannot pay an empty cart.'}, status=400)

        try:
            payload = json.loads(request.body)
            legs = payload.get('payments', [])
        except (json.JSONDecodeError, AttributeError):
            return JsonResponse({'error': 'Invalid payment data.'}, status=400)

        if not legs:
            return JsonResponse({'error': 'At least one payment method is required.'}, status=400)

        total_tendered = Decimal('0.00')
        validated_legs = []
        for leg in legs:
            method = leg.get('method')
            if method not in Payment.Method.values:
                return JsonResponse({'error': f'Invalid payment method: {method}'}, status=400)
            try:
                amount = Decimal(str(leg.get('amount', '0')))
            except InvalidOperation:
                return JsonResponse({'error': 'Invalid payment amount.'}, status=400)
            if amount <= 0:
                continue
            total_tendered += amount
            validated_legs.append((method, amount))

        if total_tendered < order.grand_total:
            shortfall = order.grand_total - total_tendered
            return JsonResponse(
                {'error': f'Payment is short by {shortfall} ₹.'}, status=400
            )

        for method, amount in validated_legs:
            Payment.objects.create(order=order, method=method, amount=amount)

        order.mark_paid()
        request.session.pop('current_order_id', None)

        return JsonResponse({
            'success': True,
            'order_id': order.pk,
            'redirect_url': reverse('billing:receipt', args=[order.pk]) + '?autoprint=1',
            'kot_print_url': reverse('billing:kot_print', args=[order.pk]) + '?autoprint=1',
        })


class ReceiptView(CashierOrAdminRequiredMixin, LoginRequiredMixin, DetailView):
    """
    Printable receipt for a paid order. Reused both right after payment
    (auto-print) and from Bill History (manual reprint).
    """

    model = Order
    template_name = 'billing/receipt.html'
    context_object_name = 'order'

    def get_queryset(self):
        return Order.objects.filter(status=Order.Status.PAID).prefetch_related(
            'items', 'payments'
        )


class KotPrintView(CashierOrAdminRequiredMixin, LoginRequiredMixin, DetailView):
    """
    Printable Kitchen Order Ticket for a counter/POS bill (as opposed to
    the dine-in KOT flow in `tables`, which is tied to a TableOrder).

    Available for the cashier's current OPEN cart (manual "Print KOT"
    button on the POS screen, before payment) and for a just-PAID order
    (auto-print right after payment completes) — anything except a VOID
    bill, which was never sent to the kitchen.
    """

    model = Order
    template_name = 'billing/kot_print.html'
    context_object_name = 'order'

    def get_queryset(self):
        return Order.objects.exclude(status=Order.Status.VOID).prefetch_related('items')


class NewBillView(CashierOrAdminRequiredMixin, LoginRequiredMixin, View):
    """
    Explicitly start a new bill, abandoning any current empty/unpaid cart.
    Used by the "New Bill" button after printing a receipt, or to reset a
    cart the cashier no longer wants.
    """

    def post(self, request, *args, **kwargs):
        order_id = request.session.pop('current_order_id', None)
        if order_id:
            stale = Order.objects.filter(pk=order_id, status=Order.Status.OPEN).first()
            if stale:
                stale.status = Order.Status.VOID
                stale.save(update_fields=['status'])
        return redirect('billing:pos')


class BillHistoryView(CashierOrAdminRequiredMixin, LoginRequiredMixin, ListView):
    """
    Today's paid bills, with search by bill number. Each row links to the
    receipt view for reprinting.
    """

    model = Order
    template_name = 'billing/bill_history.html'
    context_object_name = 'orders'
    paginate_by = 30

    def get_queryset(self):
        queryset = Order.objects.filter(status=Order.Status.PAID)

        search = self.request.GET.get('q', '').strip()
        if search:
            queryset = queryset.filter(bill_number__icontains=search)
        else:
            # Default to today's bills only, per spec. Filtered by paid_at
            # (when the bill was actually paid), matching the business-date
            # semantic used by every other report/EOD figure — a cart
            # opened before midnight and paid after it must land in the
            # same "today" bucket everywhere, not just here.
            queryset = queryset.filter(paid_at__date=timezone.localdate())

        return queryset.select_related('cashier').order_by('-paid_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('q', '')
        return context
