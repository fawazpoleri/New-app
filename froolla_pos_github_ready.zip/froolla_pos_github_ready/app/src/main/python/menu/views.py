"""
Menu app — no views.

Category and MenuItem are managed exclusively through Django Admin per
the spec ("Use Django Admin only... No custom CRUD pages"). The POS
screen (billing app) reads MenuItem/Category directly via the ORM.
"""
