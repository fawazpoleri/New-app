"""
Admin configuration for the menu app.

This is the ONLY way Categories and MenuItems are managed in Phase 1 —
there are no custom CRUD pages, per spec.
"""

from django.contrib import admin
from django.utils.html import format_html

from menu.models import Category, MenuItem


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'display_order', 'is_active')
    list_editable = ('display_order', 'is_active')
    search_fields = ('name',)
    ordering = ('display_order', 'name')


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('thumbnail', 'name', 'category', 'price', 'is_active')
    list_editable = ('price', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('name',)
    ordering = ('category', 'name')
    readonly_fields = ('image_preview',)
    fields = ('category', 'name', 'price', 'is_active', 'image', 'image_preview')

    def thumbnail(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" style="height:36px;width:36px;object-fit:cover;border-radius:6px;">',
                obj.image.url,
            )
        return '—'
    thumbnail.short_description = ''

    def image_preview(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" style="max-height:160px;border-radius:10px;">',
                obj.image.url,
            )
        return 'No image uploaded yet — add one so it shows on the QR menu.'
    image_preview.short_description = 'Preview'
