"""
Menu app models.

Category and MenuItem are managed exclusively through Django Admin in
Phase 1 — there are no custom CRUD views. The POS screen (billing app)
reads from these models read-only.
"""

from django.db import models


class Category(models.Model):
    """A grouping of menu items, e.g. Juices, Coffee, Sandwiches."""

    name = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(
        default=True,
        help_text='Inactive categories are hidden from the POS screen.',
    )
    display_order = models.PositiveIntegerField(
        default=0,
        help_text='Lower numbers appear first on the POS category list.',
    )

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['display_order', 'name']

    def __str__(self) -> str:
        return self.name


class MenuItem(models.Model):
    """A single sellable product, e.g. 'Mango Juice' priced at 1.25 ₹."""

    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='items',
    )
    name = models.CharField(max_length=100)
    price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        help_text='Price in ₹ (2 decimal places, i.e. paise).',
    )
    is_active = models.BooleanField(
        default=True,
        help_text='Inactive items are hidden from the POS screen.',
    )
    image = models.ImageField(
        upload_to='menu_items/',
        blank=True,
        null=True,
        help_text='Shown on the customer QR menu and the POS product grid.',
    )

    class Meta:
        ordering = ['name']

    def __str__(self) -> str:
        return f'{self.name} ({self.price} ₹)'
