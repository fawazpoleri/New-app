"""
cashbook.signals
----------------
Connect Django signals to the service layer so that:

  - A paid Order  → cash book entries are written automatically
  - A new Expense → cash book debit is written automatically
  - A new Income  → cash book credit is written automatically

Signals are registered in CashbookConfig.ready() so they are only
wired up once Django's app registry is fully loaded.

IMPORTANT — every @receiver below passes weak=False. These receivers are
local closures defined inside register_signals() rather than module-level
functions, so nothing else in the process holds a strong reference to
them. Django's default signal connection (weak=True) only keeps a *weak*
reference to the receiver — with no other strong reference around, the
garbage collector is free to collect these closures at any point after
register_signals() returns, which silently disconnects the signal with
no error or warning. That would mean POS sales quietly stop being
recorded in the Cash Book at some unpredictable point in a long-running
server process. weak=False makes Django hold its own strong reference,
so these are never garbage collected. Do not remove weak=False here
unless these functions are moved to module level instead.
"""

import logging

from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver

logger = logging.getLogger(__name__)


def register_signals():
    """
    Called from CashbookConfig.ready().
    Import models here (inside the function) to avoid AppRegistryNotReady.
    """
    from billing.models import Order
    from .models import Expense, OtherIncome
    from . import services

    @receiver(pre_save, sender=Expense, dispatch_uid='cashbook_expense_pre_save', weak=False)
    def on_expense_pre_save(sender, instance: Expense, **kwargs):
        """
        Stash the prior amount/account/date on the instance before an edit,
        so the post_save handler can tell whether anything financial
        actually changed and, if so, correct the ledger to match — or
        block the edit if it would silently corrupt an already-closed
        business day's frozen totals.
        """
        instance._cb_old_amount = None
        instance._cb_old_account_id = None
        instance._cb_old_date = None
        if instance.pk:
            prior = Expense.objects.filter(pk=instance.pk).values(
                'amount', 'paid_from_account_id', 'expense_date'
            ).first()
            if prior:
                instance._cb_old_amount = prior['amount']
                instance._cb_old_account_id = prior['paid_from_account_id']
                instance._cb_old_date = prior['expense_date']

    @receiver(pre_save, sender=OtherIncome, dispatch_uid='cashbook_income_pre_save', weak=False)
    def on_income_pre_save(sender, instance: OtherIncome, **kwargs):
        """Mirror of on_expense_pre_save, for OtherIncome."""
        instance._cb_old_amount = None
        instance._cb_old_account_id = None
        instance._cb_old_date = None
        if instance.pk:
            prior = OtherIncome.objects.filter(pk=instance.pk).values(
                'amount', 'receive_account_id', 'income_date'
            ).first()
            if prior:
                instance._cb_old_amount = prior['amount']
                instance._cb_old_account_id = prior['receive_account_id']
                instance._cb_old_date = prior['income_date']

    @receiver(post_save, sender=Order, dispatch_uid='cashbook_pos_sale', weak=False)
    def on_order_paid(sender, instance: Order, created: bool, **kwargs):
        """
        Fire after every Order save. Only acts when status just became PAID.
        Delegates entirely to the service layer.

        The Open Day gate lives in billing.views.PaymentView, which blocks
        the normal cashier flow before money ever changes hands. This
        signal is the last point where ALL paths converge (including
        Django admin, which can mark an Order PAID directly, bypassing
        the view). We deliberately do NOT block recording here — the
        money genuinely moved, and a missing ledger entry would be worse
        than an unusual one. Instead we flag it loudly in the description
        and the log so it's impossible to miss during reconciliation.
        """
        if instance.status != Order.Status.PAID:
            return
        # Avoid re-processing if there are already cash book entries for this order
        from .models import CashBook
        already_recorded = CashBook.objects.filter(
            reference_type=CashBook.ReferenceType.POS,
            reference_id=instance.pk,
        ).exists()
        if already_recorded:
            return

        day_open = services.is_day_open()
        if not day_open:
            logger.warning(
                'CashBook: order %s was marked PAID while the business day was '
                'NOT open (likely created outside the normal POS flow, e.g. '
                'Django admin). Recording it anyway, flagged for review.',
                instance.bill_number,
            )

        try:
            services.record_pos_payments(
                instance, created_by=instance.cashier, outside_open_day=not day_open,
            )
        except Exception as exc:
            # Log but don't crash the payment view — receipt must still print
            logger.exception('CashBook: failed to record POS payments for order %s: %s', instance.pk, exc)

    @receiver(post_save, sender=Expense, dispatch_uid='cashbook_expense', weak=False)
    def on_expense_saved(sender, instance: Expense, created: bool, **kwargs):
        """
        Record a cash book debit the first time an Expense is saved.
        Re-raises ValueError (e.g. insufficient balance) so the view can
        roll back the Expense row and show the cashier a clear message —
        an Expense must never exist without a matching ledger entry.

        On an edit (amount and/or paying account changed), the ledger is
        NOT retroactively rewritten — the original entry is append-only,
        same philosophy as correct_payment_method — instead a correcting
        pair of entries is posted so the ledger, Expected Cash, and the
        Expenses Report all agree with the edited amount going forward.
        """
        if created:
            try:
                services.record_expense(instance)
            except ValueError:
                raise  # Propagate business-rule violations (e.g. negative balance)
            except Exception as exc:
                logger.exception('CashBook: failed to record expense %s: %s', instance.pk, exc)
                raise  # An Expense with no ledger entry is worse than a failed save
            return

        old_amount = getattr(instance, '_cb_old_amount', None)
        old_account_id = getattr(instance, '_cb_old_account_id', None)
        old_date = getattr(instance, '_cb_old_date', None)
        if old_amount is None:
            return  # Couldn't determine the prior state; nothing safe to correct
        if old_amount == instance.amount and old_account_id == instance.paid_from_account_id:
            return  # Non-financial edit (e.g. note text) — ledger already correct
        if (old_date and services.is_day_closed(old_date)) or services.is_day_closed(instance.expense_date):
            raise ValueError(
                f'Cannot edit this expense — its business day ({old_date or instance.expense_date}) '
                f'is already closed, and this would silently leave that day\'s locked Cash Book '
                f'Summary out of sync with the Expenses Report. Record a Cash Adjustment for the '
                f'difference instead, dated today, the same way a real correcting journal entry works.'
            )
        try:
            services.adjust_expense_entry(
                instance, old_amount=old_amount, old_account_id=old_account_id,
            )
        except Exception as exc:
            logger.exception(
                'CashBook: failed to adjust ledger for edited expense %s: %s', instance.pk, exc,
            )
            raise

    @receiver(post_save, sender=OtherIncome, dispatch_uid='cashbook_income', weak=False)
    def on_income_saved(sender, instance: OtherIncome, created: bool, **kwargs):
        """
        Record a cash book credit the first time an OtherIncome is saved.
        Mirrors on_expense_saved's edit-correction behaviour below.
        """
        if created:
            try:
                services.record_other_income(instance)
            except Exception as exc:
                logger.exception('CashBook: failed to record income %s: %s', instance.pk, exc)
                raise  # Income with no ledger entry would silently understate cash
            return

        old_amount = getattr(instance, '_cb_old_amount', None)
        old_account_id = getattr(instance, '_cb_old_account_id', None)
        old_date = getattr(instance, '_cb_old_date', None)
        if old_amount is None:
            return
        if old_amount == instance.amount and old_account_id == instance.receive_account_id:
            return
        if (old_date and services.is_day_closed(old_date)) or services.is_day_closed(instance.income_date):
            raise ValueError(
                f'Cannot edit this income entry — its business day ({old_date or instance.income_date}) '
                f'is already closed, and this would silently leave that day\'s locked Cash Book '
                f'Summary out of sync with the Other Income Report. Record a Cash Adjustment for the '
                f'difference instead, dated today, the same way a real correcting journal entry works.'
            )
        try:
            services.adjust_income_entry(
                instance, old_amount=old_amount, old_account_id=old_account_id,
            )
        except Exception as exc:
            logger.exception(
                'CashBook: failed to adjust ledger for edited income %s: %s', instance.pk, exc,
            )
            raise
