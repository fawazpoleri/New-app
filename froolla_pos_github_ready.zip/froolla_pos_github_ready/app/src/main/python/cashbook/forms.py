"""
cashbook.forms
--------------
Clean, validated forms for every user-facing cash book action.
Business logic lives in services.py — forms only handle validation & cleaning.
"""

from decimal import Decimal, InvalidOperation

from django import forms
from django.utils import timezone

from .models import CashAccount, Expense, OtherIncome


class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['expense_date', 'category', 'amount', 'paid_from_account', 'note', 'attachment']
        widgets = {
            'expense_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'category':     forms.Select(attrs={'class': 'form-control'}),
            'amount':       forms.NumberInput(attrs={'class': 'form-control', 'step': '0.001', 'min': '0.001'}),
            'paid_from_account': forms.Select(attrs={'class': 'form-control'}),
            'note':         forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Brief description…'}),
            'attachment':   forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['paid_from_account'].queryset = CashAccount.objects.filter(is_active=True)
        self.fields['expense_date'].initial = timezone.localdate()

    def clean(self):
        cleaned_data = super().clean()
        amount = cleaned_data.get('amount')
        account = cleaned_data.get('paid_from_account')
        if amount is not None and account is not None:
            if amount > account.current_balance:
                self.add_error(
                    'amount',
                    f'Insufficient balance in {account.name}. '
                    f'Available: {account.current_balance} ₹.',
                )
        return cleaned_data

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is not None and amount <= 0:
            raise forms.ValidationError('Amount must be greater than zero.')
        return amount


class OtherIncomeForm(forms.ModelForm):
    class Meta:
        model = OtherIncome
        fields = ['income_date', 'category', 'amount', 'receive_account', 'note', 'attachment']
        widgets = {
            'income_date':    forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'category':       forms.Select(attrs={'class': 'form-control'}),
            'amount':         forms.NumberInput(attrs={'class': 'form-control', 'step': '0.001', 'min': '0.001'}),
            'receive_account': forms.Select(attrs={'class': 'form-control'}),
            'note':           forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Brief description…'}),
            'attachment':     forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['receive_account'].queryset = CashAccount.objects.filter(is_active=True)
        self.fields['income_date'].initial = timezone.localdate()

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is not None and amount <= 0:
            raise forms.ValidationError('Amount must be greater than zero.')
        return amount


class BankTransferForm(forms.Form):
    """Used for both deposit (drawer → bank) and withdrawal (bank → drawer)."""
    DIRECTION_CHOICES = [
        ('deposit',  'Cash Deposit (Drawer → Bank)'),
        ('withdraw', 'Cash Withdrawal (Bank → Drawer)'),
    ]
    direction = forms.ChoiceField(
        choices=DIRECTION_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
    )
    amount = forms.DecimalField(
        max_digits=10, decimal_places=2,
        min_value=Decimal('0.01'),
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.001', 'min': '0.001'}),
    )
    note = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Reason for transfer…'}),
    )
    attachment = forms.FileField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control'}),
        help_text='Optional supporting document (deposit slip, transfer receipt, etc.)',
    )

    def clean(self):
        """
        Block transfers that would overdraw the source account.
        Deposit pulls FROM the cash drawer; withdrawal pulls FROM the bank.
        """
        cleaned_data = super().clean()
        direction = cleaned_data.get('direction')
        amount = cleaned_data.get('amount')
        if direction and amount is not None:
            source = CashAccount.objects.filter(
                name='Cash Drawer' if direction == 'deposit' else 'Bank Account'
            ).first()
            if source and amount > source.current_balance:
                self.add_error(
                    'amount',
                    f'Insufficient balance in {source.name}. '
                    f'Available: {source.current_balance} ₹.',
                )
        return cleaned_data


class AdjustmentForm(forms.Form):
    """Admin-only; allows positive or negative cash adjustment with a mandatory note."""
    account = forms.ModelChoiceField(
        queryset=CashAccount.objects.filter(is_active=True),
        widget=forms.Select(attrs={'class': 'form-control'}),
    )
    amount = forms.DecimalField(
        max_digits=10, decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control', 'step': '0.001',
            'placeholder': 'Positive to add, negative to deduct',
        }),
        help_text='Enter a positive value to increase balance, negative to decrease.',
    )
    note = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Reason for adjustment (required)…'}),
    )

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount == Decimal('0'):
            raise forms.ValidationError('Adjustment amount cannot be zero.')
        return amount


class OpenDayForm(forms.Form):
    """
    Used to explicitly open a business day before any POS billing can
    happen. opening_cash defaults to the previous day's counted cash (or
    the account's configured opening_balance on day one) — pre-filled by
    the view, but cashiers can adjust it if the till float was changed.
    """
    opening_cash = forms.DecimalField(
        max_digits=12, decimal_places=2,
        min_value=Decimal('0.00'),
        label='Opening Cash Float (₹)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control form-control-lg',
            'step': '0.001',
            'min': '0',
            'autofocus': True,
        }),
    )


class DailyCloseForm(forms.Form):
    """Cashier only enters the physically counted cash in the drawer."""
    counted_cash = forms.DecimalField(
        max_digits=12, decimal_places=2,
        min_value=Decimal('0.00'),
        label='Counted Cash in Drawer (₹)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control form-control-lg',
            'step': '0.001',
            'min': '0',
            'autofocus': True,
        }),
    )


class PaymentCorrectionForm(forms.Form):
    """
    Lets an admin fix a payment leg recorded under the wrong method.
    The order/payment being corrected is identified by the view (via URL),
    not by this form — the form only collects the new method.
    """
    new_method = forms.ChoiceField(
        choices=[],  # populated in __init__ to exclude the current method
        label='Correct Payment Method',
        widget=forms.Select(attrs={'class': 'form-control'}),
    )

    def __init__(self, *args, current_method=None, **kwargs):
        super().__init__(*args, **kwargs)
        from payments.models import Payment
        choices = [
            (val, label) for val, label in Payment.Method.choices
            if val != current_method
        ]
        self.fields['new_method'].choices = choices


class CashBookFilterForm(forms.Form):
    """Filter bar on the Cash Book list view."""
    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
    )
    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
    )
    transaction_type = forms.ChoiceField(
        required=False,
        choices=[],  # populated in __init__ from the model so it can never drift
        widget=forms.Select(attrs={'class': 'form-control'}),
    )
    account = forms.ModelChoiceField(
        required=False,
        queryset=None,  # Set in __init__
        empty_label='All Accounts',
        widget=forms.Select(attrs={'class': 'form-control'}),
    )
    search = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Search description…'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .models import CashBook
        # Include inactive accounts too — old ledger entries against a
        # deactivated account must remain filterable/searchable.
        self.fields['account'].queryset = CashAccount.objects.all()
        self.fields['transaction_type'].choices = (
            [('', 'All Types')] + list(CashBook.TransactionType.choices)
        )
