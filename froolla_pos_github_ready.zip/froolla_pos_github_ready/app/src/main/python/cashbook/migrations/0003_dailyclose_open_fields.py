"""Adds opened_by/opened_at to DailyClose, supporting an explicit Open Day step."""

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('cashbook', '0002_paymentcorrection'),
    ]

    operations = [
        migrations.AddField(
            model_name='dailyclose',
            name='opened_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name='daily_opens',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name='dailyclose',
            name='opened_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
