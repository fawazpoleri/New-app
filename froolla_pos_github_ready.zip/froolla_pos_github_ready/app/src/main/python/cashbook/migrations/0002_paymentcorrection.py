"""Adds PaymentCorrection — tracks one-time cashier self-corrections of payment method."""

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('cashbook', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='PaymentCorrection',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('payment_id', models.PositiveIntegerField(
                    unique=True,
                    help_text='payments.Payment.id that was corrected. Unique — one correction per payment leg.',
                )),
                ('order_id', models.PositiveIntegerField(
                    help_text='billing.Order.id this payment belongs to, denormalized for quick lookup.',
                )),
                ('old_method', models.CharField(max_length=10)),
                ('new_method', models.CharField(max_length=10)),
                ('amount', models.DecimalField(decimal_places=3, max_digits=10)),
                ('corrected_by', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='payment_corrections',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('corrected_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'verbose_name': 'Payment Correction',
                'verbose_name_plural': 'Payment Corrections',
                'ordering': ['-corrected_at'],
            },
        ),
    ]
