"""
cashbook initial migration.

Creates:
  - cashbook_cashaccount
  - cashbook_cashbook
  - cashbook_expense
  - cashbook_otherincome
  - cashbook_dailyclose
"""

import decimal
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='CashAccount',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100, unique=True)),
                ('account_type', models.CharField(
                    choices=[('CASH', 'Cash'), ('BANK', 'Bank')],
                    default='CASH', max_length=10,
                )),
                ('opening_balance', models.DecimalField(
                    decimal_places=3, default=decimal.Decimal('0.000'),
                    help_text='Starting balance when the account was first activated.',
                    max_digits=12,
                )),
                ('current_balance', models.DecimalField(
                    decimal_places=3, default=decimal.Decimal('0.000'),
                    help_text='Running balance kept in sync by every CashBook entry.',
                    max_digits=12,
                )),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'verbose_name': 'Cash Account',
                'verbose_name_plural': 'Cash Accounts',
                'ordering': ['account_type', 'name'],
            },
        ),
        migrations.CreateModel(
            name='CashBook',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('transaction_datetime', models.DateTimeField(default=django.utils.timezone.now)),
                ('account', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='entries',
                    to='cashbook.cashaccount',
                )),
                ('transaction_type', models.CharField(
                    choices=[
                        ('OPENING', 'Opening Balance'),
                        ('POS_SALE', 'POS Sale'),
                        ('OTHER_INCOME', 'Other Income'),
                        ('EXPENSE', 'Expense'),
                        ('BANK_DEPOSIT', 'Bank Deposit'),
                        ('BANK_WITHDRAW', 'Bank Withdrawal'),
                        ('ADJUSTMENT', 'Adjustment'),
                        ('CLOSING', 'Closing'),
                    ],
                    max_length=20,
                )),
                ('reference_type', models.CharField(
                    choices=[
                        ('POS', 'POS Sale'),
                        ('EXPENSE', 'Expense'),
                        ('INCOME', 'Other Income'),
                        ('TRANSFER', 'Bank Transfer'),
                        ('MANUAL', 'Manual'),
                    ],
                    default='MANUAL', max_length=10,
                )),
                ('reference_id', models.PositiveIntegerField(blank=True, null=True)),
                ('description', models.CharField(max_length=255)),
                ('money_in', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('money_out', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('balance_after', models.DecimalField(
                    decimal_places=3, default=decimal.Decimal('0.000'),
                    help_text='Account balance immediately after this transaction.',
                    max_digits=12,
                )),
                ('created_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='cashbook_entries',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'verbose_name': 'Cash Book Entry',
                'verbose_name_plural': 'Cash Book',
                'ordering': ['-transaction_datetime', '-id'],
            },
        ),
        migrations.CreateModel(
            name='Expense',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('expense_date', models.DateField(default=django.utils.timezone.localdate)),
                ('category', models.CharField(
                    choices=[
                        ('SUPPLIES', 'Supplies'),
                        ('UTILITIES', 'Utilities'),
                        ('MAINTENANCE', 'Maintenance'),
                        ('SALARY', 'Salary / Wages'),
                        ('TRANSPORT', 'Transport'),
                        ('MARKETING', 'Marketing'),
                        ('FOOD_RAW', 'Raw Materials / Food'),
                        ('OTHER', 'Other'),
                    ],
                    default='OTHER', max_length=20,
                )),
                ('amount', models.DecimalField(decimal_places=3, max_digits=10)),
                ('paid_from_account', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='expenses',
                    to='cashbook.cashaccount',
                )),
                ('note', models.CharField(blank=True, max_length=255)),
                ('created_by', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='expenses',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'verbose_name': 'Expense',
                'verbose_name_plural': 'Expenses',
                'ordering': ['-expense_date', '-created_at'],
            },
        ),
        migrations.CreateModel(
            name='OtherIncome',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('income_date', models.DateField(default=django.utils.timezone.localdate)),
                ('category', models.CharField(
                    choices=[
                        ('CATERING', 'Catering / Event'),
                        ('DELIVERY', 'Delivery Commission'),
                        ('REFUND_IN', 'Supplier Refund'),
                        ('INTEREST', 'Bank Interest'),
                        ('OTHER', 'Other'),
                    ],
                    default='OTHER', max_length=20,
                )),
                ('amount', models.DecimalField(decimal_places=3, max_digits=10)),
                ('receive_account', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='other_incomes',
                    to='cashbook.cashaccount',
                )),
                ('note', models.CharField(blank=True, max_length=255)),
                ('created_by', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='other_incomes',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'verbose_name': 'Other Income',
                'verbose_name_plural': 'Other Incomes',
                'ordering': ['-income_date', '-created_at'],
            },
        ),
        migrations.CreateModel(
            name='DailyClose',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('business_date', models.DateField(unique=True)),
                ('opening_cash', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('cash_sales', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('card_sales', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('upi_sales', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('other_income', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('expenses', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('cash_deposit', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('cash_withdraw', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('expected_cash', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('counted_cash', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('difference', models.DecimalField(decimal_places=3, default=decimal.Decimal('0.000'), max_digits=12)),
                ('status', models.CharField(
                    choices=[('OPEN', 'Open'), ('CLOSED', 'Closed')],
                    default='OPEN', max_length=10,
                )),
                ('closed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='daily_closes',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('closed_at', models.DateTimeField(blank=True, null=True)),
            ],
            options={
                'verbose_name': 'Daily Close',
                'verbose_name_plural': 'Daily Closes',
                'ordering': ['-business_date'],
            },
        ),
    ]
