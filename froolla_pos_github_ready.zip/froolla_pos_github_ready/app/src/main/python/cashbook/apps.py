from django.apps import AppConfig


class CashbookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cashbook'
    verbose_name = 'Cash Book'

    def ready(self):
        """Wire up all signals once the app registry is fully loaded."""
        from .signals import register_signals
        register_signals()

        # Ensure default accounts exist, but only right after migrations
        # run (post_migrate) rather than on every process start. Querying
        # the DB directly inside ready() fires on *every* management
        # command — check, shell, test, runserver, etc. — which Django
        # itself warns against, and is unnecessary I/O on each worker boot
        # in production. post_migrate is the standard Django pattern for
        # this kind of idempotent startup data (it's how Django seeds its
        # own default permissions/content types).
        from django.db.models.signals import post_migrate

        def _ensure_default_accounts(sender, **kwargs):
            if sender.name != 'cashbook':
                return
            from .services import ensure_default_accounts
            ensure_default_accounts()

        post_migrate.connect(_ensure_default_accounts, sender=self)

        # Midnight auto-open scheduler — deliberately NOT hung off
        # post_migrate like the accounts bootstrap above. This app has
        # two real launch paths (see run_pos.py vs. run_production.bat)
        # and only one of them runs `migrate` in the same process as the
        # eventual server, so post_migrate isn't guaranteed to fire here.
        # Started straight from ready() instead; the scheduler's own
        # startup retry loop (see scheduler.py) tolerates migrations not
        # being applied yet if this happens to be a fresh install.
        #
        # Skipped for one-off management commands (migrate, test, shell,
        # etc.) so a stray background thread never spins up for something
        # that isn't actually going to serve requests.
        import sys
        _SKIP_FOR_COMMANDS = {
            'migrate', 'makemigrations', 'test', 'shell', 'dbshell',
            'collectstatic', 'createsuperuser', 'check', 'dumpdata',
            'loaddata', 'showmigrations', 'flush', 'startapp', 'startproject',
        }
        command = sys.argv[1] if len(sys.argv) > 1 else None
        if command not in _SKIP_FOR_COMMANDS:
            from .scheduler import start_midnight_scheduler
            start_midnight_scheduler()
