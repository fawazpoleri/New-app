"""cashbook URL configuration."""

from django.urls import path
from . import views

app_name = 'cashbook'

urlpatterns = [
    # Dashboard
    path('cash/',                   views.cash_dashboard,  name='cash_dashboard'),

    # Cash Book ledger
    path('cash/book/',              views.cashbook_list,   name='cashbook_list'),

    # Expenses
    path('cash/expenses/',          views.expense_list,    name='expense_list'),
    path('cash/expenses/add/',      views.expense_add,     name='expense_add'),

    # Other Income
    path('cash/income/',            views.income_list,     name='income_list'),
    path('cash/income/add/',        views.income_add,      name='income_add'),

    # Bank Transfer (admin)
    path('cash/transfer/',          views.bank_transfer,   name='bank_transfer'),

    # Adjustment (admin)
    path('cash/adjustment/',        views.adjustment,      name='adjustment'),

    # Correct a wrongly-entered payment method (any cashier, once per payment, locked after day close)
    path('cash/correct-payment/<int:order_id>/', views.correct_payment, name='correct_payment'),

    # Open Day (unlocks POS billing)
    path('cash/open/',              views.open_day,        name='open_day'),

    # Daily Close
    path('cash/close/',             views.daily_close,     name='daily_close'),
    path('cash/close/<str:business_date>/revert/', views.revert_close, name='revert_close'),

    # AJAX
    path('cash/api/balances/',      views.api_balances,    name='api_balances'),
]
