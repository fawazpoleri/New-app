"""
cashbook.views
--------------
Thin views — all business logic lives in cashbook.services.

Permission model:
  - Cashier (any authenticated, non-staff user): NO access to anything in
    this app. Cashiers are restricted to POS billing and Bill History
    only (enforced in billing.views / nav, not here).
  - Admin (is_staff): full access to every view below — Dashboard, Cash
    Book ledger, Expense, Income, Bank Transfer, Adjustment, Payment
    Correction, Open Day, Daily Close, and the balances API.
"""

from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils import timezone

from .forms import (
    AdjustmentForm, BankTransferForm, CashBookFilterForm,
    DailyCloseForm, ExpenseForm, OpenDayForm, OtherIncomeForm, PaymentCorrectionForm,
)
from .models import CashAccount, CashBook, DailyClose, Expense, OtherIncome
from . import services


# Single shared decorator stack for every view in this app — admin only.
# Non-staff users hitting any cashbook:* URL are redirected to the POS
# screen with a clear message rather than silently 403ing.
def admin_required(view_func):
    from functools import wraps

    @wraps(view_func)
    @login_required
    def _wrapped(request, *args, **kwargs):
        if not request.user.is_staff:
            messages.error(request, 'That area is for admin users only.')
            return redirect('billing:pos')
        return view_func(request, *args, **kwargs)
    return _wrapped


# ---------------------------------------------------------------------------
# Cash Dashboard (admin only)
# ---------------------------------------------------------------------------

@admin_required
def cash_dashboard(request):
    # Auto-rollover: makes sure today's business day exists (creating it
    # on the fly, carrying forward the float) so the dashboard reflects
    # the new day immediately after midnight even before any sale has
    # been rung up. Best-effort — dashboard should still render if this
    # ever fails for some reason.
    try:
        services.ensure_day_open(opened_by=request.user)
    except Exception:
        pass
    data = services.get_dashboard_data()
    return render(request, 'cashbook/dashboard.html', {
        'page_title': 'Cash Dashboard',
        **data,
    })


# ---------------------------------------------------------------------------
# Cash Book Ledger (filterable list, admin only)
# ---------------------------------------------------------------------------

@admin_required
def cashbook_list(request):
    from django.db.models import Sum

    from .models import PaymentCorrection

    form = CashBookFilterForm(request.GET or None)
    qs = CashBook.objects.select_related('account', 'created_by').order_by(
        '-transaction_datetime', '-id'
    )

    # Sale totals (Total Sale / Total Cash Sale / Total Bank Sale) always
    # reflect the selected date range, independent of the Type/Account
    # filters below — otherwise filtering the ledger down to just
    # "Expense" rows, or to a single account, would zero out the sale
    # summary instead of showing what actually sold in that period.
    sales_qs = CashBook.objects.filter(transaction_type=CashBook.TransactionType.POS_SALE)

    if form.is_valid():
        if form.cleaned_data.get('date_from'):
            qs = qs.filter(transaction_datetime__date__gte=form.cleaned_data['date_from'])
            sales_qs = sales_qs.filter(transaction_datetime__date__gte=form.cleaned_data['date_from'])
        if form.cleaned_data.get('date_to'):
            qs = qs.filter(transaction_datetime__date__lte=form.cleaned_data['date_to'])
            sales_qs = sales_qs.filter(transaction_datetime__date__lte=form.cleaned_data['date_to'])
        if form.cleaned_data.get('transaction_type'):
            qs = qs.filter(transaction_type=form.cleaned_data['transaction_type'])
        if form.cleaned_data.get('account'):
            qs = qs.filter(account=form.cleaned_data['account'])
        if form.cleaned_data.get('search'):
            qs = qs.filter(description__icontains=form.cleaned_data['search'])

    paginator = Paginator(qs, 50)
    page_obj = paginator.get_page(request.GET.get('page'))

    # Pre-compute which orders on this page already have a payment
    # correction, so the template can hide "Fix" on rows that no longer
    # need it (the reversal entry and the freshly re-posted entry both
    # carry transaction_type=POS_SALE / reference_type=POS for the same
    # order, but only the original mistake should ever show "Fix").
    order_ids_on_page = [
        e.reference_id for e in page_obj
        if e.transaction_type == CashBook.TransactionType.POS_SALE and e.reference_id
    ]
    corrected_order_ids = set(
        PaymentCorrection.objects.filter(
            order_id__in=order_ids_on_page
        ).values_list('order_id', flat=True)
    )
    closed_dates = set(
        DailyClose.objects.filter(
            status=DailyClose.Status.CLOSED,
            business_date__in=[e.transaction_datetime.date() for e in page_obj],
        ).values_list('business_date', flat=True)
    )

    cash_acct = CashAccount.objects.filter(name='Cash Drawer').first()
    bank_acct = CashAccount.objects.filter(name='Bank Account').first()

    # POS_SALE money_in is always positive (see record_pos_payments), so a
    # plain Sum per account gives the cash vs. bank sale split directly.
    cash_sale_total = sales_qs.filter(account=cash_acct).aggregate(t=Sum('money_in'))['t'] or 0 if cash_acct else 0
    bank_sale_total = sales_qs.filter(account=bank_acct).aggregate(t=Sum('money_in'))['t'] or 0 if bank_acct else 0
    total_sale = cash_sale_total + bank_sale_total

    return render(request, 'cashbook/cashbook_list.html', {
        'page_title': 'Cash Book',
        'form': form,
        'page_obj': page_obj,
        'cash_balance': cash_acct.current_balance if cash_acct else 0,
        'bank_balance': bank_acct.current_balance if bank_acct else 0,
        'total_sale': total_sale,
        'cash_sale_total': cash_sale_total,
        'bank_sale_total': bank_sale_total,
        'corrected_order_ids': corrected_order_ids,
        'closed_dates': closed_dates,
        'day_closed': services.is_day_closed(),
    })


# ---------------------------------------------------------------------------
# Expense (admin only)
# ---------------------------------------------------------------------------

@admin_required
def expense_list(request):
    from datetime import date as date_cls
    from django.db.models import Sum

    today = timezone.localdate()
    filter_date = today

    date_str = request.GET.get('date')
    if date_str:
        try:
            filter_date = date_cls.fromisoformat(date_str)
        except ValueError:
            filter_date = today

    expenses = Expense.objects.filter(expense_date=filter_date).select_related(
        'paid_from_account', 'created_by'
    )
    total_amount = expenses.aggregate(t=Sum('amount'))['t'] or 0

    return render(request, 'cashbook/expense_list.html', {
        'page_title': 'Expenses',
        'expenses': expenses,
        'total_amount': total_amount,
        'filter_date': filter_date,
        'today': today,
        'day_closed': services.is_day_closed(),
    })


@admin_required
def expense_add(request):
    if services.is_day_closed():
        messages.error(
            request,
            'Today\'s business day is closed. New entries are locked — only the '
            'summary is viewable. Open a new day, or revert the close, to continue.',
        )
        return redirect('cashbook:expense_list')

    if request.method == 'POST':
        form = ExpenseForm(request.POST, request.FILES)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.created_by = request.user
            try:
                with transaction.atomic():
                    expense.save()  # Signal fires synchronously → CashBook entry created
            except ValueError as exc:
                # Signal re-raises business-rule violations (e.g. insufficient
                # balance). Wrapping in transaction.atomic() here means that
                # if the signal's ledger write fails, the Expense row itself
                # is rolled back too — never an orphaned Expense with no
                # matching ledger entry.
                messages.error(request, str(exc))
                return render(request, 'cashbook/expense_form.html', {
                    'page_title': 'Add Expense',
                    'form': form,
                })
            messages.success(request, f'Expense of {expense.amount} ₹ recorded.')
            return redirect('cashbook:expense_list')
    else:
        form = ExpenseForm()

    return render(request, 'cashbook/expense_form.html', {
        'page_title': 'Add Expense',
        'form': form,
    })


# ---------------------------------------------------------------------------
# Other Income (admin only)
# ---------------------------------------------------------------------------

@admin_required
def income_list(request):
    from datetime import date as date_cls
    from django.db.models import Sum

    today = timezone.localdate()
    filter_date = today

    date_str = request.GET.get('date')
    if date_str:
        try:
            filter_date = date_cls.fromisoformat(date_str)
        except ValueError:
            filter_date = today

    incomes = OtherIncome.objects.filter(income_date=filter_date).select_related(
        'receive_account', 'created_by'
    )
    total_amount = incomes.aggregate(t=Sum('amount'))['t'] or 0

    return render(request, 'cashbook/income_list.html', {
        'page_title': 'Other Income',
        'incomes': incomes,
        'total_amount': total_amount,
        'filter_date': filter_date,
        'today': today,
        'day_closed': services.is_day_closed(),
    })


@admin_required
def income_add(request):
    if services.is_day_closed():
        messages.error(
            request,
            'Today\'s business day is closed. New entries are locked — only the '
            'summary is viewable. Open a new day, or revert the close, to continue.',
        )
        return redirect('cashbook:income_list')

    if request.method == 'POST':
        form = OtherIncomeForm(request.POST, request.FILES)
        if form.is_valid():
            income = form.save(commit=False)
            income.created_by = request.user
            try:
                with transaction.atomic():
                    income.save()  # Signal fires → CashBook entry created
            except Exception as exc:
                messages.error(request, f'Could not save income: {exc}')
                return render(request, 'cashbook/income_form.html', {
                    'page_title': 'Add Income',
                    'form': form,
                })
            messages.success(request, f'Income of {income.amount} ₹ recorded.')
            return redirect('cashbook:income_list')
    else:
        form = OtherIncomeForm()

    return render(request, 'cashbook/income_form.html', {
        'page_title': 'Add Income',
        'form': form,
    })


# ---------------------------------------------------------------------------
# Bank Transfer (admin only)
# ---------------------------------------------------------------------------

@admin_required
def bank_transfer(request):
    if services.is_day_closed():
        messages.error(
            request,
            'Today\'s business day is closed. Bank transfers are locked — only the '
            'Cash Book summary is viewable. Open a new day, or revert the close, to continue.',
        )
        return redirect('cashbook:cashbook_list')

    if request.method == 'POST':
        form = BankTransferForm(request.POST, request.FILES)
        if form.is_valid():
            direction = form.cleaned_data['direction']
            amount    = form.cleaned_data['amount']
            note      = form.cleaned_data['note']
            attachment = form.cleaned_data.get('attachment')

            try:
                if direction == 'deposit':
                    services.record_bank_deposit(amount, note, created_by=request.user, attachment=attachment)
                    messages.success(request, f'Deposited {amount} ₹ to bank.')
                else:
                    services.record_bank_withdrawal(amount, note, created_by=request.user, attachment=attachment)
                    messages.success(request, f'Withdrew {amount} ₹ from bank.')
            except ValueError as exc:
                messages.error(request, str(exc))
                return render(request, 'cashbook/bank_transfer.html', {
                    'page_title': 'Bank Transfer',
                    'form': form,
                })

            return redirect('cashbook:cashbook_list')
    else:
        form = BankTransferForm()

    return render(request, 'cashbook/bank_transfer.html', {
        'page_title': 'Bank Transfer',
        'form': form,
    })


# ---------------------------------------------------------------------------
# Adjustment (admin only)
# ---------------------------------------------------------------------------

@admin_required
def adjustment(request):
    if services.is_day_closed():
        messages.error(
            request,
            'Today\'s business day is closed. Adjustments are locked — only the '
            'Cash Book summary is viewable. Open a new day, or revert the close, to continue.',
        )
        return redirect('cashbook:cashbook_list')

    if request.method == 'POST':
        form = AdjustmentForm(request.POST)
        if form.is_valid():
            try:
                services.record_adjustment(
                    account=form.cleaned_data['account'],
                    amount=form.cleaned_data['amount'],
                    note=form.cleaned_data['note'],
                    created_by=request.user,
                )
            except ValueError as exc:
                messages.error(request, str(exc))
                return render(request, 'cashbook/adjustment.html', {
                    'page_title': 'Cash Adjustment',
                    'form': form,
                })
            messages.success(request, 'Adjustment recorded.')
            return redirect('cashbook:cashbook_list')
    else:
        form = AdjustmentForm()

    return render(request, 'cashbook/adjustment.html', {
        'page_title': 'Cash Adjustment',
        'form': form,
    })


# ---------------------------------------------------------------------------
# Payment Method Correction (admin only)
# ---------------------------------------------------------------------------

@admin_required
def correct_payment(request, order_id):
    """
    Fix a payment leg recorded under the wrong method (e.g. Cash instead
    of Card). Admin only.

    Locked out once:
      - the order's business date has been closed via Daily Close, OR
      - this specific payment leg has already been corrected once before
        (a second mistake on the same leg needs a manual Adjustment
        instead, to avoid endless back-and-forth flips polluting the
        ledger).

    Cash Book entries reference the Order (not the individual Payment leg),
    since one order can have several payment legs (split payment). If the
    order has exactly one payment leg, we go straight to the correction
    form. If it has more than one (split payment), the admin picks which
    leg to correct first.
    """
    from billing.models import Order
    from django.shortcuts import get_object_or_404
    from .models import PaymentCorrection

    order = get_object_or_404(Order, pk=order_id, status=Order.Status.PAID)
    legs = list(order.payments.all())

    if not legs:
        messages.error(request, f'No payment legs found for {order.bill_number}.')
        return redirect('cashbook:cashbook_list')

    # Lock check up front so the template can show a clear "day closed"
    # state instead of only surfacing the error after a failed submit.
    paid_date = order.paid_at.date() if order.paid_at else None
    day_closed = bool(
        paid_date and DailyClose.objects.filter(
            business_date=paid_date, status=DailyClose.Status.CLOSED
        ).exists()
    )

    payment_id = request.GET.get('payment_id') or request.POST.get('payment_id')
    payment = None
    if payment_id:
        payment = next((p for p in legs if p.pk == int(payment_id)), None)
    elif len(legs) == 1:
        payment = legs[0]

    if payment is None:
        # Split payment with no leg chosen yet — let the admin pick one.
        already_corrected_ids = set(
            PaymentCorrection.objects.filter(
                payment_id__in=[leg.pk for leg in legs]
            ).values_list('payment_id', flat=True)
        )
        return render(request, 'cashbook/correct_payment_pick_leg.html', {
            'page_title': 'Correct Payment Method',
            'order': order,
            'legs': legs,
            'is_locked': day_closed,
            'business_date': paid_date,
            'already_corrected_ids': already_corrected_ids,
        })

    already_corrected = PaymentCorrection.objects.filter(payment_id=payment.pk).exists()
    is_locked = day_closed or already_corrected

    if request.method == 'POST' and not is_locked:
        form = PaymentCorrectionForm(request.POST, current_method=payment.method)
        if form.is_valid():
            try:
                result = services.correct_payment_method(
                    payment=payment,
                    new_method=form.cleaned_data['new_method'],
                    corrected_by=request.user,
                )
                messages.success(
                    request,
                    f"Corrected {result['amount']} ₹ on {order.bill_number}: "
                    f"{result['old_method']} → {result['new_method']}."
                )
                return redirect('cashbook:cashbook_list')
            except ValueError as exc:
                messages.error(request, str(exc))
    else:
        form = PaymentCorrectionForm(current_method=payment.method)

    return render(request, 'cashbook/correct_payment.html', {
        'page_title': 'Correct Payment Method',
        'form': form,
        'payment': payment,
        'order': order,
        'is_locked': is_locked,
        'day_closed': day_closed,
        'already_corrected': already_corrected,
        'business_date': paid_date,
    })


# ---------------------------------------------------------------------------
# Open Day (gate for POS billing — admin only)
# ---------------------------------------------------------------------------

@admin_required
def open_day(request):
    """
    Opens a business day so POS billing is unlocked. Admin only.

    Normally this opens "today" (calendar date). But if today's business
    date has already been closed (e.g. an early EOD close), there is no
    valid "today" left to open — so this falls forward to the next
    business date right after the latest closed day, and offers that as
    "Open Next Day" instead of dead-ending the admin with no way forward.
    Pre-fills the opening cash float with what the service layer computes
    as the carry-forward amount, but lets the admin override it in case
    the float was topped up/changed before the shift.
    """
    today = timezone.localdate()

    open_record = DailyClose.objects.filter(status=DailyClose.Status.OPEN).first()
    if open_record:
        # Already open — nothing to do, just show the state.
        return render(request, 'cashbook/open_day.html', {
            'page_title': 'Open Day',
            'today': open_record.business_date,
            'already_open': open_record,
        })

    latest_closed = (
        DailyClose.objects.filter(status=DailyClose.Status.CLOSED)
        .order_by('-business_date')
        .first()
    )
    # The date we're actually about to open: today, unless today (or a
    # later date) is already closed, in which case fall forward to the
    # day right after the latest close.
    if latest_closed and latest_closed.business_date >= today:
        target_date = latest_closed.business_date + timezone.timedelta(days=1)
    else:
        target_date = today

    # Compute the suggested opening float the same way the service does,
    # purely for display/pre-fill — the actual value used is whatever the
    # form submits.
    if latest_closed:
        suggested_float = latest_closed.counted_cash
    else:
        cash_acct = CashAccount.objects.filter(name='Cash Drawer').first()
        suggested_float = cash_acct.opening_balance if cash_acct else Decimal('0.00')

    if request.method == 'POST':
        form = OpenDayForm(request.POST)
        if form.is_valid():
            try:
                services.open_day(
                    business_date=target_date,
                    opened_by=request.user,
                    opening_cash=form.cleaned_data['opening_cash'],
                )
                messages.success(request, f'Business day {target_date} is now open. Billing is unlocked.')
                return redirect('billing:pos')
            except ValueError as exc:
                messages.error(request, str(exc))
    else:
        form = OpenDayForm(initial={'opening_cash': suggested_float})

    return render(request, 'cashbook/open_day.html', {
        'page_title': 'Open Day',
        'form': form,
        'today': target_date,
        'is_next_day': latest_closed is not None and target_date != today,
        'latest_closed': latest_closed,
        'suggested_float': suggested_float,
        'already_open': None,
    })


# ---------------------------------------------------------------------------
# Daily Close (admin only)
# ---------------------------------------------------------------------------

@admin_required
def daily_close(request):
    """
    End of Day closing screen. Admin only.

    Defaults to whichever business date is currently OPEN (the day that
    actually needs closing) rather than blindly using calendar "today" —
    those can diverge once a day has been closed and the next business
    day opened (the next business date doesn't roll over until the admin
    explicitly opens it, which can happen same-calendar-day via "Open
    Next Day"). Falls back to calendar today only if no day is open at
    all (e.g. nothing has ever been opened yet).

    Accepts ?date=YYYY-MM-DD so an admin can navigate to and review/close
    any specific business date — including one later than calendar today,
    which can legitimately happen via the "Open Next Day" flow.
    """
    from datetime import date as date_cls

    today = timezone.localdate()
    open_record = DailyClose.objects.filter(status=DailyClose.Status.OPEN).first()
    business_date = open_record.business_date if open_record else today

    date_str = request.GET.get('date')
    if date_str:
        try:
            business_date = date_cls.fromisoformat(date_str)
        except ValueError:
            pass

    already_closed = DailyClose.objects.filter(
        business_date=business_date, status=DailyClose.Status.CLOSED
    ).first()

    summary = services.get_today_summary(business_date)

    if request.method == 'POST' and not already_closed:
        form = DailyCloseForm(request.POST)
        if form.is_valid():
            try:
                close = services.perform_daily_close(
                    business_date=business_date,
                    counted_cash=form.cleaned_data['counted_cash'],
                    closed_by=request.user,
                )
                messages.success(
                    request,
                    f'Business day {business_date} closed successfully. '
                    f'Difference: {close.difference:+.2f} ₹.'
                )
                return redirect(f"{request.path}?date={business_date.isoformat()}")
            except ValueError as exc:
                messages.error(request, str(exc))
    else:
        form = DailyCloseForm()

    history = DailyClose.objects.order_by('-business_date')[:14]

    return render(request, 'cashbook/daily_close.html', {
        'page_title': 'End of Day Closing',
        'form': form,
        'summary': summary,
        'today': business_date,
        'is_today': business_date == today,
        'is_past': business_date < today,
        'is_future': business_date > today,
        'already_closed': already_closed,
        'can_revert': bool(
            already_closed and not DailyClose.objects.filter(
                business_date__gt=business_date,
            ).exists()
        ),
        'history': history,
    })


# ---------------------------------------------------------------------------
# Revert Daily Close (admin only, last-closed-day only)
# ---------------------------------------------------------------------------

@admin_required
def revert_close(request, business_date):
    """
    Undo a Daily Close (POST only). Only ever reverts the most recently
    closed business day — services.revert_daily_close enforces that.
    """
    from datetime import date as date_cls

    if request.method != 'POST':
        return redirect('cashbook:daily_close')

    try:
        parsed_date = date_cls.fromisoformat(business_date)
    except ValueError:
        messages.error(request, 'Invalid date.')
        return redirect('cashbook:daily_close')

    try:
        services.revert_daily_close(parsed_date, reverted_by=request.user)
        messages.success(
            request,
            f'Business day {parsed_date} has been reopened. You can now make '
            f'corrections and re-close it when ready.',
        )
    except ValueError as exc:
        messages.error(request, str(exc))

    return redirect(f"{reverse('cashbook:daily_close')}?date={parsed_date.isoformat()}")


# ---------------------------------------------------------------------------
# AJAX: live balance for dashboard (admin only)
# ---------------------------------------------------------------------------

@admin_required
def api_balances(request):
    """Simple JSON endpoint so the dashboard can refresh balances without reload."""
    cash_acct = CashAccount.objects.filter(name='Cash Drawer').first()
    bank_acct = CashAccount.objects.filter(name='Bank Account').first()
    return JsonResponse({
        'cash_balance': str(cash_acct.current_balance) if cash_acct else '0.000',
        'bank_balance': str(bank_acct.current_balance) if bank_acct else '0.000',
    })
