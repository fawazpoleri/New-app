"""
Cash Book app models.

Tables
------
CashAccount   – cash drawer and bank account definitions
CashBook      – immutable ledger of every money movement (single source of truth)
Expense       – expense records; auto-create CashBook debit
OtherIncome   – non-POS income; auto-create CashBook credit
DailyClose    – one EOD record per business date; locks the day

All monetary fields use DecimalField — never float.
All datetimes are timezone-aware.
"""

import re
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.utils import timezone


# ---------------------------------------------------------------------------
# Cash Account
# ---------------------------------------------------------------------------

class CashAccount(models.Model):
    """
    Represents a physical money container — the cash drawer or a bank account.
    Opening balance is set once; current_balance is updated by every CashBook entry.
    """

    class AccountType(models.TextChoices):
        CASH = 'CASH', 'Cash'
        BANK = 'BANK', 'Bank'

    name = models.CharField(max_length=100, unique=True)
    account_type = models.CharField(
        max_length=10,
        choices=AccountType.choices,
        default=AccountType.CASH,
    )
    opening_balance = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal('0.00'),
        help_text='Starting balance when the account was first activated.',
    )
    current_balance = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal('0.00'),
        help_text='Running balance kept in sync by every CashBook entry.',
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['account_type', 'name']
        verbose_name = 'Cash Account'
        verbose_name_plural = 'Cash Accounts'

    def __str__(self) -> str:
        return f'{self.name} ({self.get_account_type_display()})'


# ---------------------------------------------------------------------------
# Cash Book
# ---------------------------------------------------------------------------

class CashBook(models.Model):
    """
    Immutable ledger entry. One row per money movement event.

    Rules:
    - POS_SALE entries are created automatically by a signal; never edited.
    - Every entry carries a running balance_after so the ledger is self-verifiable.
    - Soft-delete is NOT implemented; entries are permanent.
    """

    class TransactionType(models.TextChoices):
        OPENING    = 'OPENING',    'Opening Balance'
        POS_SALE   = 'POS_SALE',   'POS Sale'
        OTHER_INCOME = 'OTHER_INCOME', 'Other Income'
        EXPENSE    = 'EXPENSE',    'Expense'
        BANK_DEPOSIT  = 'BANK_DEPOSIT',  'Bank Deposit'
        BANK_WITHDRAW = 'BANK_WITHDRAW', 'Bank Withdrawal'
        ADJUSTMENT = 'ADJUSTMENT', 'Adjustment'
        CLOSING    = 'CLOSING',    'Closing'

    class ReferenceType(models.TextChoices):
        POS      = 'POS',      'POS Sale'
        EXPENSE  = 'EXPENSE',  'Expense'
        INCOME   = 'INCOME',   'Other Income'
        TRANSFER = 'TRANSFER', 'Bank Transfer'
        MANUAL   = 'MANUAL',   'Manual'

    transaction_datetime = models.DateTimeField(default=timezone.now, db_index=True)
    account = models.ForeignKey(
        CashAccount,
        on_delete=models.PROTECT,
        related_name='entries',
    )
    transaction_type = models.CharField(
        max_length=20, choices=TransactionType.choices,
    )
    reference_type = models.CharField(
        max_length=10, choices=ReferenceType.choices, default=ReferenceType.MANUAL,
    )
    # Nullable FK-like field; kept as IntegerField to avoid cross-app FKs
    reference_id = models.PositiveIntegerField(null=True, blank=True)

    description = models.CharField(max_length=255)
    money_in  = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    money_out = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    balance_after = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal('0.00'),
        help_text='Account balance immediately after this transaction.',
    )
    attachment = models.FileField(
        upload_to='cashbook/supporting_documents/%Y/%m/',
        blank=True, null=True,
        help_text='Optional supporting document (receipt, invoice, transfer slip, etc.) for this entry.',
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True, blank=True,
        related_name='cashbook_entries',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-transaction_datetime', '-id']
        verbose_name = 'Cash Book Entry'
        verbose_name_plural = 'Cash Book'

    def __str__(self) -> str:
        direction = f'+{self.money_in}' if self.money_in else f'-{self.money_out}'
        return f'{self.transaction_datetime:%Y-%m-%d %H:%M} | {self.get_transaction_type_display()} | {direction}'

    # Regex fallbacks for pulling the raw payment method (Cash/Card/UPI)
    # back out of the description text — see record_pos_payments() and
    # correct_payment_method() in services.py for the exact phrasings.
    _MODE_RE_NEW_SALE = re.compile(r'^(Cash|Card|UPI) sale', re.IGNORECASE)
    _MODE_RE_CORRECTION = re.compile(r're-posting as (CASH|CARD|UPI)', re.IGNORECASE)

    @property
    def payment_mode(self):
        """
        Human-readable payment mode ('Cash', 'Card', or 'UPI') for a POS
        sale entry. Returns None for every other transaction type (an
        Expense, Adjustment, Bank Transfer, etc. has no "payment mode" —
        that concept only applies to money coming in from a customer bill).

        CashBook doesn't store the raw Payment.method directly (one
        CashBook account — Bank Account — covers both Card and UPI), so
        this is recovered from the entry's description, which always
        records the exact method at posting time. Falls back to the
        account's broad type (Cash vs Bank) only in the unlikely case the
        description doesn't match either known phrasing.
        """
        if self.transaction_type != self.TransactionType.POS_SALE:
            return None

        match = self._MODE_RE_NEW_SALE.match(self.description)
        if match:
            return match.group(1).capitalize() if match.group(1).upper() != 'UPI' else 'UPI'

        match = self._MODE_RE_CORRECTION.search(self.description)
        if match:
            raw = match.group(1).upper()
            return 'UPI' if raw == 'UPI' else raw.capitalize()

        return 'Cash' if self.account.account_type == CashAccount.AccountType.CASH else 'Bank'


# ---------------------------------------------------------------------------
# Expense
# ---------------------------------------------------------------------------

class Expense(models.Model):
    """
    An operational expense paid out of cash or bank.
    Saving an Expense record automatically creates a CashBook debit via signal.
    """

    CATEGORY_CHOICES = [
        ('SUPPLIES',    'Supplies'),
        ('UTILITIES',   'Utilities'),
        ('MAINTENANCE', 'Maintenance'),
        ('SALARY',      'Salary / Wages'),
        ('TRANSPORT',   'Transport'),
        ('MARKETING',   'Marketing'),
        ('FOOD_RAW',    'Raw Materials / Food'),
        ('OTHER',       'Other'),
    ]

    expense_date = models.DateField(default=timezone.localdate, db_index=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='OTHER')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    paid_from_account = models.ForeignKey(
        CashAccount,
        on_delete=models.PROTECT,
        related_name='expenses',
    )
    note = models.CharField(max_length=255, blank=True)
    attachment = models.FileField(
        upload_to='cashbook/expenses/%Y/%m/',
        blank=True, null=True,
        help_text='Optional supporting document (bill, receipt, invoice) for this expense.',
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='expenses',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-expense_date', '-created_at']
        verbose_name = 'Expense'
        verbose_name_plural = 'Expenses'

    def __str__(self) -> str:
        return f'{self.get_category_display()} — {self.amount} ₹ ({self.expense_date})'


# ---------------------------------------------------------------------------
# Other Income
# ---------------------------------------------------------------------------

class OtherIncome(models.Model):
    """
    Non-POS income: catering deposits, refunds received, grants, etc.
    Saving an OtherIncome record automatically creates a CashBook credit via signal.
    """

    CATEGORY_CHOICES = [
        ('CATERING',  'Catering / Event'),
        ('DELIVERY',  'Delivery Commission'),
        ('REFUND_IN', 'Supplier Refund'),
        ('INTEREST',  'Bank Interest'),
        ('OTHER',     'Other'),
    ]

    income_date = models.DateField(default=timezone.localdate, db_index=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='OTHER')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    receive_account = models.ForeignKey(
        CashAccount,
        on_delete=models.PROTECT,
        related_name='other_incomes',
    )
    note = models.CharField(max_length=255, blank=True)
    attachment = models.FileField(
        upload_to='cashbook/incomes/%Y/%m/',
        blank=True, null=True,
        help_text='Optional supporting document (receipt, deposit slip, invoice) for this income.',
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='other_incomes',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-income_date', '-created_at']
        verbose_name = 'Other Income'
        verbose_name_plural = 'Other Incomes'

    def __str__(self) -> str:
        return f'{self.get_category_display()} — {self.amount} ₹ ({self.income_date})'


# ---------------------------------------------------------------------------
# Daily Close
# ---------------------------------------------------------------------------

class DailyClose(models.Model):
    """
    One record per business_date, covering its full lifecycle:

      OPEN day created explicitly via "Open Day" (sets opening_cash,
      records who/when opened) → POS billing is allowed only while this
      row exists with status=OPEN → cashier runs End of Day, which fills
      in all the calculated totals and flips status to CLOSED, locking
      the day permanently.

    Exactly one record per business_date — enforced by the unique
    constraint on business_date.
    """

    class Status(models.TextChoices):
        OPEN   = 'OPEN',   'Open'
        CLOSED = 'CLOSED', 'Closed'

    business_date  = models.DateField(unique=True)

    # Set at Open Day time
    opening_cash   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    opened_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True, blank=True,
        related_name='daily_opens',
    )
    opened_at = models.DateTimeField(null=True, blank=True)

    # Auto-calculated totals populated when the cashier opens the EOD screen
    cash_sales     = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    card_sales     = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    upi_sales      = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    other_income   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    expenses       = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    cash_deposit   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    cash_withdraw  = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))

    # System calculates; cashier enters counted_cash
    expected_cash  = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    counted_cash   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    difference     = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))

    status = models.CharField(
        max_length=10, choices=Status.choices, default=Status.OPEN,
    )
    closed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True, blank=True,
        related_name='daily_closes',
    )
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-business_date']
        verbose_name = 'Daily Close'
        verbose_name_plural = 'Daily Closes'

    def __str__(self) -> str:
        return f'EOD {self.business_date} — {self.get_status_display()}'


# ---------------------------------------------------------------------------
# Payment Correction (audit trail + one-correction-per-payment guard)
# ---------------------------------------------------------------------------

class PaymentCorrection(models.Model):
    """
    Records that a given Payment leg's method was self-corrected by a
    cashier (not an admin Adjustment). One row per correction performed.

    A Payment can only be self-corrected ONCE through the cashier-facing
    "Fix" flow — after that, the corrected entry is locked from further
    self-service edits to prevent endless back-and-forth flips that would
    pollute the ledger. Any further fix must go through admin Adjustment.

    We can't add a field directly onto payments.Payment (kept untouched
    per the "do not modify existing billing logic" rule), so this side
    table tracks the same information without touching that app.
    """

    payment_id = models.PositiveIntegerField(
        unique=True,
        help_text='payments.Payment.id that was corrected. Unique — one correction per payment leg.',
    )
    order_id = models.PositiveIntegerField(
        help_text='billing.Order.id this payment belongs to, denormalized for quick lookup.',
    )
    old_method = models.CharField(max_length=10)
    new_method = models.CharField(max_length=10)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    corrected_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='payment_corrections',
    )
    corrected_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-corrected_at']
        verbose_name = 'Payment Correction'
        verbose_name_plural = 'Payment Corrections'

    def __str__(self) -> str:
        return f'Order #{self.order_id}: {self.old_method} → {self.new_method} ({self.amount} ₹)'
