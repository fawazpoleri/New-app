"""
cashbook.services
-----------------
All business logic for the Cash Book module lives here.

Design principles:
- Every public function is atomic (wrapped in transaction.atomic).
- Views and signals call services; services never call views.
- No raw SQL — only ORM with select_for_update where race-conditions matter.
- All monetary arithmetic uses Decimal; never float.
"""

import logging
from decimal import Decimal
from typing import Optional

from django.db import transaction
from django.utils import timezone

from payments.models import Payment
from .models import CashAccount, CashBook, DailyClose, Expense, OtherIncome

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_cash_account() -> CashAccount:
    """Return the default Cash Drawer account, creating it if missing."""
    account, _ = CashAccount.objects.get_or_create(
        name='Cash Drawer',
        defaults={'account_type': CashAccount.AccountType.CASH, 'is_active': True},
    )
    return account


def _get_bank_account() -> CashAccount:
    """Return the default Bank Account, creating it if missing."""
    account, _ = CashAccount.objects.get_or_create(
        name='Bank Account',
        defaults={'account_type': CashAccount.AccountType.BANK, 'is_active': True},
    )
    return account


@transaction.atomic
def _post_entry(
    account: CashAccount,
    transaction_type: str,
    reference_type: str,
    description: str,
    money_in: Decimal,
    money_out: Decimal,
    reference_id: Optional[int] = None,
    created_by=None,
    transaction_datetime=None,
    allow_negative: bool = False,
    attachment=None,
) -> CashBook:
    """
    Core ledger writer. Locks the account row, computes balance_after,
    writes the CashBook entry, then updates account.current_balance.
    Called by every other service function — never directly from views.

    By default, raises ValueError if the entry would drive the account
    balance negative (e.g. an expense bigger than what's in the drawer).
    Pass allow_negative=True only for ADJUSTMENT/reversal entries, where
    going negative may be a legitimate correction of a prior mistake.
    """
    # Lock the account to prevent concurrent balance drift
    account = CashAccount.objects.select_for_update().get(pk=account.pk)

    balance_after = account.current_balance + money_in - money_out

    if not allow_negative and balance_after < Decimal('0.00'):
        raise ValueError(
            f'This would make {account.name} go negative '
            f'(balance would be {balance_after} ₹). Action blocked.'
        )

    entry = CashBook.objects.create(
        transaction_datetime=transaction_datetime or timezone.now(),
        account=account,
        transaction_type=transaction_type,
        reference_type=reference_type,
        reference_id=reference_id,
        description=description,
        money_in=money_in,
        money_out=money_out,
        balance_after=balance_after,
        created_by=created_by,
        attachment=attachment or None,
    )

    # Keep account balance in sync
    account.current_balance = balance_after
    account.save(update_fields=['current_balance', 'updated_at'])

    return entry


# ---------------------------------------------------------------------------
# Account bootstrap (called from apps.ready or management command)
# ---------------------------------------------------------------------------

def ensure_default_accounts() -> None:
    """
    Ensure the two default accounts exist.
    Safe to call multiple times — idempotent.
    """
    _get_cash_account()
    _get_bank_account()


# ---------------------------------------------------------------------------
# Rule 1-3: POS Sale → Cash Book
# ---------------------------------------------------------------------------

@transaction.atomic
def record_pos_payments(order, created_by=None, outside_open_day: bool = False) -> list[CashBook]:
    """
    Called after an Order is marked PAID.
    Creates one CashBook entry per payment leg:
      - CASH → Cash Drawer (money_in)
      - CARD → Bank Account (money_in)
      - UPI  → Bank Account (money_in)

    Rule 4 (split payment) is handled automatically — we iterate all legs.

    Each leg is posted at its *net applied* amount (see
    `Order.net_applied_payments`), not the raw tendered amount — a cash
    leg that included change for the customer must not inflate cash
    sales / the cash drawer's money_in by the change amount. `Payment`
    rows themselves are left untouched (they still hold what was actually
    tendered, which the receipt needs), only the ledger posting is net.

    outside_open_day=True flags entries created when no Open Day record
    existed for today (e.g. an Order marked PAID via Django admin instead
    of the normal POS/PaymentView flow, which already enforces the gate).
    We still record the money — it genuinely moved — but mark it clearly
    so it's caught during reconciliation rather than blending in silently.
    """
    import logging
    logger = logging.getLogger(__name__)

    cash_acct = _get_cash_account()
    bank_acct = _get_bank_account()
    entries = []
    flag = ' [⚠ OUTSIDE OPEN DAY — review]' if outside_open_day else ''

    for payment, amount in order.net_applied_payments():
        if amount <= 0:
            # Fully absorbed by change given back to the customer —
            # nothing actually landed in any account for this leg.
            continue
        method_display = payment.get_method_display()

        if payment.method == Payment.Method.CASH:
            account = cash_acct
            tx_type = CashBook.TransactionType.POS_SALE
            desc = f'Cash sale — {order.bill_number} ({method_display}){flag}'
        elif payment.method in (Payment.Method.CARD, Payment.Method.UPI):
            account = bank_acct
            tx_type = CashBook.TransactionType.POS_SALE
            desc = f'{method_display} sale — {order.bill_number}{flag}'
        else:
            # An unrecognized payment method should never silently vanish
            # from the books — that's real money the cash book would
            # otherwise never account for. Log loudly so it surfaces in
            # monitoring/alerts even though we can't guess which account
            # it belongs in.
            logger.error(
                'CashBook: order %s has payment leg with unrecognized method %r '
                '(amount %s) — NOT recorded in any ledger account. Needs manual review.',
                order.bill_number, payment.method, amount,
            )
            continue

        entry = _post_entry(
            account=account,
            transaction_type=tx_type,
            reference_type=CashBook.ReferenceType.POS,
            description=desc,
            money_in=amount,
            money_out=Decimal('0.00'),
            reference_id=order.pk,
            created_by=created_by,
            transaction_datetime=order.paid_at or timezone.now(),
        )
        entries.append(entry)

    return entries


# ---------------------------------------------------------------------------
# Rule 5: Expense → Cash Book
# ---------------------------------------------------------------------------

@transaction.atomic
def record_expense(expense: Expense) -> CashBook:
    """
    Creates a CashBook debit for a saved Expense.
    Called by the post_save signal — do not call directly from the view.
    """
    return _post_entry(
        account=expense.paid_from_account,
        transaction_type=CashBook.TransactionType.EXPENSE,
        reference_type=CashBook.ReferenceType.EXPENSE,
        description=f'Expense: {expense.get_category_display()} — {expense.note or ""}',
        money_in=Decimal('0.00'),
        money_out=expense.amount,
        reference_id=expense.pk,
        created_by=expense.created_by,
        attachment=expense.attachment or None,
    )


@transaction.atomic
def adjust_expense_entry(expense: Expense, old_amount: Decimal, old_account_id: Optional[int]) -> tuple[CashBook, CashBook]:
    """
    Corrects the ledger after an already-recorded Expense is edited
    (amount and/or paid_from_account changed). Called by the post_save
    signal — do not call directly from a view.

    Keeps the ledger append-only, exactly mirroring correct_payment_method:
    never edit or delete the original entry, instead reverse its old
    effect and post the corrected one. This is what keeps the Expenses
    Report (which always reads Expense.amount live) reconciled with the
    Cash Book / Expected Cash after a correction.
    """
    old_account = (
        CashAccount.objects.get(pk=old_account_id) if old_account_id else expense.paid_from_account
    )

    # 1. Reverse the old expense amount on the account it was originally
    #    charged to (money back in — undoing the original debit).
    reversal_entry = _post_entry(
        account=old_account,
        transaction_type=CashBook.TransactionType.ADJUSTMENT,
        reference_type=CashBook.ReferenceType.EXPENSE,
        description=(
            f'Correction: reversing prior amount ({old_amount} ₹) for edited '
            f'Expense #{expense.pk} ({expense.get_category_display()})'
        ),
        money_in=old_amount,
        money_out=Decimal('0.00'),
        reference_id=expense.pk,
        created_by=expense.created_by,
        allow_negative=True,
    )

    # 2. Post the corrected amount on the (possibly new) account.
    correction_entry = _post_entry(
        account=expense.paid_from_account,
        transaction_type=CashBook.TransactionType.EXPENSE,
        reference_type=CashBook.ReferenceType.EXPENSE,
        description=(
            f'Correction: re-posting edited amount ({expense.amount} ₹) — '
            f'{expense.get_category_display()} #{expense.pk}'
        ),
        money_in=Decimal('0.00'),
        money_out=expense.amount,
        reference_id=expense.pk,
        created_by=expense.created_by,
    )
    return reversal_entry, correction_entry


# ---------------------------------------------------------------------------
# Rule 6: Other Income → Cash Book
# ---------------------------------------------------------------------------

@transaction.atomic
def record_other_income(income: OtherIncome) -> CashBook:
    """
    Creates a CashBook credit for a saved OtherIncome record.
    Called by the post_save signal — do not call directly from the view.
    """
    return _post_entry(
        account=income.receive_account,
        transaction_type=CashBook.TransactionType.OTHER_INCOME,
        reference_type=CashBook.ReferenceType.INCOME,
        description=f'Income: {income.get_category_display()} — {income.note or ""}',
        money_in=income.amount,
        money_out=Decimal('0.00'),
        reference_id=income.pk,
        created_by=income.created_by,
        attachment=income.attachment or None,
    )


@transaction.atomic
def adjust_income_entry(income: OtherIncome, old_amount: Decimal, old_account_id: Optional[int]) -> tuple[CashBook, CashBook]:
    """
    Corrects the ledger after an already-recorded OtherIncome is edited
    (amount and/or receive_account changed). Mirror of
    adjust_expense_entry — see that function's docstring for the rationale.
    """
    old_account = (
        CashAccount.objects.get(pk=old_account_id) if old_account_id else income.receive_account
    )

    # 1. Reverse the old income amount on the account it was originally
    #    credited to (money back out — undoing the original credit).
    reversal_entry = _post_entry(
        account=old_account,
        transaction_type=CashBook.TransactionType.ADJUSTMENT,
        reference_type=CashBook.ReferenceType.INCOME,
        description=(
            f'Correction: reversing prior amount ({old_amount} ₹) for edited '
            f'Income #{income.pk} ({income.get_category_display()})'
        ),
        money_in=Decimal('0.00'),
        money_out=old_amount,
        reference_id=income.pk,
        created_by=income.created_by,
        allow_negative=True,
    )

    # 2. Post the corrected amount on the (possibly new) account.
    correction_entry = _post_entry(
        account=income.receive_account,
        transaction_type=CashBook.TransactionType.OTHER_INCOME,
        reference_type=CashBook.ReferenceType.INCOME,
        description=(
            f'Correction: re-posting edited amount ({income.amount} ₹) — '
            f'{income.get_category_display()} #{income.pk}'
        ),
        money_in=income.amount,
        money_out=Decimal('0.00'),
        reference_id=income.pk,
        created_by=income.created_by,
    )
    return reversal_entry, correction_entry


# ---------------------------------------------------------------------------
# Rules 7 & 8: Bank Transfer (Deposit / Withdrawal)
# ---------------------------------------------------------------------------

@transaction.atomic
def record_bank_deposit(amount: Decimal, note: str, created_by=None, attachment=None) -> tuple[CashBook, CashBook]:
    """
    Rule 7: Move cash from the drawer into the bank.
    Creates two entries:
      1. Cash Drawer  → money_out
      2. Bank Account → money_in

    attachment (optional) is the supporting document (deposit slip, bank
    receipt, etc.) for this transfer — stored on both legs of the entry
    so it surfaces wherever either account's ledger is viewed.
    """
    cash_acct = _get_cash_account()
    bank_acct = _get_bank_account()
    now = timezone.now()

    cash_entry = _post_entry(
        account=cash_acct,
        transaction_type=CashBook.TransactionType.BANK_DEPOSIT,
        reference_type=CashBook.ReferenceType.TRANSFER,
        description=f'Cash deposit to bank — {note}',
        money_in=Decimal('0.00'),
        money_out=amount,
        created_by=created_by,
        transaction_datetime=now,
        attachment=attachment,
    )
    bank_entry = _post_entry(
        account=bank_acct,
        transaction_type=CashBook.TransactionType.BANK_DEPOSIT,
        reference_type=CashBook.ReferenceType.TRANSFER,
        description=f'Cash deposit from drawer — {note}',
        money_in=amount,
        money_out=Decimal('0.00'),
        created_by=created_by,
        transaction_datetime=now,
        attachment=attachment,
    )
    return cash_entry, bank_entry


@transaction.atomic
def record_bank_withdrawal(amount: Decimal, note: str, created_by=None, attachment=None) -> tuple[CashBook, CashBook]:
    """
    Rule 8: Withdraw cash from bank into the drawer.
    Creates two entries:
      1. Bank Account → money_out
      2. Cash Drawer  → money_in

    attachment (optional) is the supporting document for this transfer —
    stored on both legs, mirroring record_bank_deposit.
    """
    cash_acct = _get_cash_account()
    bank_acct = _get_bank_account()
    now = timezone.now()

    bank_entry = _post_entry(
        account=bank_acct,
        transaction_type=CashBook.TransactionType.BANK_WITHDRAW,
        reference_type=CashBook.ReferenceType.TRANSFER,
        description=f'Bank withdrawal to drawer — {note}',
        money_in=Decimal('0.00'),
        money_out=amount,
        created_by=created_by,
        transaction_datetime=now,
        attachment=attachment,
    )
    cash_entry = _post_entry(
        account=cash_acct,
        transaction_type=CashBook.TransactionType.BANK_WITHDRAW,
        reference_type=CashBook.ReferenceType.TRANSFER,
        description=f'Bank withdrawal received — {note}',
        money_in=amount,
        money_out=Decimal('0.00'),
        created_by=created_by,
        transaction_datetime=now,
        attachment=attachment,
    )
    return bank_entry, cash_entry


# ---------------------------------------------------------------------------
# Rule 9: Manual Adjustment (admin only)
# ---------------------------------------------------------------------------

@transaction.atomic
def record_adjustment(
    account: CashAccount,
    amount: Decimal,
    note: str,
    created_by=None,
) -> CashBook:
    """
    Positive amount = money_in (upward correction).
    Negative amount = money_out (downward correction).
    Note is mandatory — enforced in the form.
    """
    if amount >= 0:
        entry = _post_entry(
            account=account,
            transaction_type=CashBook.TransactionType.ADJUSTMENT,
            reference_type=CashBook.ReferenceType.MANUAL,
            description=f'Adjustment (+): {note}',
            money_in=amount,
            money_out=Decimal('0.00'),
            created_by=created_by,
            allow_negative=True,
        )
    else:
        entry = _post_entry(
            account=account,
            transaction_type=CashBook.TransactionType.ADJUSTMENT,
            reference_type=CashBook.ReferenceType.MANUAL,
            description=f'Adjustment (−): {note}',
            money_in=Decimal('0.00'),
            money_out=abs(amount),
            created_by=created_by,
            allow_negative=True,
        )
    return entry


@transaction.atomic
def correct_payment_method(payment, new_method: str, corrected_by=None) -> dict:
    """
    Fixes a cashier mistake where a payment leg was recorded under the
    wrong method (e.g. CASH instead of CARD).

    This NEVER edits or deletes the original CashBook entry — the ledger
    stays append-only and fully auditable. Instead it:

      1. Posts a REVERSAL entry on the original account (cancels the
         wrong entry, money flows back out).
      2. Updates the Payment row's method (so future reports/EOD sums
         use the corrected method).
      3. Posts a fresh POS_SALE entry on the correct account.
      4. Records a PaymentCorrection row, which also acts as a guard:
         each payment leg can only be self-corrected ONCE through this
         flow. A second mistake on the same leg requires an admin
         Adjustment — this prevents endless back-and-forth flips that
         would otherwise be possible by simply re-opening the Fix screen.

    Raises ValueError if:
      - new_method matches the existing method,
      - the order's business date has already been closed,
      - this payment has already been self-corrected once before.
    """
    from .models import PaymentCorrection

    if new_method == payment.method:
        raise ValueError('New payment method is the same as the current one.')

    if new_method not in Payment.Method.values:
        raise ValueError(f'Invalid payment method: {new_method}')

    if PaymentCorrection.objects.filter(payment_id=payment.pk).exists():
        raise ValueError(
            'This payment has already been corrected once. '
            'Further changes require an admin Cash Adjustment.'
        )

    order = payment.order

    # Guard: don't let a correction silently change figures on a day
    # that has already been closed and reconciled.
    paid_date = order.paid_at.date() if order.paid_at else None
    if paid_date and DailyClose.objects.filter(
        business_date=paid_date, status=DailyClose.Status.CLOSED
    ).exists():
        raise ValueError(
            f'Cannot correct this payment — business date {paid_date} is already closed. '
            'Use a manual Adjustment instead.'
        )

    old_method = payment.method
    raw_amount = payment.amount
    # The ledger only ever had the *net* amount posted for this leg (see
    # record_pos_payments / Order.net_applied_payments) — if this leg
    # included change given back to the customer, raw_amount overstates
    # what actually moved. Reverse/repost the net amount so the ledger
    # stays exactly balanced; the raw tendered amount is kept only for
    # the audit trail description below.
    amount = order.net_applied_amount_for(payment)

    cash_acct = _get_cash_account()
    bank_acct = _get_bank_account()

    def account_for(method):
        return cash_acct if method == Payment.Method.CASH else bank_acct

    old_account = account_for(old_method)
    new_account = account_for(new_method)

    # 1. Reverse the original entry (money_out on the account it wrongly hit)
    change_note = (
        f' (leg tendered {raw_amount} ₹, {raw_amount - amount} ₹ of that was change — '
        f'only the net {amount} ₹ ever hit the ledger)'
        if raw_amount != amount else ''
    )
    reversal_entry = _post_entry(
        account=old_account,
        transaction_type=CashBook.TransactionType.ADJUSTMENT,
        reference_type=CashBook.ReferenceType.POS,
        description=(
            f'Correction: reversing {old_method} entry for {order.bill_number} '
            f'(was recorded as {old_method}, should be {new_method}){change_note}'
        ),
        money_in=Decimal('0.00'),
        money_out=amount,
        reference_id=order.pk,
        created_by=corrected_by,
        allow_negative=True,
    )

    # 2. Update the Payment row itself so EOD sums and reports agree
    payment.method = new_method
    payment.save(update_fields=['method'])

    # 3. Post the corrected entry on the right account
    correction_entry = _post_entry(
        account=new_account,
        transaction_type=CashBook.TransactionType.POS_SALE,
        reference_type=CashBook.ReferenceType.POS,
        description=(
            f'Correction: re-posting as {new_method} for {order.bill_number} '
            f'(corrected from {old_method})'
        ),
        money_in=amount,
        money_out=Decimal('0.00'),
        reference_id=order.pk,
        created_by=corrected_by,
    )

    # 4. Lock this payment leg against further self-service correction
    PaymentCorrection.objects.create(
        payment_id=payment.pk,
        order_id=order.pk,
        old_method=old_method,
        new_method=new_method,
        amount=amount,
        corrected_by=corrected_by,
    )

    return {
        'reversal_entry': reversal_entry,
        'correction_entry': correction_entry,
        'old_method': old_method,
        'new_method': new_method,
        'amount': amount,
    }


# ---------------------------------------------------------------------------
# Open Day (gate for POS billing)
# ---------------------------------------------------------------------------

def is_day_open(business_date=None) -> bool:
    """
    With no argument: True if there is currently ANY business day in the
    OPEN state. This intentionally does NOT restrict to calendar "today" —
    since Daily Close auto-opens the following business date immediately
    (see perform_daily_close), the currently-open business_date can run
    ahead of the calendar date (a close performed before midnight already
    rolls billing onto tomorrow's date).

    With an explicit business_date: True only if that specific date has
    an OPEN DailyClose record.
    """
    if business_date is not None:
        return DailyClose.objects.filter(
            business_date=business_date, status=DailyClose.Status.OPEN,
        ).exists()
    return DailyClose.objects.filter(status=DailyClose.Status.OPEN).exists()


def is_day_closed(business_date=None) -> bool:
    """
    True if the given business date (defaults to today) has already been
    closed via Daily Close. Used to block new Expense/Income/Transfer/
    Adjustment entries once the books for the day are locked — only the
    Cash Book summary stays viewable, not new entry forms.
    """
    if business_date is None:
        business_date = timezone.localdate()
    return DailyClose.objects.filter(
        business_date=business_date, status=DailyClose.Status.CLOSED,
    ).exists()


def get_open_day(business_date=None) -> Optional[DailyClose]:
    """Return today's OPEN DailyClose record, or None if the day isn't open."""
    if business_date is None:
        business_date = timezone.localdate()
    return DailyClose.objects.filter(
        business_date=business_date, status=DailyClose.Status.OPEN,
    ).first()


@transaction.atomic
def open_day(business_date, opened_by, opening_cash: Optional[Decimal] = None) -> DailyClose:
    """
    Explicitly opens a business day so POS billing is allowed.

    opening_cash defaults to:
      - yesterday's counted_cash, if yesterday was closed, or
      - the Cash Drawer account's configured opening_balance, if this is
        the very first day ever opened.

    Raises ValueError if:
      - this business_date is already open or already closed,
      - an earlier business date is still open (must close it first —
        can't have two open days stacking, that would make "today's"
        sales/expenses ambiguous as to which day they belong to).
    """
    from django.db import IntegrityError

    if DailyClose.objects.filter(business_date=business_date).exists():
        existing = DailyClose.objects.get(business_date=business_date)
        if existing.status == DailyClose.Status.CLOSED:
            raise ValueError(f'Business date {business_date} is already closed.')
        raise ValueError(f'Business date {business_date} is already open.')

    # Don't allow opening a new day while an earlier one is still open —
    # that would make it ambiguous which day a new sale belongs to, and
    # the older day would never get closed.
    earlier_open = (
        DailyClose.objects.filter(
            business_date__lt=business_date, status=DailyClose.Status.OPEN,
        )
        .order_by('business_date')
        .first()
    )
    if earlier_open:
        raise ValueError(
            f'Business date {earlier_open.business_date} is still open. '
            f'Close it before opening {business_date}.'
        )

    if opening_cash is None:
        prev_close = (
            DailyClose.objects.filter(
                business_date__lt=business_date, status=DailyClose.Status.CLOSED,
            )
            .order_by('-business_date')
            .first()
        )
        if prev_close:
            opening_cash = prev_close.counted_cash
        else:
            opening_cash = _get_cash_account().opening_balance

    try:
        day = DailyClose.objects.create(
            business_date=business_date,
            opening_cash=opening_cash,
            opened_by=opened_by,
            opened_at=timezone.now(),
            status=DailyClose.Status.OPEN,
        )
    except IntegrityError:
        raise ValueError(
            f'Business date {business_date} was just opened by someone else. '
            'Please refresh the page.'
        )

    # Mark a ledger entry too, so the cash book shows exactly when the
    # till was opened and with how much.
    #
    # current_balance is a running total that is only ever moved by real
    # CashBook entries (never set directly) — so the declared float must
    # actually be posted here, not just logged as a zero-amount note.
    # We post the *delta* between the declared opening_cash and whatever
    # current_balance already is, rather than the full opening_cash every
    # time: on day one current_balance is 0 so the full float is credited;
    # on later days current_balance already carries forward everything
    # that happened on prior days, so if opening_cash simply matches the
    # previous count the delta is zero (no double-counting). If a cashier
    # tops up or removes float cash before opening, or the previous count
    # was off, the delta correctly reconciles current_balance to the
    # newly declared float.
    cash_acct = _get_cash_account()
    delta = opening_cash - cash_acct.current_balance
    money_in = delta if delta > 0 else Decimal('0.00')
    money_out = -delta if delta < 0 else Decimal('0.00')
    _post_entry(
        account=cash_acct,
        transaction_type=CashBook.TransactionType.OPENING,
        reference_type=CashBook.ReferenceType.MANUAL,
        description=f'Business day opened — {business_date} (float: {opening_cash} ₹)',
        money_in=money_in,
        money_out=money_out,
        reference_id=day.pk,
        created_by=opened_by,
        allow_negative=True,  # Float corrections may legitimately reduce balance
    )

    return day


@transaction.atomic
def ensure_day_open(opened_by=None) -> DailyClose:
    """
    Auto-rollover gate for POS billing.

    Returns whichever DailyClose record is currently OPEN, auto-creating
    one if none exists — so billing continues uninterrupted across the
    midnight rollover (and after a Daily Close, if for some reason the
    automatic next-day open performed by perform_daily_close() didn't
    happen) WITHOUT requiring an admin to click "Open Day" first.

    Picks the same target business_date the old manual "Open Day" screen
    used to compute:
      - calendar today, normally, or
      - the day right after the latest close, if that close already
        covers today or a later date (falling forward rather than
        re-opening an already-closed date).

    opened_by is optional here (None means "opened automatically by the
    system", not by a specific admin) — DailyClose.opened_by is nullable
    specifically to allow this.

    Never deletes or overwrites any existing row; only ever creates a new
    DailyClose for a business_date that doesn't have one yet, so no
    existing data can be lost by calling this.
    """
    open_record = DailyClose.objects.filter(status=DailyClose.Status.OPEN).first()
    if open_record:
        return open_record

    today = timezone.localdate()
    latest_closed = (
        DailyClose.objects.filter(status=DailyClose.Status.CLOSED)
        .order_by('-business_date')
        .first()
    )
    if latest_closed and latest_closed.business_date >= today:
        target_date = latest_closed.business_date + timezone.timedelta(days=1)
    else:
        target_date = today

    try:
        return open_day(business_date=target_date, opened_by=opened_by)
    except ValueError:
        # Lost a race with another request/thread that opened the day (or
        # closed/opened concurrently) between our check above and the
        # create — re-check rather than propagate, since the day is very
        # likely open now anyway.
        open_record = DailyClose.objects.filter(status=DailyClose.Status.OPEN).first()
        if open_record:
            return open_record
        raise


@transaction.atomic
def revert_daily_close(business_date, reverted_by) -> DailyClose:
    """
    Admin-only safety valve: undoes a Daily Close, flipping the day back
    to OPEN so a mistake (wrong counted cash, an entry that should have
    been booked first, etc.) can be corrected before re-closing.

    Only the MOST RECENTLY closed day can be reverted. perform_daily_close
    enforces "close oldest-unclosed-day first"; symmetrically, reverting
    an older closed day while a newer one is already open or closed would
    leave the books out of sequence (two open days, or a gap in opening
    cash continuity for everything after it). If an earlier close needs
    fixing, every later day must be reverted first, in order.

    This does NOT touch any Expense/Income/POS sale/Adjustment entries
    posted that day — those stay exactly as they are. It only:
      - removes the zero-amount CLOSING marker entry for this day, and
      - resets the DailyClose row's close-time fields and flips it back
        to OPEN, so Daily Close, the dashboard, and all entry forms treat
        the day as open again.
    """
    day = DailyClose.objects.filter(business_date=business_date).first()
    if day is None:
        raise ValueError(f'Business date {business_date} has no close record to revert.')
    if day.status != DailyClose.Status.CLOSED:
        raise ValueError(f'Business date {business_date} is not closed.')

    later_record = (
        DailyClose.objects.filter(business_date__gt=business_date)
        .order_by('business_date')
        .first()
    )
    if later_record:
        raise ValueError(
            f'Cannot revert {business_date} — {later_record.business_date} was '
            f'opened after it. Revert {later_record.business_date} first.'
        )

    cash_acct = _get_cash_account()
    CashBook.objects.filter(
        account=cash_acct,
        transaction_type=CashBook.TransactionType.CLOSING,
        reference_type=CashBook.ReferenceType.MANUAL,
        reference_id=day.pk,
    ).delete()

    updated_count = DailyClose.objects.filter(
        pk=day.pk, status=DailyClose.Status.CLOSED,
    ).update(
        status=DailyClose.Status.OPEN,
        closed_by=None,
        closed_at=None,
        counted_cash=Decimal('0.00'),
        difference=Decimal('0.00'),
    )
    if updated_count == 0:
        raise ValueError(
            f'Business date {business_date} was just changed by someone else. '
            'Please refresh the page.'
        )

    day.refresh_from_db()
    return day


# ---------------------------------------------------------------------------
# Supporting documents (Expense / Income / Transfer attachments)
# ---------------------------------------------------------------------------

def get_supporting_documents(business_date=None) -> list[dict]:
    """
    Collect every supporting document (receipt, invoice, deposit slip,
    etc.) uploaded against Expense, Other Income, or Bank Transfer
    entries for a given business date.

    Used by the Daily Close (EOD) screen and the Reports → Cash Book
    Summary (daily summary) section so admins can review the paperwork
    behind a day's figures without hunting through each individual list.

    Returns a flat list of dicts, newest first, each with:
      kind, kind_label, description, amount, direction ('in'/'out'),
      account, attachment (FieldFile or None), created_by, time.
    """
    if business_date is None:
        business_date = timezone.localdate()

    documents: list[dict] = []

    expenses = (
        Expense.objects
        .filter(expense_date=business_date)
        .exclude(attachment='')
        .select_related('paid_from_account', 'created_by')
    )
    for exp in expenses:
        documents.append({
            'kind': 'EXPENSE',
            'kind_label': 'Expense',
            'description': f'{exp.get_category_display()} — {exp.note or "—"}',
            'amount': exp.amount,
            'direction': 'out',
            'account': exp.paid_from_account,
            'attachment': exp.attachment,
            'created_by': exp.created_by,
            'time': exp.created_at,
        })

    incomes = (
        OtherIncome.objects
        .filter(income_date=business_date)
        .exclude(attachment='')
        .select_related('receive_account', 'created_by')
    )
    for inc in incomes:
        documents.append({
            'kind': 'INCOME',
            'kind_label': 'Other Income',
            'description': f'{inc.get_category_display()} — {inc.note or "—"}',
            'amount': inc.amount,
            'direction': 'in',
            'account': inc.receive_account,
            'attachment': inc.attachment,
            'created_by': inc.created_by,
            'time': inc.created_at,
        })

    # Transfers post two CashBook legs (cash + bank) with the same
    # attachment — only surface the money_out ("source") leg of each pair
    # so a single transfer shows up once, not twice.
    transfers = (
        CashBook.objects
        .filter(
            transaction_datetime__date=business_date,
            transaction_type__in=[
                CashBook.TransactionType.BANK_DEPOSIT,
                CashBook.TransactionType.BANK_WITHDRAW,
            ],
            money_out__gt=Decimal('0.00'),
        )
        .exclude(attachment='')
        .select_related('account', 'created_by')
    )
    for entry in transfers:
        documents.append({
            'kind': 'TRANSFER',
            'kind_label': entry.get_transaction_type_display(),
            'description': entry.description,
            'amount': entry.money_out,
            'direction': 'transfer',
            'account': entry.account,
            'attachment': entry.attachment,
            'created_by': entry.created_by,
            'time': entry.transaction_datetime,
        })

    documents.sort(key=lambda d: d['time'], reverse=True)
    return documents


# ---------------------------------------------------------------------------
# Daily Close summary
# ---------------------------------------------------------------------------

def get_today_summary(business_date=None) -> dict:
    """
    Compute all figures needed for the EOD screen without touching DailyClose.
    Returns a plain dict so views stay thin.
    """
    from django.db.models import Sum
    from billing.models import Order

    if business_date is None:
        business_date = timezone.localdate()

    cash_acct = _get_cash_account()

    # --- Opening cash: prefer today's explicit Open Day record (set when
    # the cashier opened the till), falling back to the previous close or
    # the account's configured opening_balance if the day was never
    # formally opened (shouldn't happen once Open Day is enforced, but
    # keeps this function safe to call standalone, e.g. from the dashboard
    # before any day has ever been opened).
    today_record = DailyClose.objects.filter(business_date=business_date).first()
    if today_record:
        opening_cash = today_record.opening_cash
    else:
        prev_close = (
            DailyClose.objects.filter(
                business_date__lt=business_date,
                status=DailyClose.Status.CLOSED,
            )
            .order_by('-business_date')
            .first()
        )
        opening_cash = prev_close.counted_cash if prev_close else cash_acct.opening_balance

    # --- Today's paid orders ---
    today_orders = Order.objects.filter(
        status=Order.Status.PAID,
        paid_at__date=business_date,
    ).prefetch_related('payments')

    # Sales-by-method must be computed from *net* applied payments (see
    # Order.net_applied_payments), not a raw Sum('amount') over Payment —
    # a raw sum double-counts any change given back on a cash overpayment,
    # which would inflate cash_sales (and therefore expected_cash) by the
    # change amount. This mirrors the fix applied in record_pos_payments.
    method_totals = {
        Payment.Method.CASH: Decimal('0.00'),
        Payment.Method.CARD: Decimal('0.00'),
        Payment.Method.UPI: Decimal('0.00'),
    }
    for order in today_orders:
        for method, net_amount in order.net_payment_totals_by_method().items():
            if method in method_totals:
                method_totals[method] += net_amount

    cash_sales   = method_totals[Payment.Method.CASH]
    card_sales   = method_totals[Payment.Method.CARD]
    upi_sales    = method_totals[Payment.Method.UPI]

    # --- Today's other income (cash account only) ---
    other_income = (
        OtherIncome.objects
        .filter(income_date=business_date, receive_account=cash_acct)
        .aggregate(t=Sum('amount'))['t']
    ) or Decimal('0.00')

    # --- Today's expenses (cash account only) ---
    expenses = (
        Expense.objects
        .filter(expense_date=business_date, paid_from_account=cash_acct)
        .aggregate(t=Sum('amount'))['t']
    ) or Decimal('0.00')

    # --- Transfers today ---
    today_entries = CashBook.objects.filter(
        account=cash_acct,
        transaction_datetime__date=business_date,
    )
    cash_deposit = (
        today_entries.filter(transaction_type=CashBook.TransactionType.BANK_DEPOSIT)
        .aggregate(t=Sum('money_out'))['t']
    ) or Decimal('0.00')
    cash_withdraw = (
        today_entries.filter(transaction_type=CashBook.TransactionType.BANK_WITHDRAW)
        .aggregate(t=Sum('money_in'))['t']
    ) or Decimal('0.00')

    expected_cash = (
        opening_cash + cash_sales + other_income + cash_withdraw
        - expenses - cash_deposit
    )

    return {
        'business_date':  business_date,
        'opening_cash':   opening_cash,
        'cash_sales':     cash_sales,
        'card_sales':     card_sales,
        'upi_sales':      upi_sales,
        'other_income':   other_income,
        'expenses':       expenses,
        'cash_deposit':   cash_deposit,
        'cash_withdraw':  cash_withdraw,
        'expected_cash':  expected_cash,
    }


@transaction.atomic
def perform_daily_close(business_date, counted_cash: Decimal, closed_by) -> DailyClose:
    """
    Closes a business day that was previously opened via open_day().
    Fills in all the calculated totals on the existing OPEN record and
    flips its status to CLOSED. Creates a CLOSING CashBook entry to mark
    the day's end.

    Concurrency: business_date is unique on DailyClose, so if two cashiers
    submit the close at the same moment, only one UPDATE can win the
    "still OPEN" filter below — the loser's update affects zero rows,
    which we detect and turn into a friendly ValueError.

    Raises ValueError if:
      - the day was never opened (no Open Day record exists at all),
      - the day is already closed,
      - an earlier business date is still open (closing out of order would
        silently misstate "opening cash" for this and all following days).
    """
    day = DailyClose.objects.filter(business_date=business_date).first()

    if day is None:
        raise ValueError(
            f'Business date {business_date} was never opened. Open the day before closing it.'
        )
    if day.status == DailyClose.Status.CLOSED:
        raise ValueError(f'Business date {business_date} is already closed.')

    # Guard against closing out of sequence: if an earlier day was never
    # closed, opening_cash for *this* close would be wrong, and that
    # earlier day's own figures would never get a permanent record.
    # Cafés that skip a day's close must close oldest first.
    from billing.models import Order
    oldest_unclosed = (
        Order.objects.filter(status=Order.Status.PAID, paid_at__date__lt=business_date)
        .exclude(
            paid_at__date__in=DailyClose.objects.filter(
                status=DailyClose.Status.CLOSED
            ).values_list('business_date', flat=True)
        )
        .order_by('paid_at')
        .first()
    )
    if oldest_unclosed:
        earliest_open_orders_date = oldest_unclosed.paid_at.date()
        raise ValueError(
            f'Cannot close {business_date} — {earliest_open_orders_date} has unclosed sales. '
            f'Close business days in order, starting with {earliest_open_orders_date}.'
        )

    summary = get_today_summary(business_date)
    expected_cash = summary['expected_cash']
    difference = expected_cash - counted_cash

    # Update-in-place, gated on still being OPEN, so a concurrent duplicate
    # submit can only succeed once — the second call affects 0 rows.
    updated_count = DailyClose.objects.filter(
        pk=day.pk, status=DailyClose.Status.OPEN,
    ).update(
        cash_sales=summary['cash_sales'],
        card_sales=summary['card_sales'],
        upi_sales=summary['upi_sales'],
        other_income=summary['other_income'],
        expenses=summary['expenses'],
        cash_deposit=summary['cash_deposit'],
        cash_withdraw=summary['cash_withdraw'],
        expected_cash=expected_cash,
        counted_cash=counted_cash,
        difference=difference,
        status=DailyClose.Status.CLOSED,
        closed_by=closed_by,
        closed_at=timezone.now(),
    )
    if updated_count == 0:
        raise ValueError(
            f'Business date {business_date} was just closed by someone else. '
            'Please refresh the page.'
        )

    day.refresh_from_db()

    # Write a CLOSING entry so the ledger reflects end-of-day
    cash_acct = _get_cash_account()
    _post_entry(
        account=cash_acct,
        transaction_type=CashBook.TransactionType.CLOSING,
        reference_type=CashBook.ReferenceType.MANUAL,
        description=f'End of Day closing — {business_date}',
        money_in=Decimal('0.00'),
        money_out=Decimal('0.00'),
        reference_id=day.pk,
        created_by=closed_by,
        allow_negative=True,  # A zero-amount marker entry; never actually negative
    )

    # Immediately roll billing over onto the next business day so no
    # separate manual "Open Day" step is needed after a close — the next
    # sale just lands on business_date + 1. Best-effort: if this somehow
    # fails (e.g. that date was already opened/closed by something else),
    # the Daily Close itself is still valid and stays closed; the next
    # call to ensure_day_open() (the billing gate) will pick a sensible
    # target date and open it lazily instead.
    try:
        open_day(business_date=business_date + timezone.timedelta(days=1), opened_by=closed_by)
    except ValueError as exc:
        logger.warning(
            'Auto-open of the next business day after closing %s did not happen: %s',
            business_date, exc,
        )

    return day


# ---------------------------------------------------------------------------
# Dashboard summary
# ---------------------------------------------------------------------------

def get_dashboard_data(business_date=None) -> dict:
    """Compute all figures shown on the Cash Dashboard."""
    from django.db.models import Sum

    if business_date is None:
        business_date = timezone.localdate()

    cash_acct = _get_cash_account()
    bank_acct = _get_bank_account()
    summary   = get_today_summary(business_date)

    today_record = DailyClose.objects.filter(business_date=business_date).first()
    is_open = bool(today_record and today_record.status == DailyClose.Status.OPEN)
    is_closed = bool(today_record and today_record.status == DailyClose.Status.CLOSED)

    # A close can only be reverted from the dashboard if it's the most
    # recently closed day overall (same rule revert_daily_close enforces).
    can_revert_close = False
    if is_closed:
        later_record = DailyClose.objects.filter(business_date__gt=business_date).exists()
        can_revert_close = not later_record

    recent_entries = (
        CashBook.objects
        .filter(account=cash_acct)
        .select_related('created_by')
        .order_by('-transaction_datetime')[:10]
    )

    return {
        'business_date':    business_date,
        'is_open':          is_open,
        'is_closed':        is_closed,
        'daily_close':      today_record,
        'can_revert_close': can_revert_close,
        'cash_balance':    cash_acct.current_balance,
        'bank_balance':    bank_acct.current_balance,
        'today_sales':     summary['cash_sales'] + summary['card_sales'] + summary['upi_sales'],
        'today_expenses':  summary['expenses'],
        'today_income':    summary['other_income'],
        'expected_cash':   summary['expected_cash'],
        'recent_entries':  recent_entries,
    }
