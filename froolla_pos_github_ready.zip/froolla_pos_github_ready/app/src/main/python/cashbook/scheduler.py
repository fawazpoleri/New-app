"""
cashbook.scheduler
-------------------
Background thread that rolls the business day over automatically at
midnight, so it's already open by the time anyone looks — no cashier
visit or admin click required.

Context: `ensure_day_open()` (see services.py) already auto-opens the
day the moment a cashier hits the POS screen after midnight — that
alone makes billing itself resilient. But nothing else proactively
called it, so the Dashboard, Reports, and Tables screens could still
show yesterday's business date for hours after midnight, right up
until the first sale of the new day. This scheduler closes that gap by
calling the same `ensure_day_open()`:

  1. Once, shortly after the server starts (covers the case where the
     till was switched off across a midnight rollover and only comes
     back up the next morning), and
  2. Every local midnight after that, for as long as the process runs.

Deliberately does NOT wait for Django's post_migrate signal to start —
this app is launched two different ways (see run_pos.py vs.
run_production.bat), and only one of them runs `migrate` in the same
process as the eventual server, so post_migrate can't be relied on to
fire in every deployment. Instead the startup catch-up below simply
retries with backoff until it succeeds (or gives up after a generous
window), which is correct regardless of exactly when migrations finish
relative to this thread starting.

Started once per process from CashbookConfig.ready() (see apps.py) —
never call start_midnight_scheduler() directly from a view or another
management command.
"""

import logging
import threading
import time

from django.utils import timezone

logger = logging.getLogger(__name__)

_started = False
_lock = threading.Lock()

# Startup catch-up retry schedule: keep trying every 10s for up to ~10
# minutes in case this process's migrations are still being applied
# (only relevant to run_pos.py's same-process migrate-then-serve
# sequence on a completely fresh install). After that, give up on catch-up
# and just wait for the next scheduled midnight.
_STARTUP_RETRY_INTERVAL_SECONDS = 10
_STARTUP_RETRY_MAX_ATTEMPTS = 60


def _seconds_until_next_midnight() -> float:
    now = timezone.localtime()
    tomorrow_midnight = (now + timezone.timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0,
    )
    return (tomorrow_midnight - now).total_seconds()


def _ensure_day_open_once() -> bool:
    """Returns True on success, False if it raised (logged either way)."""
    try:
        from cashbook.services import ensure_day_open
        day = ensure_day_open()
        logger.info('Midnight scheduler: business day %s is open.', day.business_date)
        return True
    except Exception:
        logger.exception('Midnight scheduler: failed to auto-open the business day.')
        return False


def _startup_catch_up() -> None:
    """
    Retry loop for the very first check after the process starts. Needed
    because on a completely fresh install (run_pos.py path), this thread
    can start before `migrate` has finished creating the tables it needs
    — everything after this succeeds immediately in the far more common
    case where migrations were already applied moments earlier.
    """
    for attempt in range(1, _STARTUP_RETRY_MAX_ATTEMPTS + 1):
        if _ensure_day_open_once():
            return
        time.sleep(_STARTUP_RETRY_INTERVAL_SECONDS)
    logger.warning(
        'Midnight scheduler: startup catch-up gave up after %d attempts; '
        'will try again at the next midnight rollover.',
        _STARTUP_RETRY_MAX_ATTEMPTS,
    )


def _run_forever() -> None:
    _startup_catch_up()
    while True:
        # Wake a few seconds *after* midnight, never a hair before it —
        # clock/thread-timing jitter landing early would open "today"
        # instead of the new business date.
        time.sleep(_seconds_until_next_midnight() + 5)
        _ensure_day_open_once()


def start_midnight_scheduler() -> None:
    """Idempotent — safe to call more than once, only ever starts one thread."""
    global _started
    with _lock:
        if _started:
            return
        _started = True

    thread = threading.Thread(
        target=_run_forever,
        name='midnight-day-open-scheduler',
        daemon=True,
    )
    thread.start()
    logger.info('Midnight business-day scheduler started.')
