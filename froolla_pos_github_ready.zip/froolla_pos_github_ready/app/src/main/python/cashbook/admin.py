from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError

from . import services
from .models import CashAccount, CashBook, DailyClose, Expense, OtherIncome, PaymentCorrection


@admin.register(CashAccount)
class CashAccountAdmin(admin.ModelAdmin):
    list_display = ['name', 'account_type', 'opening_balance', 'current_balance', 'is_active']
    list_filter = ['account_type', 'is_active']
    readonly_fields = ['current_balance', 'created_at', 'updated_at']


@admin.register(CashBook)
class CashBookAdmin(admin.ModelAdmin):
    list_display = [
        'transaction_datetime', 'account', 'transaction_type',
        'money_in', 'money_out', 'balance_after', 'description', 'attachment',
    ]
    list_filter = ['transaction_type', 'account', 'reference_type']
    search_fields = ['description']
    date_hierarchy = 'transaction_datetime'
    readonly_fields = [
        'transaction_datetime', 'account', 'transaction_type', 'reference_type',
        'reference_id', 'description', 'money_in', 'money_out', 'balance_after',
        'created_by', 'created_at', 'updated_at', 'attachment',
    ]

    def has_add_permission(self, request):
        return False  # Entries created only via service layer

    def has_delete_permission(self, request, obj=None):
        return False  # Ledger is immutable


class ExpenseAdminForm(forms.ModelForm):
    """
    Blocks a financial edit (amount or paying account changed) once the
    expense's original or new date falls in an already-closed business
    day — mirroring correct_payment_method's lock on closed-day
    corrections. Checked here, at form-validation time, rather than only
    in the post_save signal, so Django Admin shows a normal inline form
    error instead of an unhandled 500: a signal raising late (after
    form.is_valid() already returned True) isn't something Django Admin
    can render gracefully, even though the save is still safely rolled
    back either way.
    """
    class Meta:
        model = Expense
        fields = '__all__'

    def clean(self):
        cleaned = super().clean()
        if not self.instance.pk:
            return cleaned  # New expense — nothing to compare against
        prior = Expense.objects.filter(pk=self.instance.pk).values(
            'amount', 'paid_from_account_id', 'expense_date',
        ).first()
        if not prior:
            return cleaned
        new_amount = cleaned.get('amount')
        new_account = cleaned.get('paid_from_account')
        new_date = cleaned.get('expense_date')
        financial_change = (
            new_amount != prior['amount']
            or (new_account and new_account.pk != prior['paid_from_account_id'])
        )
        if not financial_change:
            return cleaned
        if services.is_day_closed(prior['expense_date']) or (new_date and services.is_day_closed(new_date)):
            raise ValidationError(
                f"Cannot change the amount/account on this expense — its business day "
                f"({prior['expense_date']}) is already closed. That would silently leave "
                f"the closed day's Cash Book Summary out of sync with the Expenses Report. "
                f"Record a Cash Adjustment for the difference instead, dated today."
            )
        return cleaned


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    form = ExpenseAdminForm
    list_display = ['expense_date', 'category', 'amount', 'paid_from_account', 'note', 'attachment', 'created_by']
    list_filter = ['category', 'expense_date']
    date_hierarchy = 'expense_date'
    readonly_fields = ['created_by', 'created_at']

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    def has_delete_permission(self, request, obj=None):
        # Deleting an Expense would orphan its CashBook entry (reference_id
        # is not a real FK, so nothing would cascade or error). Edit the
        # amount instead — the post_save signal now posts a correcting
        # ledger entry automatically, keeping everything reconciled.
        return False


class OtherIncomeAdminForm(forms.ModelForm):
    """Mirror of ExpenseAdminForm — see its docstring for the rationale."""
    class Meta:
        model = OtherIncome
        fields = '__all__'

    def clean(self):
        cleaned = super().clean()
        if not self.instance.pk:
            return cleaned
        prior = OtherIncome.objects.filter(pk=self.instance.pk).values(
            'amount', 'receive_account_id', 'income_date',
        ).first()
        if not prior:
            return cleaned
        new_amount = cleaned.get('amount')
        new_account = cleaned.get('receive_account')
        new_date = cleaned.get('income_date')
        financial_change = (
            new_amount != prior['amount']
            or (new_account and new_account.pk != prior['receive_account_id'])
        )
        if not financial_change:
            return cleaned
        if services.is_day_closed(prior['income_date']) or (new_date and services.is_day_closed(new_date)):
            raise ValidationError(
                f"Cannot change the amount/account on this income entry — its business day "
                f"({prior['income_date']}) is already closed. That would silently leave "
                f"the closed day's Cash Book Summary out of sync with the Other Income Report. "
                f"Record a Cash Adjustment for the difference instead, dated today."
            )
        return cleaned


@admin.register(OtherIncome)
class OtherIncomeAdmin(admin.ModelAdmin):
    form = OtherIncomeAdminForm
    list_display = ['income_date', 'category', 'amount', 'receive_account', 'note', 'attachment', 'created_by']
    list_filter = ['category', 'income_date']
    date_hierarchy = 'income_date'
    readonly_fields = ['created_by', 'created_at']

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    def has_delete_permission(self, request, obj=None):
        # Same rationale as ExpenseAdmin — deleting would orphan the
        # matching CashBook entry. Edit instead; the ledger auto-corrects.
        return False


@admin.register(DailyClose)
class DailyCloseAdmin(admin.ModelAdmin):
    list_display = [
        'business_date', 'opening_cash', 'expected_cash',
        'counted_cash', 'difference', 'status', 'closed_by', 'closed_at',
    ]
    list_filter = ['status']
    date_hierarchy = 'business_date'
    readonly_fields = [
        'opening_cash', 'cash_sales', 'card_sales', 'upi_sales',
        'other_income', 'expenses', 'cash_deposit', 'cash_withdraw',
        'expected_cash', 'difference', 'closed_by', 'closed_at',
    ]


@admin.register(PaymentCorrection)
class PaymentCorrectionAdmin(admin.ModelAdmin):
    list_display = [
        'corrected_at', 'order_id', 'payment_id',
        'old_method', 'new_method', 'amount', 'corrected_by',
    ]
    list_filter = ['old_method', 'new_method']
    date_hierarchy = 'corrected_at'
    readonly_fields = [
        'payment_id', 'order_id', 'old_method', 'new_method',
        'amount', 'corrected_by', 'corrected_at',
    ]

    def has_add_permission(self, request):
        return False  # Created only via the correction service

    def has_delete_permission(self, request, obj=None):
        return False  # Audit trail is permanent
