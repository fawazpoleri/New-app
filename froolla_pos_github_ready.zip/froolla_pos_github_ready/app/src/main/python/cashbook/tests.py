"""
Cash Book tests. Covers the signal-driven ledger (the "single source of
truth" for money movement):

  - A PAID Order automatically posts CashBook entries via the post_save
    signal, split correctly by payment method/account
  - Change given back to a cash-paying customer is never posted as revenue
  - A double-save of the same PAID order never double-posts
  - Expense/Income creation posts a matching ledger debit/credit, and
    a day-closed edit is blocked rather than silently corrupting totals
"""

from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.utils import timezone

from billing.models import Order, OrderItem
from cashbook import services as cb_services
from cashbook.models import CashAccount, CashBook, Expense
from core.models import RestaurantSetting
from menu.models import Category, MenuItem
from payments.models import Payment


class CashbookTestBase(TestCase):
    def setUp(self):
        self.cashier = User.objects.create_user('cashier1', password='x')
        self.category = Category.objects.create(name='Juices')
        self.item = MenuItem.objects.create(category=self.category, name='Mango Juice', price=Decimal('100.00'))
        settings_ = RestaurantSetting.get_solo()
        settings_.gst_enabled = False
        settings_.tax_percent = Decimal('0.00')
        settings_.save()
        cb_services.ensure_default_accounts()

    def make_paid_order(self, payments):
        """payments: list of (method, amount) tuples."""
        order = Order.objects.create(cashier=self.cashier)
        OrderItem.objects.create(
            order=order, menu_item=self.item, item_name=self.item.name,
            unit_price=self.item.price, quantity=1,
        )
        order.recalculate_totals()
        for method, amount in payments:
            Payment.objects.create(order=order, method=method, amount=amount)
        order.mark_paid()  # fires cashbook.signals.on_order_paid
        return order


class POSSaleLedgerTests(CashbookTestBase):
    def test_cash_sale_posts_to_cash_drawer(self):
        self.make_paid_order([(Payment.Method.CASH, Decimal('100.00'))])

        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        entries = CashBook.objects.filter(account=cash_acct, transaction_type=CashBook.TransactionType.POS_SALE)
        self.assertEqual(entries.count(), 1)
        self.assertEqual(entries.first().money_in, Decimal('100.00'))

    def test_card_sale_posts_to_bank_account_not_cash_drawer(self):
        self.make_paid_order([(Payment.Method.CARD, Decimal('100.00'))])

        bank_acct = CashAccount.objects.get(name='Bank Account')
        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        self.assertEqual(
            CashBook.objects.filter(account=bank_acct, transaction_type=CashBook.TransactionType.POS_SALE).count(), 1,
        )
        self.assertEqual(
            CashBook.objects.filter(account=cash_acct, transaction_type=CashBook.TransactionType.POS_SALE).count(), 0,
        )

    def test_split_payment_posts_two_entries_to_two_accounts(self):
        self.make_paid_order([
            (Payment.Method.CASH, Decimal('40.00')),
            (Payment.Method.CARD, Decimal('60.00')),
        ])
        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        bank_acct = CashAccount.objects.get(name='Bank Account')
        self.assertEqual(cash_acct.entries.filter(transaction_type=CashBook.TransactionType.POS_SALE).count(), 1)
        self.assertEqual(bank_acct.entries.filter(transaction_type=CashBook.TransactionType.POS_SALE).count(), 1)

        cash_acct.refresh_from_db()
        bank_acct.refresh_from_db()
        self.assertEqual(cash_acct.current_balance, Decimal('40.00'))
        self.assertEqual(bank_acct.current_balance, Decimal('60.00'))

    def test_cash_overpayment_change_is_excluded_from_the_ledger(self):
        """Customer pays 150 cash on a 100 bill; only 100 should hit the drawer."""
        self.make_paid_order([(Payment.Method.CASH, Decimal('150.00'))])

        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        entry = CashBook.objects.get(account=cash_acct, transaction_type=CashBook.TransactionType.POS_SALE)
        self.assertEqual(entry.money_in, Decimal('100.00'))  # not 150
        cash_acct.refresh_from_db()
        self.assertEqual(cash_acct.current_balance, Decimal('100.00'))

    def test_resaving_a_paid_order_does_not_double_post(self):
        order = self.make_paid_order([(Payment.Method.CASH, Decimal('100.00'))])
        # Simulate a second, unrelated save while already PAID (e.g. admin edit elsewhere)
        order.save()

        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        self.assertEqual(
            CashBook.objects.filter(account=cash_acct, reference_id=order.pk).count(), 1,
        )

    def test_running_balance_after_is_correct(self):
        self.make_paid_order([(Payment.Method.CASH, Decimal('100.00'))])
        self.make_paid_order([(Payment.Method.CASH, Decimal('50.00'))])

        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        entries = list(cash_acct.entries.order_by('id'))
        self.assertEqual(entries[0].balance_after, Decimal('100.00'))
        self.assertEqual(entries[1].balance_after, Decimal('150.00'))


class ExpenseLedgerTests(CashbookTestBase):
    def test_expense_posts_a_debit_and_reduces_balance(self):
        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        cb_services._post_entry(
            account=cash_acct, transaction_type=CashBook.TransactionType.OPENING,
            reference_type=CashBook.ReferenceType.MANUAL, description='Opening float',
            money_in=Decimal('500.00'), money_out=Decimal('0.00'),
        )

        expense = Expense.objects.create(
            category='SUPPLIES',
            amount=Decimal('120.00'),
            paid_from_account=cash_acct,
            expense_date=timezone.localdate(),
            created_by=self.cashier,
        )

        cash_acct.refresh_from_db()
        self.assertEqual(cash_acct.current_balance, Decimal('380.00'))

    def test_expense_larger_than_balance_is_blocked(self):
        cash_acct = CashAccount.objects.get(name='Cash Drawer')
        with self.assertRaises(ValueError):
            cb_services._post_entry(
                account=cash_acct, transaction_type=CashBook.TransactionType.EXPENSE,
                reference_type=CashBook.ReferenceType.EXPENSE, description='Too much',
                money_in=Decimal('0.00'), money_out=Decimal('50.00'),
            )
