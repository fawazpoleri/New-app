"""
Payments app models.

A single Order can have multiple Payment rows attached — this is how
"Mixed" payments (e.g. part cash, part card) are represented: one row per
method/amount the cashier enters, all linked to the same order.
"""

from django.db import models


class Payment(models.Model):
    """One payment leg against an Order. Multiple rows = a mixed payment."""

    class Method(models.TextChoices):
        CASH = 'CASH', 'Cash'
        CARD = 'CARD', 'Card'
        UPI = 'UPI', 'UPI'

    order = models.ForeignKey(
        'billing.Order',
        on_delete=models.CASCADE,
        related_name='payments',
    )
    method = models.CharField(max_length=10, choices=Method.choices)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']

    def __str__(self) -> str:
        return f'{self.get_method_display()} - {self.amount} ₹ ({self.order.bill_number})'
