"""
Admin configuration for the payments app.

Read-only — payments are always created through the POS payment flow,
never directly in the admin.
"""

from django.contrib import admin

from payments.models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('order', 'method', 'amount', 'created_at')
    list_filter = ('method','created_at')
    search_fields = ('order__bill_number',)
    readonly_fields = ('order', 'method', 'amount', 'created_at')

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
