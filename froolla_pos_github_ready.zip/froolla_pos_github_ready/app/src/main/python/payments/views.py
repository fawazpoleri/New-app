"""
Payments app — no views.

Payment rows are created exclusively from billing.views.PaymentView (the
POS payment screen's confirm endpoint), so there is nothing for this app
to render on its own. The Payment model lives in its own app for a clean
separation of concerns, ready to grow (e.g. a payment gateway integration)
in a later phase without touching billing.
"""
