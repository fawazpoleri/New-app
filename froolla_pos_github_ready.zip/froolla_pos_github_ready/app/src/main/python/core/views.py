"""
Core app views.

Currently holds the Dashboard — the landing page after login for admin
users, showing today's high-level numbers and a quick link into the POS
screen. Cashiers (non-staff) are redirected straight to the POS screen
instead — they don't get a sales-summary landing page, just billing.
"""

from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Sum
from django.shortcuts import redirect
from django.utils import timezone
from django.views.generic import TemplateView

from billing.models import Order
from menu.models import Category, MenuItem
from tables.permissions import is_kitchen


class DashboardView(LoginRequiredMixin, TemplateView):
    """
    Landing page after login — admin only.

    Shows four summary cards (today's sales, today's bills, menu items,
    categories) plus a quick "Open POS" action. All figures are scoped to
    "today" in the server's local timezone.

    Non-staff users (cashiers) never see this page; they're redirected
    straight to the POS screen, which is their actual landing page.
    """

    template_name = 'core/dashboard.html'

    def get(self, request, *args, **kwargs):
        if not request.user.is_staff:
            if is_kitchen(request.user):
                return redirect('tables:kitchen_display')
            return redirect('billing:pos')
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        today = timezone.localdate()
        # Filtered by paid_at (when the bill was actually paid), matching
        # the business-date semantic used everywhere else in the app —
        # Sales Report, EOD/Cash Book Summary, Bill History. A cart opened
        # yesterday but paid today must count as today's sale here too,
        # not the other way around (this previously used created_at,
        # which could disagree with every other "today" figure in the app
        # around a midnight boundary).
        todays_orders = Order.objects.filter(
            paid_at__date=today,
            status=Order.Status.PAID,
        )

        todays_sales = todays_orders.aggregate(
            total=Sum('grand_total')
        )['total'] or 0

        context.update({
            'todays_sales': todays_sales,
            'todays_bill_count': todays_orders.count(),
            'menu_item_count': MenuItem.objects.filter(is_active=True).count(),
            'category_count': Category.objects.filter(is_active=True).count(),
        })
        return context
