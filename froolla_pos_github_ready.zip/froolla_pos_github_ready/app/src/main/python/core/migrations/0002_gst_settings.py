from decimal import Decimal

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='restaurantsetting',
            name='gst_enabled',
            field=models.BooleanField(
                default=False,
                help_text=(
                    'Turn on Indian GST. When enabled, menu prices are treated as '
                    'GST-inclusive and the POS billing screen shows a CGST/SGST '
                    'breakdown extracted from the price instead of adding tax on top.'
                ),
            ),
        ),
        migrations.AddField(
            model_name='restaurantsetting',
            name='gst_percent',
            field=models.DecimalField(
                decimal_places=2,
                default=Decimal('5.00'),
                help_text=(
                    'Total GST% already baked into menu prices, e.g. 5 for 2.5% CGST '
                    '+ 2.5% SGST. Only used when GST is enabled.'
                ),
                max_digits=5,
            ),
        ),
        migrations.AlterField(
            model_name='restaurantsetting',
            name='tax_percent',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                help_text=(
                    'Applied to the subtotal after discount. Leave 0 if not applicable. '
                    'Ignored while GST is enabled below.'
                ),
                max_digits=5,
            ),
        ),
    ]
