from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

    def ready(self) -> None:
        """Brand the Django Admin site (header/title) per the restaurant's name."""
        from django.contrib import admin

        admin.site.site_header = 'Cafe POS Administration'
        admin.site.site_title = 'Cafe POS Admin'
        admin.site.index_title = 'Manage Menu, Settings & Sales'
