"""
Template context processors for the core app.
"""

from core.models import RestaurantSetting


def restaurant_settings(request):
    """
    Make restaurant branding (name, address, phone, footer) available in
    every template as `restaurant`, without each view having to fetch it.
    """
    return {'restaurant': RestaurantSetting.get_solo()}
