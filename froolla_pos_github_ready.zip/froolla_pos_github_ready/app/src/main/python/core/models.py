"""
Core app models.

Holds restaurant-wide configuration (RestaurantSetting) used to brand the
POS UI and printed receipts. Designed as a singleton — there should only
ever be one row.
"""

from decimal import Decimal

from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.db import models

RESTAURANT_SETTINGS_CACHE_KEY = 'core:restaurant_settings:solo'


class RestaurantSetting(models.Model):
    """
    Singleton model holding restaurant identity & receipt details.

    Accessed via RestaurantSetting.get_solo() rather than a manual query,
    so callers never need to worry about whether the row exists yet.
    """

    name = models.CharField(
        max_length=100,
        default='My Cafe',
        help_text='Shown on the dashboard header and printed receipts.',
    )
    address = models.CharField(
        max_length=255,
        blank=True,
        help_text='Printed on the receipt header.',
    )
    phone = models.CharField(max_length=30, blank=True)
    receipt_footer = models.CharField(
        max_length=200,
        default='Thank You! Visit Again.',
        help_text='Printed at the bottom of every receipt.',
    )
    tax_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0,
        help_text=(
            'Applied to the subtotal after discount. Leave 0 if not applicable. '
            'Ignored while GST is enabled below.'
        ),
    )

    gst_enabled = models.BooleanField(
        default=False,
        help_text=(
            'Turn on Indian GST. When enabled, menu prices are treated as '
            'GST-inclusive and the POS billing screen shows a CGST/SGST '
            'breakdown extracted from the price instead of adding tax on top.'
        ),
    )
    gst_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('5.00'),
        help_text=(
            'Total GST% already baked into menu prices, e.g. 5 for 2.5% CGST '
            '+ 2.5% SGST. Only used when GST is enabled.'
        ),
    )

    class Meta:
        verbose_name = 'Restaurant Setting'
        verbose_name_plural = 'Restaurant Settings'

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        """Force singleton behaviour: always overwrite row with pk=1."""
        self.pk = 1
        super().save(*args, **kwargs)
        cache.delete(RESTAURANT_SETTINGS_CACHE_KEY)

    def delete(self, *args, **kwargs):
        """Prevent deletion — the app always needs exactly one settings row."""
        raise ValidationError('Restaurant settings cannot be deleted.')

    @classmethod
    def get_solo(cls) -> 'RestaurantSetting':
        """
        Return the single settings row, creating it with defaults if missing.

        Cached: this is loaded via a context processor on every page render,
        so without caching it's an extra DB round-trip on every navigation.
        The cache is cleared automatically on save(), so admin edits (name,
        GST settings, receipt footer, etc.) take effect immediately.
        """
        obj = cache.get(RESTAURANT_SETTINGS_CACHE_KEY)
        if obj is None:
            obj, _created = cls.objects.get_or_create(pk=1)
            cache.set(RESTAURANT_SETTINGS_CACHE_KEY, obj, timeout=3600)
        return obj
