"""
Admin configuration for the core app.

RestaurantSetting is a singleton, so the admin is locked down to prevent
adding extra rows or deleting the only row.
"""

from django.contrib import admin

from core.models import RestaurantSetting


@admin.register(RestaurantSetting)
class RestaurantSettingAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'gst_enabled', 'gst_percent', 'tax_percent')
    fieldsets = (
        (None, {'fields': ('name', 'address', 'phone', 'receipt_footer')}),
        ('Indian GST (POS billing)', {
            'fields': ('gst_enabled', 'gst_percent'),
            'description': (
                'When enabled, menu prices are treated as already including '
                'GST. The POS billing screen extracts and displays the CGST/'
                'SGST split instead of adding tax on top.'
            ),
        }),
        ('Legacy tax (non-GST regions)', {
            'fields': ('tax_percent',),
            'description': 'Ignored while GST is enabled above.',
        }),
    )

    def has_add_permission(self, request):
        # Block adding a second row once one exists — this model is a singleton.
        return not RestaurantSetting.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False
