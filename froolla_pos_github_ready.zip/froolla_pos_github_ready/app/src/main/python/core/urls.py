"""
URL routes for the core app: dashboard only (root POS/billing routes live
in the billing app).
"""

from django.urls import path

from core.views import DashboardView

app_name = 'core'

urlpatterns = [
    path('', DashboardView.as_view(), name='dashboard'),
]
