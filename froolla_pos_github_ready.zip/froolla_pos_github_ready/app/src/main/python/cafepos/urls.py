"""
URL configuration for the cafepos project.

Root-level routing simply delegates to each app's own urls.py.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

# Android build: billing features only. Django Admin, Reports, and Tables
# (floor plan / kitchen display) are intentionally not routed here — those
# apps stay installed (billing depends on tables.permissions internally)
# but aren't exposed as pages on-device. cashbook.urls IS kept: the POS
# and Payment screens link to cashbook:open_day as the manual fallback
# whenever the automatic day-open (billing/views.py _is_business_day_open)
# fails, so billing isn't actually usable without it.
urlpatterns = [
    path('accounts/', include('accounts.urls')),
    path('', include('core.urls')),
    path('', include('billing.urls')),
    path('', include('cashbook.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
