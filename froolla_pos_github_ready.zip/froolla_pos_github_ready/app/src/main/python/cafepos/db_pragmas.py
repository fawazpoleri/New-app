"""
SQLite connection tuning.

By default SQLite uses "rollback journal" mode, where a writer takes an
exclusive lock on the *whole file* for the duration of its transaction —
so any other connection trying to write (or even trying to start a write)
blocks, and with the stock ~5s driver timeout can throw
"database is locked" (OperationalError) well before that timeout is
reached under real concurrent load (multiple terminals, KDS, QR ordering
all writing around the same time).

WAL (Write-Ahead Logging) mode lets readers and writers work without
blocking each other — writers append to a separate log instead of
locking the main file, and only writer-vs-writer contention waits at
all. Combined with the busy `timeout` set in DATABASES OPTIONS (see
settings.py), a second writer now *waits* for the first to finish
instead of failing immediately.

This only applies to the sqlite3 backend; harmless no-op on Postgres.
"""
from django.db.backends.signals import connection_created


def _apply_sqlite_pragmas(sender, connection, **kwargs):
    if connection.vendor != 'sqlite':
        return
    with connection.cursor() as cursor:
        cursor.execute('PRAGMA journal_mode=WAL;')
        cursor.execute('PRAGMA synchronous=NORMAL;')


def register():
    connection_created.connect(_apply_sqlite_pragmas)
