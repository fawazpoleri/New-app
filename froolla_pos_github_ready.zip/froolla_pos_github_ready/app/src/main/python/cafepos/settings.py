"""
Django settings for cafepos project.

Cafe / Restaurant POS — Phase 1
"""

from pathlib import Path
import os
import sys

# Build paths inside the project like this: BASE_DIR / 'subdir'.
# NOTE: when this app is frozen into a PyInstaller executable, __file__
# resolves inside the (read-only, temp-extracted for --onefile) bundle.
# That's fine for code/templates/static/fixtures — they're read-only
# assets anyway. Anything that needs to be *written* (sqlite file, media
# uploads, logs) must NOT live here; see RUNTIME_DIR below.
BASE_DIR = Path(__file__).resolve().parent.parent

# RUNTIME_DIR is where the app is actually installed/run from on the
# shop's PC — the folder holding the .exe (or, in dev, the project
# folder). run_pos.py (the PyInstaller entry point) sets POS_RUNTIME_DIR
# before this settings module is imported. This is where db.sqlite3
# (if used), media/, logs/, and the optional .env config file live, so
# they survive updates and sit next to the exe where the shop can find
# and back them up.
RUNTIME_DIR = Path(os.environ.get('POS_RUNTIME_DIR', BASE_DIR))

# SECURITY WARNING: keep the secret key used in production secret!
# Replace this with an environment variable before deploying.
SECRET_KEY = os.environ.get(
    'DJANGO_SECRET_KEY',
    'django-insecure-CHANGE-THIS-BEFORE-DEPLOYMENT-4wql9nv9f3c3oh',
)

# SECURITY WARNING: don't run with debug turned on in production!
# DEBUG=True keeps every SQL query in memory for the life of the process
# (django.db.connection.queries) — on a POS terminal left running all day
# that's a real, steadily-growing memory leak, on top of exposing full
# tracebacks to anyone hitting an error. Defaults to OFF; turn it on only
# for local development with `set DJANGO_DEBUG=1` (Windows) /
# `export DJANGO_DEBUG=1` (Mac/Linux) before `runserver`.
DEBUG = os.environ.get('DJANGO_DEBUG', '0') == '1'

ALLOWED_HOSTS = ['*']  # Restrict this in production (e.g. ['yourcafe.com'])


# Application definition

INSTALLED_APPS = [
    # jazzmin/admin dropped for the Android build — billing features only,
    # no on-device need for the Django Admin theme.
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Local apps
    'core',
    'accounts',
    'menu',
    'billing',
    'payments',
    # 'reports' dropped for the Android build — not part of the billing flow.
    'cashbook',
    'tables',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'cafepos.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'core.context_processors.restaurant_settings',
                'tables.context_processors.kitchen_pending_count',
            ],
        },
    },
]

WSGI_APPLICATION = 'cafepos.wsgi.application'


# Database
# https://docs.djangoproject.com/en/5.2/ref/settings/#databases
#
# DB_ENGINE=postgres  -> PostgreSQL (recommended for production/multi-till)
# DB_ENGINE=sqlite (default) -> single-file local database, zero setup
#
# Set these as real environment variables (e.g. via NSSM's "Environment"
# field) or in a `.env` file next to the .exe / project root — see
# `.env.example`. Never commit real credentials.

DB_ENGINE = os.environ.get('DB_ENGINE', 'sqlite').strip().lower()

if DB_ENGINE in ('postgres', 'postgresql'):
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('DB_NAME', 'froolla_pos'),
            'USER': os.environ.get('DB_USER', 'postgres'),
            'PASSWORD': os.environ.get('DB_PASSWORD', ''),
            'HOST': os.environ.get('DB_HOST', 'localhost'),
            'PORT': os.environ.get('DB_PORT', '5432'),
            # Keeps connections open between requests instead of
            # reconnecting every request — important once the till is
            # talking to Postgres over anything other than localhost.
            'CONN_MAX_AGE': int(os.environ.get('DB_CONN_MAX_AGE', '60')),
            'OPTIONS': {
                'connect_timeout': int(os.environ.get('DB_CONNECT_TIMEOUT', '10')),
            },
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': RUNTIME_DIR / 'db.sqlite3',
            # 'timeout' is how long (seconds) a connection will wait for the
            # write lock before raising "database is locked", instead of
            # failing near-instantly. Paired with WAL mode below (set via
            # the connection_created signal in cafepos/db_pragmas.py) so
            # readers no longer block writers at all — only writer-vs-writer
            # contention waits, and now it waits instead of erroring.
            #
            # 'transaction_mode': 'IMMEDIATE' matters just as much as the
            # timeout above. Django's default sqlite transactions start
            # with a plain "BEGIN" (deferred) — the write lock isn't
            # actually requested until the first write statement runs,
            # and Python's sqlite3 driver does not reliably honor the busy
            # timeout on that *upgrade* from a read to a write lock, so two
            # concurrent writers can still get an immediate "database is
            # locked" even with timeout/WAL set. Starting every transaction
            # with "BEGIN IMMEDIATE" grabs the write lock up front, so the
            # busy-timeout wait applies as expected instead of being
            # bypassed. (Requires Python's sqlite3 bindings to support
            # multi-word BEGIN statements, i.e. Python 3.12+; that's fine
            # here since PyInstaller bundles the runtime.)
            'OPTIONS': {
                'timeout': 20,
                'transaction_mode': 'IMMEDIATE',
            },
        }
    }
    # Enable WAL mode on every new connection (see db_pragmas.py for why).
    from cafepos.db_pragmas import register as _register_sqlite_pragmas
    _register_sqlite_pragmas()


# Password validation
# https://docs.djangoproject.com/en/5.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 4},  # Cashiers need short, memorable PINs/passwords
    },
]


# Internationalization
# https://docs.djangoproject.com/en/5.2/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Kolkata'

USE_I18N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.2/howto/static-files/

STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
# Writable (WhiteNoise checks this dir exists even though
# WHITENOISE_USE_FINDERS below means it doesn't need collectstatic output
# in it) — so this lives in RUNTIME_DIR, same reasoning as MEDIA_ROOT.
STATIC_ROOT = RUNTIME_DIR / 'staticfiles'

# WhiteNoise: serves CSS/JS/fonts/icons with gzip compression and
# far-future cache headers, without needing an nginx/Apache in front of
# the app (this project runs standalone on the shop's LAN — see README).
# USE_FINDERS=True means it serves straight out of STATICFILES_DIRS, so
# no `collectstatic` step is required to keep working as before.
WHITENOISE_USE_FINDERS = True
WHITENOISE_AUTOREFRESH = DEBUG

# Media files (none required in Phase 1, reserved for future product images)
MEDIA_URL = 'media/'
MEDIA_ROOT = RUNTIME_DIR / 'media'

# Default primary key field type
# https://docs.djangoproject.com/en/5.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# Authentication redirects
LOGIN_URL = 'accounts:login'
# Android build goes straight to the POS billing screen — no dashboard/reports on-device.
LOGIN_REDIRECT_URL = 'billing:pos'
LOGOUT_REDIRECT_URL = 'accounts:login'

# Currency used across receipts/templates (Indian Rupee, 2 decimal places by convention)
CURRENCY_SYMBOL = 'INR'
CURRENCY_DECIMAL_PLACES = 2

# ----------------------------------------------------------------------------
# Runtime folders (writable) — ensure they exist. In dev these are just
# subfolders of the project; in a frozen/packaged build they live next to
# the .exe (RUNTIME_DIR), so they survive app updates and are easy to find
# for backups.
# ----------------------------------------------------------------------------
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
(RUNTIME_DIR / 'logs').mkdir(parents=True, exist_ok=True)
MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
STATIC_ROOT.mkdir(parents=True, exist_ok=True)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '{asctime} {levelname} {name}: {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'standard',
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(RUNTIME_DIR / 'logs' / 'pos.log'),
            'maxBytes': 5 * 1024 * 1024,
            'backupCount': 5,
            'formatter': 'standard',
        },
    },
    'root': {
        'handlers': ['console', 'file'],
        'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
    },
    'loggers': {
        'django.request': {
            'handlers': ['console', 'file'],
            'level': 'WARNING',
            'propagate': False,
        },
    },
}
