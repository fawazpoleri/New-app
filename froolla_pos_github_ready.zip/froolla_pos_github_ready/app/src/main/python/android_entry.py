"""
Froolla POS — Android (Chaquopy) launcher.

Mirrors run_pos.py's approach for the Windows .exe build, adapted to run
*inside* the Android app process instead of as a standalone executable:

  1. Point RUNTIME_DIR at the app's own private storage (passed in from
     Kotlin as `context.getFilesDir()`), so db.sqlite3, media/, and logs/
     survive app restarts and app updates, same as they survive .exe
     updates on Windows.
  2. Boot Django, run migrations (safe/no-op if already applied).
  3. On a genuinely first run (no users yet), seed the sample menu
     fixture and create one starter login so the app is immediately
     usable, instead of shipping with the real production db.sqlite3.
  4. Serve with Waitress on 127.0.0.1 only — this app is not reachable
     from the network, it's a local server the on-device WebView talks
     to, same role Waitress plays on the shop PC today.

Called from MainActivity.kt via Chaquopy:
    Python.getInstance().getModule("android_entry").callAttr("start", filesDir)
on a background thread — this function blocks forever (serve() loops),
so it must never be called on the UI thread.
"""

import os
import secrets
import sys
from pathlib import Path

STARTER_USERNAME = "cashier"
STARTER_PASSWORD = "froolla123"  # change this from the Bill History > Logout screen's account settings, or via `python manage.py create_staff_user`


def _ensure_secret_key(runtime_dir: Path) -> str:
    """
    Persist one generated SECRET_KEY per install in RUNTIME_DIR, instead
    of shipping a fixed key baked into the APK (which every install of
    the app would then share).
    """
    key_file = runtime_dir / ".secret_key"
    if key_file.exists():
        return key_file.read_text(encoding="utf-8").strip()
    key = secrets.token_urlsafe(50)
    key_file.write_text(key, encoding="utf-8")
    return key


def _seed_first_run() -> None:
    """
    Runs only when there are zero users yet, i.e. a brand new install —
    never touches an existing db.sqlite3 that already has real data
    (e.g. one you've pulled over from the Windows install).
    """
    from django.contrib.auth.models import User
    from django.core.management import call_command

    if User.objects.exists():
        return

    print("Froolla POS — first run: seeding sample menu + starter login...")
    try:
        call_command("loaddata", "sample_menu")
    except Exception as exc:  # pragma: no cover - fixture is optional
        print(f"  (skipped sample menu fixture: {exc})")

    call_command(
        "create_staff_user",
        STARTER_USERNAME,
        role="cashier",
        password=STARTER_PASSWORD,
    )
    print(f'  Starter login -> username: "{STARTER_USERNAME}"  password: "{STARTER_PASSWORD}"')
    print("  Change this from an admin account once you're set up.")


def start(files_dir: str, host: str = "127.0.0.1", port: int = 8000) -> None:
    """Entry point called from Kotlin. Blocks forever serving the app."""
    runtime_dir = Path(files_dir) / "froolla_runtime"
    runtime_dir.mkdir(parents=True, exist_ok=True)

    os.environ["POS_RUNTIME_DIR"] = str(runtime_dir)
    os.environ["DJANGO_SETTINGS_MODULE"] = "cafepos.settings"
    os.environ["DJANGO_DEBUG"] = "0"
    os.environ.setdefault("DJANGO_SECRET_KEY", _ensure_secret_key(runtime_dir))

    import django

    django.setup()

    from django.core.management import call_command

    print("Froolla POS — applying database migrations...")
    call_command("migrate", interactive=False, verbosity=1)

    _seed_first_run()

    from waitress import serve

    from cafepos.wsgi import application

    print(f"Froolla POS — serving on http://{host}:{port} (local only)")
    sys.stdout.flush()
    serve(application, host=host, port=port, threads=4)
