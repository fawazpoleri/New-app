/**
 * POS Screen behaviour
 * --------------------
 * - Category rail switches which product grid is visible (no reload).
 * - Tapping a product card POSTs to add-to-cart, then re-renders the cart
 *   from the JSON response — no full page reload, so it stays fast.
 * - Quantity +/-, remove, clear, and discount all follow the same pattern:
 *   POST -> receive fresh cart JSON -> re-render cart panel.
 */

(function () {
  'use strict';

  const csrfToken = document.querySelector('input[name=csrfmiddlewaretoken]')?.value
    || getCookie('csrftoken');

  function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : '';
  }

  function postForm(url, data) {
    const formData = new URLSearchParams(data);
    return fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrfToken,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    }).then((res) => res.json());
  }

  function formatMoney(value) {
    return Number(value).toFixed(2);
  }

  // ---------------- Category switching ----------------

  const categoryButtons = document.querySelectorAll('.category-btn');
  const productGrids = document.querySelectorAll('.category-products');
  const activeCategoryName = document.getElementById('active-category-name');

  categoryButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const categoryId = btn.dataset.categoryId;

      categoryButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      productGrids.forEach((grid) => {
        grid.style.display = grid.dataset.categoryId === categoryId ? '' : 'none';
      });

      if (activeCategoryName) {
        activeCategoryName.textContent = btn.querySelector('span:not(.bi)').textContent;
      }
    });
  });

  // ---------------- Cart rendering ----------------

  const cartLinesEl = document.getElementById('cart-lines');
  const subtotalEl = document.getElementById('subtotal-value');
  const taxEl = document.getElementById('tax-value');
  const taxableValueEl = document.getElementById('taxable-value-value');
  const cgstEl = document.getElementById('cgst-value');
  const sgstEl = document.getElementById('sgst-value');
  const grandTotalEl = document.getElementById('grand-total-value');
  const billNumberEl = document.getElementById('bill-number');
  const discountInput = document.getElementById('discount-input');
  const printKotBtn = document.getElementById('print-kot-btn');

  function renderCart(cart) {
    if (billNumberEl) billNumberEl.textContent = cart.bill_number;
    if (subtotalEl) subtotalEl.textContent = formatMoney(cart.subtotal) + ' ₹';
    if (grandTotalEl) grandTotalEl.textContent = formatMoney(cart.grand_total) + ' ₹';

    if (printKotBtn) {
      const hasItems = cart.items.length > 0;
      printKotBtn.classList.toggle('btn-disabled', !hasItems);
      printKotBtn.setAttribute('aria-disabled', String(!hasItems));
    }

    if (cart.gst_enabled) {
      // GST mode: prices are tax-inclusive, so show the CGST/SGST split
      // extracted from the total rather than a single "Tax" line.
      if (taxableValueEl) taxableValueEl.textContent = formatMoney(cart.taxable_value) + ' ₹';
      if (cgstEl) cgstEl.textContent = formatMoney(cart.cgst_amount) + ' ₹';
      if (sgstEl) sgstEl.textContent = formatMoney(cart.sgst_amount) + ' ₹';
    } else if (taxEl) {
      const taxRow = taxEl.closest('.totals-row');
      if (Number(cart.tax_amount) > 0) {
        taxEl.textContent = formatMoney(cart.tax_amount) + ' ₹';
        if (taxRow) taxRow.style.display = '';
      } else if (taxRow) {
        taxRow.style.display = 'none';
      }
    }

    if (!cartLinesEl) return;

    if (cart.items.length === 0) {
      cartLinesEl.innerHTML = `
        <div class="cart-empty">
          <i class="bi bi-cart3"></i>
          <p>Cart is empty.<br>Tap a product to add it.</p>
        </div>`;
      return;
    }

    cartLinesEl.innerHTML = cart.items.map((item) => `
      <div class="cart-line" data-line-id="${item.line_id}">
        <div class="cart-line-info">
          <div class="cart-line-name">${escapeHtml(item.name)}</div>
          <div class="cart-line-price mono">${formatMoney(item.unit_price)} ₹</div>
        </div>
        <div class="qty-control">
          <button type="button" class="qty-btn qty-decrease" data-line-id="${item.line_id}">−</button>
          <span class="qty-value">${item.quantity}</span>
          <button type="button" class="qty-btn qty-increase" data-line-id="${item.line_id}">+</button>
        </div>
        <div class="cart-line-total mono">${formatMoney(item.line_total)}</div>
        <button type="button" class="cart-line-remove" data-line-id="${item.line_id}" title="Remove item">
          <i class="bi bi-x-circle"></i>
        </button>
      </div>
    `).join('');
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------------- Add to cart ----------------

  document.querySelectorAll('.product-card').forEach((card) => {
    card.addEventListener('click', () => {
      const itemId = card.dataset.itemId;

      card.classList.add('just-added');
      setTimeout(() => card.classList.remove('just-added'), 220);

      postForm(window.POS_URLS.addItem, { item_id: itemId }).then(renderCart);
    });
  });

  // ---------------- Cart line interactions (delegated) ----------------

  if (cartLinesEl) {
    cartLinesEl.addEventListener('click', (event) => {
      const increaseBtn = event.target.closest('.qty-increase');
      const decreaseBtn = event.target.closest('.qty-decrease');
      const removeBtn = event.target.closest('.cart-line-remove');

      if (increaseBtn) {
        postForm(window.POS_URLS.updateQuantity, {
          line_id: increaseBtn.dataset.lineId,
          delta: 1,
        }).then(renderCart);
      } else if (decreaseBtn) {
        postForm(window.POS_URLS.updateQuantity, {
          line_id: decreaseBtn.dataset.lineId,
          delta: -1,
        }).then(renderCart);
      } else if (removeBtn) {
        postForm(window.POS_URLS.removeItem, {
          line_id: removeBtn.dataset.lineId,
        }).then(renderCart);
      }
    });
  }

  // ---------------- Discount ----------------

  if (discountInput) {
    let debounceTimer;
    discountInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        postForm(window.POS_URLS.applyDiscount, {
          discount_amount: discountInput.value || '0',
        }).then(renderCart);
      }, 400);
    });
  }

  // ---------------- Clear bill ----------------

  const clearBillBtn = document.getElementById('clear-bill-btn');
  if (clearBillBtn) {
    clearBillBtn.addEventListener('click', () => {
      if (!confirm('Clear the entire bill? This cannot be undone.')) return;
      postForm(window.POS_URLS.clearCart, {}).then((cart) => {
        renderCart(cart);
        if (discountInput) discountInput.value = '0.000';
      });
    });
  }

  if (printKotBtn) {
    printKotBtn.addEventListener('click', (event) => {
      if (printKotBtn.classList.contains('btn-disabled')) event.preventDefault();
    });
  }

  // ---------------- Go to payment ----------------

  const paymentBtn = document.getElementById('payment-btn');
  if (paymentBtn) {
    paymentBtn.addEventListener('click', () => {
      if (paymentBtn.disabled) return;  // Day not open yet — button is locked
      window.location.href = window.POS_URLS.payment;
    });
  }
})();
