/**
 * Kitchen Display Screen behaviour
 * ---------------------------------
 * Same getCookie/CSRF pattern as table_order.js and pos.js, but every
 * action endpoint here returns the re-rendered board HTML fragment
 * directly (not JSON) — a tap swaps #kds-board-wrap's contents in
 * place, and a timer does the same on a poll so every kitchen screen
 * stays in sync with what other stations are doing.
 */

(function () {
  'use strict';

  const wrap = document.getElementById('kds-board-wrap');
  if (!wrap) return;

  const refreshUrl = wrap.dataset.refreshUrl;
  const liveDot = document.getElementById('kds-live-dot');
  const liveLabel = document.getElementById('kds-live-label');

  const POLL_INTERVAL_MS = 8000;
  const TIME_TICK_MS = 30000;

  const csrfToken = document.querySelector('input[name=csrfmiddlewaretoken]')?.value
    || getCookie('csrftoken');

  function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : '';
  }

  let inFlight = false;

  function setLive(ok) {
    if (!liveDot || !liveLabel) return;
    liveDot.classList.toggle('kds-live-dot-stale', !ok);
    liveLabel.textContent = ok ? 'Live' : 'Reconnecting…';
  }

  function renderBoard(html) {
    wrap.innerHTML = html;
  }

  function refreshBoard() {
    if (inFlight) return;
    inFlight = true;
    fetch(refreshUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then((res) => {
        if (!res.ok) throw new Error('bad status');
        return res.text();
      })
      .then((html) => {
        renderBoard(html);
        setLive(true);
      })
      .catch(() => setLive(false))
      .finally(() => {
        inFlight = false;
      });
  }

  function postAction(url, ticketEl) {
    if (ticketEl) ticketEl.classList.add('kds-ticket-updating');
    return fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrfToken,
        'X-Requested-With': 'XMLHttpRequest',
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error('bad status');
        return res.text();
      })
      .then((html) => {
        renderBoard(html);
        setLive(true);
      })
      .catch(() => {
        // Leave the (still-stale) board as-is and let the next poll
        // reconcile it — better than losing the kitchen's tap silently.
        if (ticketEl) ticketEl.classList.remove('kds-ticket-updating');
        setLive(false);
      });
  }

  // Event delegation: the board's DOM is fully replaced on every
  // refresh/action, so listen on the stable wrapper rather than binding
  // to individual buttons.
  wrap.addEventListener('click', (event) => {
    const button = event.target.closest('.kds-action');
    if (!button) return;
    event.preventDefault();
    const url = button.dataset.url;
    if (!url) return;
    const ticketEl = button.closest('.kds-ticket');
    postAction(url, ticketEl);
  });

  // "3 min ago" labels re-computed client-side between polls so elapsed
  // time doesn't visibly freeze between an 8-second refresh cycle.
  function tickTimes() {
    wrap.querySelectorAll('.kds-ticket-time[data-timestamp]').forEach((el) => {
      const then = new Date(el.dataset.timestamp).getTime();
      if (Number.isNaN(then)) return;
      const minutes = Math.max(0, Math.floor((Date.now() - then) / 60000));
      const label = minutes < 1 ? 'just now' : `${minutes} min ago`;
      const icon = el.querySelector('.bi');
      el.textContent = '';
      if (icon) el.appendChild(icon);
      el.appendChild(document.createTextNode(' ' + label));
    });
  }

  setInterval(refreshBoard, POLL_INTERVAL_MS);
  setInterval(tickTimes, TIME_TICK_MS);

  // Pause polling while the tab/screen is hidden, resume immediately
  // (with an instant refresh) when it becomes visible again — avoids a
  // stale board being the first thing the kitchen sees after waking the
  // tablet screen back up.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') refreshBoard();
  });
})();
