/**
 * Payment Screen behaviour
 * ------------------------
 * Single methods (Cash/Card/UPI) show one input pre-filled with the full
 * amount due. "Mixed" lets the cashier add multiple legs (e.g. part Cash,
 * part Card) that together must cover the grand total.
 *
 * "Remaining" (tendered < due) and "Change" (tendered > due, cash-only
 * scenario) are both surfaced via the same balance row, recalculated on
 * every keystroke.
 */

(function () {
  'use strict';

  const app = document.getElementById('payment-app');
  if (!app) return;

  const grandTotal = parseFloat(app.dataset.grandTotal);
  const posUrl = app.dataset.posUrl;
  const paymentUrl = app.dataset.paymentUrl;
  const dayOpen = app.dataset.dayOpen === '1';

  const methodTabs = document.querySelectorAll('.method-tab');
  const legsContainer = document.getElementById('payment-legs');
  const quickAmountsContainer = document.getElementById('quick-amounts');
  const totalTenderedEl = document.getElementById('total-tendered');
  const balanceLabelEl = document.getElementById('balance-label');
  const balanceValueEl = document.getElementById('balance-value');
  const balanceRowEl = document.getElementById('balance-row');
  const confirmBtn = document.getElementById('confirm-payment-btn');
  const errorBanner = document.getElementById('payment-error');
  const errorText = document.getElementById('payment-error-text');

  const METHOD_ICONS = {
    CASH: 'bi-cash-stack',
    CARD: 'bi-credit-card',
    UPI: 'bi-qr-code',
  };

  let mode = null; // 'SINGLE' or 'MIXED'
  let legs = []; // {method, amount}

  function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : '';
  }

  function fmt(n) {
    return n.toFixed(2);
  }

  // ---------------- Method tab selection ----------------

  methodTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      methodTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      const method = tab.dataset.method;
      if (method === 'MIXED') {
        mode = 'MIXED';
        legs = [];
        renderMixedLegs();
        renderQuickAmounts(null);
      } else {
        mode = 'SINGLE';
        legs = [{ method, amount: grandTotal }];
        renderSingleLeg(method);
        renderQuickAmounts(method);
      }
      recalc();
    });
  });

  function renderSingleLeg(method) {
    legsContainer.style.display = '';
    const editable = method === 'CASH';
    legsContainer.innerHTML = `
      <div class="payment-leg">
        <div class="payment-leg-icon"><i class="bi ${METHOD_ICONS[method]}"></i></div>
        <div class="payment-leg-method">${method}</div>
        <input type="number" class="payment-leg-input mono" step="0.001" min="0"
               value="${fmt(grandTotal)}" data-leg-index="0"
               ${editable ? '' : 'disabled title="Amount is fixed for this payment method"'}>
      </div>
    `;
    bindLegInputs();
  }

  function renderMixedLegs() {
    legsContainer.style.display = '';
    if (legs.length === 0) {
      legsContainer.innerHTML = `
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          ${Object.keys(METHOD_ICONS).map((m) => `
            <button type="button" class="btn btn-secondary add-leg-btn" data-add-method="${m}">
              <i class="bi ${METHOD_ICONS[m]}"></i> Add ${m}
            </button>
          `).join('')}
        </div>
      `;
      bindAddLegButtons();
      return;
    }

    legsContainer.innerHTML = legs.map((leg, index) => `
      <div class="payment-leg">
        <div class="payment-leg-icon"><i class="bi ${METHOD_ICONS[leg.method]}"></i></div>
        <div class="payment-leg-method">${leg.method}</div>
        <input type="number" class="payment-leg-input mono" step="0.001" min="0"
               value="${fmt(leg.amount)}" data-leg-index="${index}">
        <button type="button" class="payment-leg-remove" data-remove-index="${index}">
          <i class="bi bi-x-circle"></i>
        </button>
      </div>
    `).join('') + `
      <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top: 10px;">
        ${Object.keys(METHOD_ICONS)
          .filter((m) => !legs.some((l) => l.method === m))
          .map((m) => `
            <button type="button" class="btn btn-secondary add-leg-btn" data-add-method="${m}">
              <i class="bi ${METHOD_ICONS[m]}"></i> Add ${m}
            </button>
          `).join('')}
      </div>
    `;
    bindLegInputs();
    bindAddLegButtons();
    bindRemoveLegButtons();
  }

  function bindAddLegButtons() {
    legsContainer.querySelectorAll('.add-leg-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const method = btn.dataset.addMethod;
        const remaining = Math.max(grandTotal - sumLegs(), 0);
        legs.push({ method, amount: remaining });
        renderMixedLegs();
        recalc();
      });
    });
  }

  function bindRemoveLegButtons() {
    legsContainer.querySelectorAll('[data-remove-index]').forEach((btn) => {
      btn.addEventListener('click', () => {
        legs.splice(Number(btn.dataset.removeIndex), 1);
        renderMixedLegs();
        recalc();
      });
    });
  }

  function bindLegInputs() {
    legsContainer.querySelectorAll('.payment-leg-input').forEach((input) => {
      input.addEventListener('input', () => {
        const index = Number(input.dataset.legIndex);
        legs[index].amount = parseFloat(input.value) || 0;
        recalc();
      });
    });
  }

  function sumLegs() {
    return legs.reduce((sum, leg) => sum + (leg.amount || 0), 0);
  }

  // ---------------- Quick amount chips (single-method only) ----------------

  function renderQuickAmounts(method) {
    if (!method || method !== 'CASH') {
      quickAmountsContainer.innerHTML = '';
      return;
    }
    const roundUp = Math.ceil(grandTotal);
    const suggestions = Array.from(new Set([
      grandTotal,
      roundUp,
      roundUp + 1,
      roundUp + 4,
    ])).filter((v) => v >= grandTotal);

    quickAmountsContainer.innerHTML = suggestions.map((amt) => `
      <button type="button" class="quick-amount-btn" data-amount="${amt}">${fmt(amt)} ₹</button>
    `).join('');

    quickAmountsContainer.querySelectorAll('.quick-amount-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        legs[0].amount = parseFloat(btn.dataset.amount);
        const input = legsContainer.querySelector('.payment-leg-input');
        if (input) input.value = fmt(legs[0].amount);
        recalc();
      });
    });
  }

  // ---------------- Totals / balance ----------------

  function recalc() {
    const tendered = sumLegs();
    totalTenderedEl.textContent = fmt(tendered) + ' ₹';

    const balance = grandTotal - tendered;
    balanceRowEl.classList.remove('positive', 'negative');

    if (balance > 0.0009) {
      balanceLabelEl.textContent = 'Remaining';
      balanceValueEl.textContent = fmt(balance) + ' ₹';
      balanceRowEl.classList.add('negative');
      confirmBtn.disabled = true;
    } else {
      const change = Math.abs(balance);
      balanceLabelEl.textContent = change > 0.0009 ? 'Change Due' : 'Exact Amount';
      balanceValueEl.textContent = fmt(change) + ' ₹';
      balanceRowEl.classList.add('positive');
      // Even if the tendered amount fully covers the bill, never enable
      // the button while the business day hasn't been opened.
      confirmBtn.disabled = legs.length === 0 || !dayOpen;
    }

    hideError();
  }

  function showError(message) {
    errorText.textContent = message;
    errorBanner.classList.add('visible');
  }

  function hideError() {
    errorBanner.classList.remove('visible');
  }

  // ---------------- Confirm payment ----------------

  confirmBtn.addEventListener('click', () => {
    if (!dayOpen) {
      showError('The business day has not been opened yet. Ask an admin to Open Day first.');
      return;
    }
    if (legs.length === 0) {
      showError('Select a payment method first.');
      return;
    }

    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing...';

    fetch(paymentUrl, {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        payments: legs.map((leg) => ({ method: leg.method, amount: fmt(leg.amount) })),
      }),
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          showError(data.error || 'Payment failed. Please try again.');
          confirmBtn.disabled = false;
          confirmBtn.innerHTML = '<i class="bi bi-check-circle"></i> Confirm Payment';
          return;
        }
        // Single-window flow: navigate straight to the invoice/receipt,
        // which auto-prints itself. KOT is printed manually from a
        // button on that screen instead of an auto-opened second tab
        // (that second tab was stealing focus and leaving the cashier
        // stuck looking at a bare KOT ticket with no Print Invoice /
        // New Bill buttons).
        window.location.href = data.redirect_url;
      })
      .catch(() => {
        showError('Network error. Please try again.');
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '<i class="bi bi-check-circle"></i> Confirm Payment';
      });
  });

  // Default to no method selected; cashier must actively choose one.
  recalc();
})();
