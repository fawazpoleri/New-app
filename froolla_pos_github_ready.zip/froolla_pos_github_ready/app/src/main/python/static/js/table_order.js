/**
 * Table Order screen behaviour
 * -----------------------------
 * Same pattern as pos.js: tap a product -> POST -> re-render from JSON.
 * The one addition is "Confirm Order", which turns any pending +/- edits
 * into a new KOT and opens the print view in a new tab.
 */

(function () {
  'use strict';

  const app = document.getElementById('table-order-app');
  if (!app) return;

  const canEdit = app.dataset.canEdit === '1';
  const csrfToken = document.querySelector('input[name=csrfmiddlewaretoken]')?.value
    || getCookie('csrftoken');

  function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : '';
  }

  function postForm(url, data) {
    const formData = new URLSearchParams(data);
    return fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrfToken,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    }).then((res) => res.json());
  }

  function formatMoney(value) {
    return Number(value).toFixed(2);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------------- Category switching ----------------

  const categoryButtons = document.querySelectorAll('.category-btn');
  const productGrids = document.querySelectorAll('.category-products');
  const activeCategoryName = document.getElementById('active-category-name');

  categoryButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const categoryId = btn.dataset.categoryId;
      categoryButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      productGrids.forEach((grid) => {
        grid.style.display = grid.dataset.categoryId === categoryId ? '' : 'none';
      });
      if (activeCategoryName) {
        activeCategoryName.textContent = btn.querySelector('span:not(.bi)').textContent;
      }
    });
  });

  // ---------------- Order rendering ----------------

  const cartLinesEl = document.getElementById('cart-lines');
  const subtotalEl = document.getElementById('subtotal-value');
  const confirmBtn = document.getElementById('confirm-order-btn');
  const navCartBtn = document.getElementById('to-cart-nav-btn');
  const navCartBadge = document.getElementById('to-cart-nav-badge');
  const navCartTotal = document.getElementById('to-cart-nav-total');

  function bumpNavCart() {
    if (!navCartBtn) return;
    navCartBtn.classList.remove('bump');
    void navCartBtn.offsetWidth; // restart the animation on rapid consecutive taps
    navCartBtn.classList.add('bump');
  }

  function renderOrder(payload) {
    if (payload.error) {
      alert(payload.error);
      return;
    }
    if (subtotalEl) subtotalEl.textContent = '₹' + formatMoney(payload.subtotal);
    if (navCartTotal) navCartTotal.textContent = '₹' + formatMoney(payload.subtotal);
    if (navCartBadge) {
      const count = payload.items.length;
      navCartBadge.hidden = count === 0;
      navCartBadge.textContent = count;
    }

    if (cartLinesEl) {
      if (payload.items.length === 0) {
        cartLinesEl.innerHTML = `
          <div class="cart-empty">
            <i class="bi bi-journal-text"></i>
            <p>No items yet.<br>Tap a product to add it.</p>
          </div>`;
      } else {
        cartLinesEl.innerHTML = payload.items.map((item) => `
          <div class="cart-line ${item.is_pending ? 'pending' : ''}" data-line-id="${item.line_id}">
            <div class="cart-line-info">
              <div class="cart-line-name">${escapeHtml(item.name)}${item.is_pending ? '<span class="pending-tag">pending</span>' : ''}</div>
              <div class="cart-line-price mono">${formatMoney(item.unit_price)} ₹</div>
              <input type="text" class="line-note-input" data-line-id="${item.line_id}" placeholder="Note, e.g. No onion" value="${escapeHtml(item.notes || '')}">
            </div>
            <div class="qty-control">
              <button type="button" class="qty-btn qty-decrease" data-line-id="${item.line_id}">−</button>
              <span class="qty-value">${item.quantity}</span>
              <button type="button" class="qty-btn qty-increase" data-line-id="${item.line_id}">+</button>
            </div>
            <div class="cart-line-total mono">${formatMoney(item.line_total)}</div>
          </div>
        `).join('');
      }
    }
  }

  // ---------------- Cart drawer open/close ----------------

  const cartOverlay = document.getElementById('to-cart-overlay');

  function openCartDrawer() {
    if (cartOverlay) cartOverlay.hidden = false;
  }

  function closeCartDrawer() {
    if (cartOverlay) cartOverlay.hidden = true;
  }

  if (navCartBtn) navCartBtn.addEventListener('click', openCartDrawer);
  document.getElementById('to-cart-drawer-close')?.addEventListener('click', closeCartDrawer);
  cartOverlay?.addEventListener('click', (event) => {
    if (event.target === cartOverlay) closeCartDrawer();
  });

  // ---------------- Add item ----------------

  if (canEdit) {
    document.querySelectorAll('.product-card').forEach((card) => {
      card.addEventListener('click', () => {
        const itemId = card.dataset.itemId;
        card.classList.add('just-added');
        setTimeout(() => card.classList.remove('just-added'), 220);
        postForm(window.TABLE_ORDER_URLS.addItem, { item_id: itemId }).then((payload) => {
          renderOrder(payload);
          bumpNavCart();
        });
      });
    });
  }

  // ---------------- Line interactions (delegated) ----------------

  if (cartLinesEl) {
    cartLinesEl.addEventListener('click', (event) => {
      const increaseBtn = event.target.closest('.qty-increase');
      const decreaseBtn = event.target.closest('.qty-decrease');
      if (!canEdit || (!increaseBtn && !decreaseBtn)) return;

      const btn = increaseBtn || decreaseBtn;
      postForm(window.TABLE_ORDER_URLS.updateQuantity, {
        line_id: btn.dataset.lineId,
        delta: increaseBtn ? 1 : -1,
      }).then(renderOrder);
    });

    cartLinesEl.addEventListener('change', (event) => {
      const noteInput = event.target.closest('.line-note-input');
      if (!canEdit || !noteInput) return;
      postForm(window.TABLE_ORDER_URLS.setNote, {
        line_id: noteInput.dataset.lineId,
        notes: noteInput.value,
      }).then(renderOrder);
    });
  }

  // ---------------- Confirm Order (send KOT) ----------------

  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      // Open the tab now, inside the click handler itself — browsers only
      // treat window.open() as a trusted user action (not a blocked
      // popup) when it's tied directly to the gesture, which the async
      // fetch() below would otherwise break. We navigate this
      // already-open tab once the KOT URL comes back.
      const printWindow = window.open('', '_blank');

      postForm(window.TABLE_ORDER_URLS.confirm, {}).then((payload) => {
        renderOrder(payload);
        if (payload.kot_created) {
          if (printWindow) {
            printWindow.location = payload.kot_print_url;
          } else {
            window.open(payload.kot_print_url, '_blank');
          }
        } else {
          if (printWindow) printWindow.close();
          if (!payload.error) alert('No new or changed items to send to the kitchen.');
        }
      });
    });
  }

  // ---------------- Generate Invoice ----------------

  const invoiceBtn = document.getElementById('generate-invoice-btn');
  if (invoiceBtn) {
    invoiceBtn.addEventListener('click', () => {
      if (!confirm('Generate the invoice for this table? Any unsent item changes will be sent to the kitchen first.')) return;
      document.getElementById('generate-invoice-form').submit();
    });
  }
})();
