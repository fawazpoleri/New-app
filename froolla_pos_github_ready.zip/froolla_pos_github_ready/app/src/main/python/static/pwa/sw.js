/**
 * Service worker for the staff "Table Orders" PWA.
 *
 * Scope is deliberately narrow: this makes the app shell (CSS/JS/icons)
 * load instantly and survive a flaky WiFi moment, since restaurant WiFi
 * is exactly the kind of network this matters for. It does NOT cache
 * order data, KOT pages, or any POST — a waiter should never be looking
 * at a stale table/order/cart. Those always go straight to the network.
 */

const CACHE_NAME = 'froolla-table-orders-v1';

const APP_SHELL = [
  '/static/pwa/manifest.json',
  '/static/pwa/icon-192.png',
  '/static/pwa/icon-512.png',
  '/static/pwa/offline.html',
  '/static/css/base.css',
  '/static/css/tables.css',
  '/static/css/pos.css',
  '/static/js/table_order.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names.filter((name) => name !== CACHE_NAME).map((name) => caches.delete(name))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return; // never intercept POSTs — always hit the server live

  const url = new URL(request.url);

  // Full-page navigations (opening/reloading a screen): network first, so
  // the floor plan / order screen is always current. Only fall back to a
  // simple offline notice if there's genuinely no connection.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => caches.match('/static/pwa/offline.html'))
    );
    return;
  }

  // Static assets (css/js/icons): cache-first for speed, refreshing the
  // cache in the background when the network is available.
  if (url.pathname.startsWith('/static/')) {
    event.respondWith(
      caches.match(request).then((cached) => {
        const networkFetch = fetch(request).then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        }).catch(() => cached);
        return cached || networkFetch;
      })
    );
    return;
  }

  // Everything else (order data, KOT prints, etc.) — always go live.
});
