package com.froolla.pos

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Boots the bundled Django project (billing screens only — see
 * android_entry.py / cafepos/urls.py) inside this app's own process via
 * Chaquopy, on a background thread, then points the WebView at it once
 * it responds. The server only ever listens on 127.0.0.1 — nothing here
 * is reachable from the network.
 */
class MainActivity : AppCompatActivity() {

    private val SERVER_URL = "http://127.0.0.1:8000/"
    private val executor = Executors.newSingleThreadExecutor()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)
        val loadingOverlay = findViewById<View>(R.id.loadingOverlay)
        val loadingText = findViewById<TextView>(R.id.loadingText)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // Cashier session cookie needs to persist across taps just like a
        // normal browser tab — default WebView cookie behavior handles this.
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                loadingOverlay.visibility = View.GONE
            }
        }

        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        executor.execute {
            try {
                startDjangoServer()
                waitUntilServerReady()
                runOnUiThread { webView.loadUrl(SERVER_URL) }
            } catch (e: Exception) {
                runOnUiThread {
                    loadingText.text = "Failed to start: ${e.message}"
                }
            }
        }
    }

    /** Calls android_entry.start(filesDir) — this call never returns (waitress.serve loops). */
    private fun startDjangoServer() {
        val py = Python.getInstance()
        val module = py.getModule("android_entry")
        // Fire-and-forget: run on this background thread, which is
        // dedicated to the server for the lifetime of the app.
        Thread {
            try {
                module.callAttr("start", filesDir.absolutePath)
            } catch (e: PyException) {
                e.printStackTrace()
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    /** Polls the local server until it responds (migrations can take a couple seconds on first run). */
    private fun waitUntilServerReady() {
        val deadline = System.currentTimeMillis() + 30_000
        while (System.currentTimeMillis() < deadline) {
            try {
                val conn = URL(SERVER_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 500
                conn.readTimeout = 500
                conn.requestMethod = "GET"
                conn.connect()
                conn.responseCode // any response at all means the server is up
                conn.disconnect()
                return
            } catch (e: Exception) {
                Thread.sleep(300)
            }
        }
        throw RuntimeException("Server did not respond in time")
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
