# Add project specific ProGuard rules here.
# minifyEnabled is off by default for this build (see app/build.gradle.kts).
