plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.froolla.pos"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.froolla.pos"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // Keep the APK smaller — real devices only, drop the x86 emulator ABIs.
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }

        python {
            // Packages needed by the trimmed billing-only Django project.
            // (psycopg2-binary and django-jazzmin from the desktop build are
            // dropped on purpose — SQLite-only + no admin theme on-device.)
            pip {
                install("django>=5.2,<6.0")
                install("whitenoise>=6.6")
                install("waitress>=3.0")
                install("Pillow>=10.0")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
